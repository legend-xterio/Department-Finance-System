// ──────────────────────────────────────────────────────────────────────────────
// THE POSTING ENGINE — every ledger write goes through postEntry().
//
// The URPSA workbook is SINGLE-ENTRY: one row per income or expense, with a
// category code. This engine takes that row and DERIVES the balanced double
// entry, so trial balance, financial position and cash flow are real statements
// rather than typed-in totals. Nothing else in the app inserts a journal_entry
// or journal_line.
//
// Rules enforced (mirroring the workbook's own Error Checks sheet):
//   R1  ≥ 2 lines, and at least one debit and one credit
//   R2  debits equal credits to the kobo
//   R3  amount > 0, each line exactly one of debit/credit non-zero
//   R4  the account exists, is postable, and is active
//   R5  the cash account exists and is active
//   R6  the posting date falls inside an OPEN period — a closed period refuses
//   R7  nothing posts before the conversion date (no pre-system history)
//   R8  evidence: an entry above the org's evidence threshold must carry a
//       VERIFIED document (the workbook's "Evidence / acknowledgement needed")
//   R9  posted entries are immutable — corrections are reversals
// ──────────────────────────────────────────────────────────────────────────────
import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "./_core/db";
import {
  accounts,
  cashAccounts,
  evidence,
  fiscalPeriods,
  journalEntries,
  journalLines,
  orgs,
} from "../drizzle/schema";
import { money, num } from "../shared/finance";

export class PostingError extends Error {
  code: string;
  constructor(message: string, code = "BAD_REQUEST") {
    super(message);
    this.code = code;
  }
}

export interface PostingLine {
  accountCode: string;
  activityCode?: string | null;
  cashAccountCode?: string | null;
  debit?: number;
  credit?: number;
  memo?: string | null;
}

export interface PostingInput {
  ownerId: string;
  entryDate: string; // YYYY-MM-DD
  description: string;
  documentRef?: string | null;
  source?: string;
  lines: PostingLine[];
  preparedBy: string;
  approvedBy?: string | null;
  evidenceIds?: string[];
  reversesEntryId?: string | null;
  /** Skip the evidence gate — used only by system postings whose evidence was
   *  already checked at the object level (opening balances, reversals). */
  bypassEvidenceGate?: boolean;
}

/**
 * Next sequential entry number for this owner: JE-0001, JE-0002 …
 *
 * Highest existing suffix + 1, never a row count. Counting breaks the moment an
 * entry is deleted or a reversal removes one: the count drops, the "next"
 * number is one that already exists, and the unique index rejects it — a hard
 * failure that looks like a random posting error.
 */
async function nextEntryNo(ownerId: string): Promise<string> {
  const [row] = await db
    .select({ max: sql<string | null>`max(nullif(regexp_replace(${journalEntries.entryNo}, '\\D', '', 'g'), '')::int)` })
    .from(journalEntries)
    .where(eq(journalEntries.ownerId, ownerId));
  const next = Number(row?.max ?? 0) + 1;
  return `JE-${String(next).padStart(4, "0")}`;
}

/** Resolve the fiscal period that owns a date, creating nothing. */
async function periodForDate(ownerId: string, date: string) {
  const [p] = await db
    .select()
    .from(fiscalPeriods)
    .where(
      and(
        eq(fiscalPeriods.ownerId, ownerId),
        sql`${fiscalPeriods.startDate} <= ${date}::date`,
        sql`${fiscalPeriods.endDate} >= ${date}::date`,
      ),
    )
    .limit(1);
  return p ?? null;
}

/**
 * Validate + write one balanced journal entry. Throws PostingError with a
 * user-facing message on any rule breach; returns the created entry.
 */
export async function postEntry(input: PostingInput) {
  const { ownerId } = input;

  // ── R1/R3: line shape ─────────────────────────────────────────────────────
  const lines = input.lines.map((l) => ({
    ...l,
    debit: money(l.debit ?? 0),
    credit: money(l.credit ?? 0),
  }));
  if (lines.length < 2) throw new PostingError("An entry needs at least two lines.");
  for (const l of lines) {
    if (l.debit < 0 || l.credit < 0) throw new PostingError("Amounts cannot be negative.");
    if (l.debit > 0 && l.credit > 0) {
      throw new PostingError("Each line is a debit or a credit — never both.");
    }
  }

  // ── R2: balance ───────────────────────────────────────────────────────────
  const totalDebit = money(lines.reduce((s, l) => s + l.debit, 0));
  const totalCredit = money(lines.reduce((s, l) => s + l.credit, 0));
  if (totalDebit === 0 && totalCredit === 0) {
    throw new PostingError("The entry has no value.");
  }
  if (totalDebit !== totalCredit) {
    throw new PostingError(
      `Debits (${totalDebit.toFixed(2)}) must equal credits (${totalCredit.toFixed(2)}).`,
    );
  }

  // ── R4: accounts exist, are postable, and are active ──────────────────────
  const codes = [...new Set(lines.map((l) => l.accountCode))];
  const chart = await db.select().from(accounts).where(inArray(accounts.code, codes));
  const byCode = new Map(chart.map((a) => [a.code, a]));
  for (const l of lines) {
    const acc = byCode.get(l.accountCode);
    if (!acc) throw new PostingError(`Account ${l.accountCode} does not exist.`);
    if (!acc.isPostable) {
      throw new PostingError(`Account ${acc.code} ${acc.name} is a heading, not a postable account.`);
    }
    if (!acc.isActive) throw new PostingError(`Account ${acc.code} ${acc.name} is inactive.`);
  }

  // ── R5: cash accounts exist and are active ────────────────────────────────
  const cashCodes = [...new Set(lines.map((l) => l.cashAccountCode).filter(Boolean))] as string[];
  if (cashCodes.length > 0) {
    const found = await db
      .select()
      .from(cashAccounts)
      .where(and(eq(cashAccounts.ownerId, ownerId), inArray(cashAccounts.code, cashCodes)));
    const byCash = new Map(found.map((c) => [c.code, c]));
    for (const code of cashCodes) {
      const ca = byCash.get(code);
      if (!ca) throw new PostingError(`Cash account ${code} does not exist.`);
      if (!ca.isActive) throw new PostingError(`Cash account ${code} is inactive.`);
    }
  }

  // ── R7: not before the conversion date ────────────────────────────────────
  const [org] = await db.select().from(orgs).where(eq(orgs.ownerId, ownerId)).limit(1);
  if (!org) {
    throw new PostingError("Set up your organisation before posting entries.", "PRECONDITION_FAILED");
  }
  if (input.entryDate < String(org.conversionDate)) {
    throw new PostingError(`Nothing may post before the conversion date (${org.conversionDate}).`);
  }

  // ── R6: period must be open ───────────────────────────────────────────────
  const period = await periodForDate(ownerId, input.entryDate);
  if (!period) {
    throw new PostingError(
      `No fiscal period covers ${input.entryDate}. Create the period, or post into an open one.`,
    );
  }
  if (period.status === "closed" || period.status === "locked") {
    throw new PostingError(
      `Period ${period.fiscalYear}-${String(period.periodNo).padStart(2, "0")} is ${period.status} — posting refused.`,
    );
  }

  // ── R8: evidence gate ─────────────────────────────────────────────────────
  if (!input.bypassEvidenceGate) {
    const needsEvidence =
      totalDebit >= num(org.evidenceRequiredAbove) ||
      lines.some((l) => byCode.get(l.accountCode)?.requiresEvidence);
    if (needsEvidence) {
      const ids = input.evidenceIds ?? [];
      if (ids.length === 0) {
        throw new PostingError(
          `Evidence is required above ${num(org.evidenceRequiredAbove).toFixed(2)} or on this account. Attach a document first.`,
          "PRECONDITION_FAILED",
        );
      }
      const found = await db
        .select({ id: evidence.id, status: evidence.status })
        .from(evidence)
        .where(and(eq(evidence.ownerId, ownerId), inArray(evidence.id, ids)));
      const verified = found.filter((e) => e.status === "verified");
      if (verified.length === 0) {
        throw new PostingError(
          "Evidence must be verified before the entry can post. Verify the attached document first.",
          "PRECONDITION_FAILED",
        );
      }
    }
  }

  // ── Write the entry + lines ───────────────────────────────────────────────
  const entryNo = await nextEntryNo(ownerId);
  const [entry] = await db
    .insert(journalEntries)
    .values({
      ownerId,
      entryNo,
      entryDate: input.entryDate,
      periodId: period.id,
      source: input.source ?? "manual",
      status: "posted",
      description: input.description,
      documentRef: input.documentRef ?? null,
      currency: "NGN",
      totalDebit: totalDebit.toFixed(2),
      totalCredit: totalCredit.toFixed(2),
      reversesEntryId: input.reversesEntryId ?? null,
      preparedBy: input.preparedBy,
      approvedBy: input.approvedBy ?? null,
      postedAt: new Date(),
    })
    .returning();

  await db.insert(journalLines).values(
    lines.map((l, i) => ({
      ownerId,
      entryId: entry.id,
      lineNo: i + 1,
      accountCode: l.accountCode,
      activityCode: l.activityCode ?? null,
      cashAccountCode: l.cashAccountCode ?? null,
      debit: l.debit.toFixed(2),
      credit: l.credit.toFixed(2),
      memo: l.memo ?? null,
    })),
  );

  return entry;
}

/**
 * Post a workbook-style single-entry transaction as a balanced double entry.
 *
 *   Income  →  Dr cash account,  Cr income account (4001–4005)
 *   Expense →  Dr expense account (5001–5007),  Cr cash account
 *
 * This is the ONLY way a transaction row reaches the ledger, so the workbook's
 * "one row per actual income or expense" model and the double entry can never
 * disagree.
 */
export async function postTransaction(input: {
  ownerId: string;
  txnType: "Income" | "Expense";
  txnDate: string;
  categoryCode: string;
  cashAccountCode: string;
  amount: number;
  description: string;
  activityCode?: string | null;
  documentRef?: string | null;
  preparedBy: string;
  approvedBy?: string | null;
  evidenceIds?: string[];
  bypassEvidenceGate?: boolean;
}) {
  const amount = money(input.amount);
  if (amount <= 0) throw new PostingError("The amount must be greater than zero.");

  // Which general-ledger account does this cash account post to?
  //
  // This used to be the literal "1012" for every movement, so a petty-cash
  // payment credited the BANK account: the cash book and the bank statement
  // could never agree, and the balance sheet showed the wrong split between
  // cash on hand and money at the bank. The mapping now comes from the cash
  // account row itself, falling back to its type only when the column is empty
  // (an older row that predates the column).
  const [cashRow] = await db
    .select()
    .from(cashAccounts)
    .where(and(eq(cashAccounts.ownerId, input.ownerId), eq(cashAccounts.code, input.cashAccountCode)))
    .limit(1);
  if (!cashRow) {
    throw new PostingError(`Cash account ${input.cashAccountCode} does not exist.`);
  }
  if (!cashRow.isActive) {
    throw new PostingError(`Cash account ${input.cashAccountCode} is inactive.`);
  }
  const cashGlCode = cashRow.glAccountCode?.trim() || (cashRow.accountType === "cash" ? "1011" : "1012");

  const isIncome = input.txnType === "Income";
  const lines: PostingLine[] = isIncome
    ? [
        {
          accountCode: cashGlCode,
          cashAccountCode: input.cashAccountCode,
          activityCode: input.activityCode ?? null,
          debit: amount,
          memo: `Received into ${input.cashAccountCode}`,
        },
        {
          accountCode: input.categoryCode,
          activityCode: input.activityCode ?? null,
          credit: amount,
          memo: input.description,
        },
      ]
    : [
        {
          accountCode: input.categoryCode,
          activityCode: input.activityCode ?? null,
          debit: amount,
          memo: input.description,
        },
        {
          accountCode: cashGlCode,
          cashAccountCode: input.cashAccountCode,
          activityCode: input.activityCode ?? null,
          credit: amount,
          memo: `Paid from ${input.cashAccountCode}`,
        },
      ];

  return postEntry({
    ownerId: input.ownerId,
    entryDate: input.txnDate,
    description: input.description,
    documentRef: input.documentRef ?? null,
    source: "manual",
    preparedBy: input.preparedBy,
    approvedBy: input.approvedBy ?? null,
    evidenceIds: input.evidenceIds,
    bypassEvidenceGate: input.bypassEvidenceGate,
    lines,
  });
}

/**
 * Post the opening balances as a REAL balanced journal entry.
 *
 *   Dr 1012 Bank            bankAmount
 *   Dr 1011 Cash on hand    cashAmount
 *   Dr 1013 Receivable      receivableAmount
 *   Cr 2011 Liabilities     payableAmount
 *   Cr 3010 Accumulated fund fundAmount
 *
 * The entry is dated at the start of the financial year and goes through the
 * same validation as any other posting (accounts postable, period open, nothing
 * before the conversion date). The evidence gate is bypassed deliberately: an
 * opening balance is a brought-forward figure, not a payment, so there is no
 * receipt to attach — the treasurer's authority is the source document.
 *
 * Re-posting REPLACES the previous opening entry rather than adding a second
 * one: the old entry is removed and the corrected one posted, so the ledger
 * never carries two competing openings and the gross debits stay honest.
 */
export async function postOpeningEntry(input: {
  ownerId: string;
  entryDate: string;
  bankAmount: number;
  cashAmount: number;
  receivableAmount: number;
  payableAmount: number;
  fundAmount: number;
  preparedBy: string;
  /** The opening entry currently in force, if any — removed before re-posting. */
  replacesEntryId?: string | null;
}) {
  const bank = money(input.bankAmount);
  const cash = money(input.cashAmount);
  const receivable = money(input.receivableAmount);
  const payable = money(input.payableAmount);
  const fund = money(input.fundAmount);

  for (const [label, v] of [
    ["Bank", bank],
    ["Cash", cash],
    ["Receivable", receivable],
    ["Payable", payable],
  ] as [string, number][]) {
    if (v < 0) throw new PostingError(`${label} cannot be negative.`);
  }

  const totalAssets = money(bank + cash + receivable);
  const totalClaims = money(payable + fund);
  if (totalAssets === 0 && totalClaims === 0) {
    throw new PostingError("Enter at least one opening balance.");
  }
  if (totalAssets !== totalClaims) {
    throw new PostingError(
      `The opening entry must balance. Assets (bank + cash + receivable) are ${totalAssets.toFixed(2)} ` +
        `but liabilities + accumulated fund are ${totalClaims.toFixed(2)}. ` +
        `Set the accumulated fund to ${money(totalAssets - payable).toFixed(2)} to balance it.`,
    );
  }

  const lines: PostingLine[] = [];
  if (bank > 0) {
    lines.push({
      accountCode: "1012",
      cashAccountCode: "BANK-01",
      debit: bank,
      memo: "Opening balance — bank",
    });
  }
  if (cash > 0) {
    lines.push({
      accountCode: "1011",
      cashAccountCode: "CASH-01",
      debit: cash,
      memo: "Opening balance — cash on hand",
    });
  }
  if (receivable > 0) {
    lines.push({
      accountCode: "1013",
      debit: receivable,
      memo: "Opening balance — amounts owed to the association",
    });
  }
  if (payable > 0) {
    lines.push({
      accountCode: "2011",
      credit: payable,
      memo: "Opening balance — amounts owed by the association",
    });
  }
  if (fund > 0) {
    lines.push({
      accountCode: "3010",
      credit: fund,
      memo: "Opening balance — accumulated fund brought forward",
    });
  }

  // Post the corrected entry FIRST, then remove the one it replaces.
  //
  // The order matters. Deleting first and posting second means a validation
  // failure (a closed period, an inactive account, a bad date) leaves the book
  // with NO opening entry at all — the treasurer's figures silently vanish and
  // the trial balance still balances, so nothing looks wrong. Posting first
  // means a failure leaves the previous opening exactly as it was, and the
  // delete only runs once the replacement is safely in the ledger.
  const entry = await postEntry({
    ownerId: input.ownerId,
    entryDate: input.entryDate,
    description: "Opening balances brought forward",
    source: "opening",
    preparedBy: input.preparedBy,
    bypassEvidenceGate: true,
    lines,
  });

  if (input.replacesEntryId && input.replacesEntryId !== entry.id) {
    const [old] = await db
      .select()
      .from(journalEntries)
      .where(
        and(
          eq(journalEntries.id, input.replacesEntryId),
          eq(journalEntries.ownerId, input.ownerId),
        ),
      )
      .limit(1);
    // Only ever remove a previous OPENING entry — never a manual posting that
    // happens to share the id.
    if (old && old.source === "opening") {
      // Lines cascade with the header.
      await db.delete(journalEntries).where(eq(journalEntries.id, old.id));
    }
  }

  return entry;
}

/**
 * R9 — reverse a posted entry. Creates a mirrored entry (debits ↔ credits) and
 * marks the original reversed. The original is never edited or deleted.
 */
export async function reverseEntry(input: {
  ownerId: string;
  entryId: string;
  reason: string;
  actor: string;
}) {
  const [original] = await db
    .select()
    .from(journalEntries)
    .where(and(eq(journalEntries.id, input.entryId), eq(journalEntries.ownerId, input.ownerId)))
    .limit(1);
  if (!original) throw new PostingError("Entry not found.", "NOT_FOUND");
  if (original.status === "reversed") {
    throw new PostingError("That entry has already been reversed.");
  }

  const lines = await db
    .select()
    .from(journalLines)
    .where(eq(journalLines.entryId, original.id));

  const reversal = await postEntry({
    ownerId: input.ownerId,
    entryDate: new Date().toISOString().slice(0, 10),
    description: `Reversal of ${original.entryNo} — ${input.reason}`,
    source: "reversal",
    preparedBy: input.actor,
    reversesEntryId: original.id,
    bypassEvidenceGate: true, // it mirrors an entry that already passed the gate
    lines: lines.map((l) => ({
      accountCode: l.accountCode,
      activityCode: l.activityCode,
      cashAccountCode: l.cashAccountCode,
      // mirror: a debit becomes a credit
      debit: num(l.credit),
      credit: num(l.debit),
      memo: `Reversal of ${original.entryNo}`,
    })),
  });

  await db
    .update(journalEntries)
    .set({ status: "reversed" })
    .where(eq(journalEntries.id, original.id));

  return reversal;
}
