// ── AGENT-OWNED: tRPC API surface ─────────────────────────────────────────────
// Every business procedure is owner-scoped through ctx.ownerId. There is no
// procedure anywhere in this file that can read or write another treasurer's
// rows. Ledger writes go ONLY through postEntry()/postTransaction() in
// ./posting.ts, so the double-entry / period / evidence rules cannot be bypassed
// by any client.
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { and, asc, desc, eq, gte, lte, sql } from "drizzle-orm";
import { router, publicProcedure, protectedProcedure, middleware } from "./_core/trpc";
import { authProvider, registerLocalUser, AuthError, EmailTakenError } from "./_core/auth";
import { compare, hash as bcryptHash } from "bcryptjs";
import { createHash, randomBytes } from "node:crypto";
import {
  storageCommit,
  storageDeleteOwned,
  storageListByOwner,
  storagePutUrl,
  StorageError,
} from "./_core/storage";
import { randomUUID } from "node:crypto";
import { atomic, db } from "./_core/db";
import {
  accounts,
  activities,
  assets,
  budgetLines,
  budgets,
  cashAccounts,
  dues,
  evidence,
  fiscalPeriods,
  journalEntries,
  journalLines,
  liabilities,
  members,
  openingBalances,
  orgs,
  sponsorship,
  transactions,
  orgMembers,
  loginAttempts,
  recoveryCodes,
  passwordResets,
  changeLog,
  reconciliationItems,
  reconciliations,
  userSecurity,
  users,
} from "../drizzle/schema";
import { postEntry, postTransaction, postOpeningEntry, reverseEntry, PostingError } from "./posting";
import * as rep from "./reports";
import { money, num, fiscalMonths } from "../shared/finance";
import { fiscalYearChoices } from "../shared/budget-plan";
import { memberIdPrefix, formatMemberId, highestSequence } from "../shared/member-id";

const today = () => new Date().toISOString().slice(0, 10);

/** Re-throw a PostingError as the right tRPC code so the user reads the reason. */
function asTrpc(e: unknown): never {
  if (e instanceof PostingError) {
    throw new TRPCError({
      code: (e.code as "BAD_REQUEST") ?? "BAD_REQUEST",
      message: e.message,
    });
  }
  throw e;
}

// ── Book access: owner resolution + role enforcement ─────────────────────────
/**
 * Roles that may change the BOOK ITSELF: settings, periods, access, the chart of
 * accounts, reconciliations, backups, deletions. `auditor` and `president` are
 * refused here.
 */
const WRITE_ROLES = new Set(["treasurer", "admin"]);

/**
 * Roles that may enter TRANSACTIONAL records in the registers: a journal entry,
 * a petty-cash movement, a sponsorship receipt, an asset, a commitment, a budget
 * line. The auditor is included because the association's auditor is the person
 * who actually sees the receipts first; the president is not, because that login
 * exists to look without touching.
 *
 * This is deliberately a SEPARATE tier from WRITE_ROLES. An auditor who can post
 * a transaction must still be unable to close a period, change a role, or edit
 * the chart of accounts — otherwise the audit trail they are supposed to check
 * is one they could rewrite.
 */
const REGISTER_WRITE_ROLES = new Set(["treasurer", "admin", "auditor"]);
export const BOOK_ROLES = ["treasurer", "admin", "auditor", "president"] as const;
export type BookRole = (typeof BOOK_ROLES)[number];

/**
 * Resolve WHICH book this request is about, and what the caller may do in it.
 *
 * The book is identified by its owner. A user is either the owner (the treasurer
 * who created it — always full rights) or an `org_members` row naming the owner
 * and a role. Anything else is refused, so a stranger who signs up cannot reach
 * URPSA's data even though they hold a valid session.
 *
 * Every business procedure below runs on `bookProcedure`, so `ctx.ownerId` is
 * the book and `ctx.bookRole` is the caller's standing in it. Mutations run on
 * `writeProcedure`, which refuses a read-only role server-side — the client is
 * never trusted to hide a button.
 */
const bookMiddleware = middleware(async ({ ctx, next }) => {
  if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });

  // The owner of a book is its treasurer. This is the common case and needs no
  // extra query beyond the membership lookup below.
  const [membership] = await db
    .select()
    .from(orgMembers)
    .where(eq(orgMembers.userId, ctx.user.id))
    .limit(1);

  if (membership) {
    return next({
      ctx: { ...ctx, user: ctx.user, ownerId: membership.ownerId, bookRole: membership.role as BookRole },
    });
  }

  // Not a member of anyone else's book → they own their own.
  return next({
    ctx: { ...ctx, user: ctx.user, ownerId: ctx.user.id, bookRole: "treasurer" as BookRole },
  });
});

export const bookProcedure = protectedProcedure.use(bookMiddleware);

/** A book procedure that may only be called by a role allowed to change the
 *  book itself (settings, periods, access, deletions, reconciliations). */
export const writeProcedure = bookProcedure.use(({ ctx, next }) => {
  if (!WRITE_ROLES.has(ctx.bookRole)) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: `Your role (${ctx.bookRole}) cannot change the book's setup — that is the treasurer's or an admin's call.`,
    });
  }
  return next({ ctx });
});

/**
 * A book procedure that may be called by any role allowed to ENTER transactional
 * records — the treasurer, an admin, and the auditor.
 *
 * Used only by the register mutations (posting, editing a register row, attaching
 * a receipt). Everything structural stays on `writeProcedure`, so an auditor can
 * add a transaction but cannot close the period it lands in, change who else can
 * sign in, or edit the chart of accounts.
 */
export const registerWriteProcedure = bookProcedure.use(({ ctx, next }) => {
  if (!REGISTER_WRITE_ROLES.has(ctx.bookRole)) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: `Your role (${ctx.bookRole}) is read-only — it cannot enter records in the registers.`,
    });
  }
  return next({ ctx });
});

/** Record a register edit in the change log. Never throws: a log failure must
 *  not roll back the edit the treasurer actually asked for. */
async function logChange(input: {
  ownerId: string;
  actor: { id: string; name: string | null; email: string; role: string };
  /** The caller's role IN THIS BOOK. `actor.role` is the global user role
   *  ('user' for everyone), so logging that would make the change log's Role
   *  column useless — every row would say "user". */
  bookRole?: string;
  entity: string;
  entityId?: string | null;
  action: string;
  summary: string;
  before?: unknown;
  after?: unknown;
}) {
  try {
    await db.insert(changeLog).values({
      ownerId: input.ownerId,
      actorId: input.actor.id,
      actorName: input.actor.name ?? input.actor.email,
      actorRole: input.bookRole ?? input.actor.role,
      entity: input.entity,
      entityId: input.entityId ?? null,
      action: input.action,
      summary: input.summary,
      before: input.before === undefined ? null : JSON.stringify(input.before),
      after: input.after === undefined ? null : JSON.stringify(input.after),
    });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error("[change-log] failed to record", e);
  }
}

// ── Register reference series ─────────────────────────────────────────────────
/**
 * Next free `PREFIX-000N` for a table column, by the highest existing suffix.
 *
 * Always max+1, never a row count: a deleted row must not donate its reference
 * to the next record, and a count-based series collides on the unique index the
 * first time anything is removed.
 */
async function nextRef(table: any, column: any, ownerId: string, prefix: string) {
  const [row] = await db
    .select({ max: sql<string | null>`max(nullif(regexp_replace(${column}, '\\D', '', 'g'), '')::int)` })
    .from(table)
    .where(eq(table.ownerId, ownerId));
  return `${prefix}-${String(Number(row?.max ?? 0) + 1).padStart(4, "0")}`;
}
// Each register keeps its own series, allocated from the highest existing
// suffix so a deleted reference is never reissued.
async function nextRegisterRef(
  kind: "sponsorship" | "assets" | "liabilities",
  ownerId: string,
  prefix: string,
) {
  // Highest existing suffix + 1, not a row count: deleting a row must never
  // hand its reference to the next record, or a stale transaction starts
  // pointing at a pledge that no longer exists.
  const rows =
    kind === "sponsorship"
      ? await db.select({ ref: sponsorship.sponsorshipId }).from(sponsorship).where(eq(sponsorship.ownerId, ownerId))
      : kind === "assets"
        ? await db.select({ ref: assets.assetId }).from(assets).where(eq(assets.ownerId, ownerId))
        : await db.select({ ref: liabilities.liabilityId }).from(liabilities).where(eq(liabilities.ownerId, ownerId));
  let max = 0;
  for (const r of rows) {
    const n = Number(String(r.ref).slice(prefix.length + 1));
    if (Number.isFinite(n) && n > max) max = n;
  }
  return `${prefix}-${String(max + 1).padStart(4, "0")}`;
}

// ── Member IDs: URPSA/YY/XXX ────────────────────────────────────────────────
const MEMBER_ID_RE = /^URPSA\/\d{2}\/\d{3}$/;

export function assertMemberId(id: string) {
  if (!MEMBER_ID_RE.test(id)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Member IDs follow the URPSA/YY/XXX rule — for example URPSA/26/013. "${id}" does not.`,
    });
  }
}

/** Next free URPSA/YY/XXX for an admission year, by highest existing suffix. */
export async function nextMemberId(ownerId: string, year: string): Promise<string> {
  const prefix = memberIdPrefix(year);
  const rows = await db
    .select({ memberId: members.memberId })
    .from(members)
    .where(and(eq(members.ownerId, ownerId), sql`${members.memberId} like ${prefix + "%"}`));
  return formatMemberId(year, highestSequence(rows.map((r) => r.memberId), prefix) + 1);
}

// ── Auth ─────────────────────────────────────────────────────────────────────
/**
 * Failed-login throttling.
 *
 * Two independent counters, because they stop different attacks:
 *   per EMAIL — someone guessing one treasurer's password
 *   per IP    — someone spraying many accounts from one machine
 *
 * Both are counted from the `login_attempts` table rather than memory, so the
 * limit holds across processes and survives a restart. A successful login
 * clears that email's failures, so a legitimate user who mistyped twice is not
 * punished after they get in.
 */
const MAX_FAILS_PER_EMAIL = 5;
const MAX_FAILS_PER_IP = 20;
const LOCKOUT_MINUTES = 15;

function clientIp(c: any): string {
  const h = c?.req?.header?.bind(c.req);
  const fwd = h?.("x-forwarded-for") ?? h?.("x-real-ip");
  if (fwd) return String(fwd).split(",")[0].trim();
  return "unknown";
}

async function recentFailures(kind: "email" | "ip", key: string): Promise<number> {
  const since = new Date(Date.now() - LOCKOUT_MINUTES * 60_000);
  const [row] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(loginAttempts)
    .where(
      and(
        eq(loginAttempts.kind, kind),
        eq(loginAttempts.key, key),
        eq(loginAttempts.success, false),
        gte(loginAttempts.attemptedAt, since),
      ),
    );
  return row?.n ?? 0;
}

async function recordAttempt(kind: "email" | "ip", key: string, success: boolean) {
  await db.insert(loginAttempts).values({ kind, key, success });
}

/** Throws the lockout message when either counter is over its limit. */
async function assertNotLockedOut(email: string, ip: string) {
  const [byEmail, byIp] = await Promise.all([
    recentFailures("email", email.toLowerCase()),
    recentFailures("ip", ip),
  ]);
  if (byEmail >= MAX_FAILS_PER_EMAIL) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: `Too many failed attempts for this account. Try again in ${LOCKOUT_MINUTES} minutes, or use a recovery code to reset the password.`,
    });
  }
  if (byIp >= MAX_FAILS_PER_IP) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: `Too many failed attempts from this network. Try again in ${LOCKOUT_MINUTES} minutes.`,
    });
  }
}

/**
 * The IP-only check, for the recovery path.
 *
 * A password lockout must NOT block account recovery — being locked out is
 * precisely when a recovery code is needed, so refusing it there would turn a
 * forgotten password into a permanent lockout. The recovery code is its own
 * credential, and it is long enough that guessing is not a threat; the IP
 * counter still stops a machine hammering the endpoint.
 */
async function assertIpNotLockedOut(ip: string) {
  const byIp = await recentFailures("ip", ip);
  if (byIp >= MAX_FAILS_PER_IP) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: `Too many failed attempts from this network. Try again in ${LOCKOUT_MINUTES} minutes.`,
    });
  }
}

/** A recovery code: 4 groups of 4 from an unambiguous alphabet (no O/0/I/1). */
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function makeRecoveryCode(): string {
  const bytes = randomBytes(16);
  const chars = [...bytes].map((b) => CODE_ALPHABET[b % CODE_ALPHABET.length]);
  return [0, 4, 8, 12].map((i) => chars.slice(i, i + 4).join("")).join("-");
}
const sha256 = (s: string) => createHash("sha256").update(s).digest("hex");

/** Mark every session issued before now as stale. */
async function revokeSessions(userId: string) {
  const now = new Date();
  await db
    .insert(userSecurity)
    .values({ userId, sessionsValidAfter: now, passwordChangedAt: now, updatedAt: now })
    .onConflictDoUpdate({
      target: userSecurity.userId,
      set: { sessionsValidAfter: now, passwordChangedAt: now, updatedAt: now },
    });
}

const authRouter = router({
  me: publicProcedure.query(({ ctx }) => ctx.user),

  /** Whether the public signup form is open. Read by the login page. */
  signupOpen: publicProcedure.query(async () => {
    const [row] = await db.select({ allow: orgs.allowPublicSignup }).from(orgs).limit(1);
    // No org yet → this is a brand-new install, so allow the first account.
    return { open: row ? row.allow : true };
  }),

  signup: publicProcedure
    .input(z.object({ email: z.string().email(), password: z.string().min(8), name: z.string().optional() }))
    .mutation(async ({ ctx, input }) => {
      // Public signup is closed by default. A stranger must not be able to mint
      // an account on a bookkeeping app; the treasurer adds colleagues instead.
      const [anyOrg] = await db.select({ allow: orgs.allowPublicSignup }).from(orgs).limit(1);
      if (anyOrg && !anyOrg.allow) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message:
            "Public signup is closed. Ask the treasurer to add you from Settings → Access, or sign in with the account you were given.",
        });
      }
      try {
        const user = await registerLocalUser(input.email, input.password, input.name);
        await authProvider().login(ctx.c, input.email, input.password);
        return user;
      } catch (e: unknown) {
        if (e instanceof EmailTakenError) throw new TRPCError({ code: "CONFLICT", message: e.message });
        throw e;
      }
    }),

  login: publicProcedure
    .input(z.object({ email: z.string().email(), password: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const email = input.email.toLowerCase();
      const ip = clientIp(ctx.c);
      await assertNotLockedOut(email, ip);
      try {
        const user = await authProvider().login(ctx.c, email, input.password);
        // Clear this account's failures: a legitimate user who mistyped is not
        // punished for having got in.
        await db
          .delete(loginAttempts)
          .where(and(eq(loginAttempts.kind, "email"), eq(loginAttempts.key, email)));
        await recordAttempt("ip", ip, true);
        return user;
      } catch (e) {
        await recordAttempt("email", email, false);
        await recordAttempt("ip", ip, false);
        if (e instanceof AuthError) {
          const left = Math.max(0, MAX_FAILS_PER_EMAIL - (await recentFailures("email", email)));
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message:
              left > 0
                ? `Invalid email or password. ${left} attempt${left === 1 ? "" : "s"} left before this account is locked for ${LOCKOUT_MINUTES} minutes.`
                : `Invalid email or password. This account is now locked for ${LOCKOUT_MINUTES} minutes.`,
          });
        }
        throw e;
      }
    }),

  logout: publicProcedure.mutation(async ({ ctx }) => {
    await authProvider().logout(ctx.c);
    return { ok: true };
  }),

  // ── Account recovery without an email service ──────────────────────────────
  /**
   * Change the password of the signed-in user.
   *
   * Requires the current password (so a borrowed session cannot silently take
   * the account over) and revokes every other session on success.
   */
  changePassword: bookProcedure
    .input(
      z.object({
        currentPassword: z.string().min(1, "Enter your current password"),
        newPassword: z.string().min(8, "Use at least 8 characters"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [row] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
      if (!row?.passwordHash) throw new TRPCError({ code: "BAD_REQUEST", message: "This account has no password." });
      const ok = await compare(input.currentPassword, row.passwordHash);
      if (!ok) throw new TRPCError({ code: "UNAUTHORIZED", message: "That is not your current password." });
      if (input.currentPassword === input.newPassword) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Choose a password different from the current one." });
      }
      const passwordHash = await bcryptHash(input.newPassword, 10);
      await db.update(users).set({ passwordHash }).where(eq(users.id, ctx.user.id));
      await revokeSessions(ctx.user.id);
      // Re-issue a session for THIS device so the user is not logged out of the
      // screen they just used.
      await authProvider().login(ctx.c, row.email, input.newPassword);
      return { ok: true };
    }),

  /**
   * Generate a fresh set of one-time recovery codes, replacing any old ones.
   *
   * The plaintext is returned ONCE and never stored — only bcrypt hashes are
   * kept, so a database read cannot mint a login. This is the whole recovery
   * story on a system with no email: print these and keep them with the books.
   */
  generateRecoveryCodes: bookProcedure.mutation(async ({ ctx }) => {
    const codes = Array.from({ length: 8 }, makeRecoveryCode);
    const hashes = await Promise.all(codes.map((c) => bcryptHash(c, 10)));
    await db.delete(recoveryCodes).where(eq(recoveryCodes.userId, ctx.user.id));
    await db.insert(recoveryCodes).values(
      hashes.map((codeHash, i) => ({
        userId: ctx.user.id,
        codeHash,
        hint: codes[i].slice(-4),
      })),
    );
    return { codes };
  }),

  /** How many unused recovery codes remain, and when they were last issued. */
  recoveryStatus: bookProcedure.query(async ({ ctx }) => {
    const rows = await db.select().from(recoveryCodes).where(eq(recoveryCodes.userId, ctx.user.id));
    const unused = rows.filter((r) => !r.usedAt);
    return {
      total: rows.length,
      unused: unused.length,
      issuedAt: rows[0]?.createdAt ?? null,
    };
  }),

  /**
   * Step 1 of a reset: trade a recovery code for a short-lived reset token.
   *
   * Deliberately public — the whole point is that the user cannot sign in. The
   * code is the credential, so this is rate-limited by the same counters as a
   * login: a wrong code counts as a failed attempt against that email.
   */
  startReset: publicProcedure
    .input(z.object({ email: z.string().email(), recoveryCode: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const email = input.email.toLowerCase();
      const ip = clientIp(ctx.c);
      // IP-only: a password lockout must not block recovery (see the helper).
      await assertIpNotLockedOut(ip);

      const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
      const generic = new TRPCError({
        code: "UNAUTHORIZED",
        message: "That email and recovery code do not match. Check the code and try again.",
      });
      if (!user) {
        await recordAttempt("email", email, false);
        await recordAttempt("ip", ip, false);
        throw generic;
      }

      const codes = await db
        .select()
        .from(recoveryCodes)
        .where(and(eq(recoveryCodes.userId, user.id), sql`${recoveryCodes.usedAt} is null`));

      const normalised = input.recoveryCode.trim().toUpperCase();
      let matched: (typeof codes)[number] | null = null;
      for (const c of codes) {
        if (await compare(normalised, c.codeHash)) {
          matched = c;
          break;
        }
      }
      if (!matched) {
        await recordAttempt("email", email, false);
        await recordAttempt("ip", ip, false);
        throw generic;
      }

      // Burn the code — a recovery code is single-use by construction.
      await db.update(recoveryCodes).set({ usedAt: new Date() }).where(eq(recoveryCodes.id, matched.id));

      const token = randomBytes(32).toString("hex");
      await db.insert(passwordResets).values({
        userId: user.id,
        tokenHash: sha256(token),
        expiresAt: new Date(Date.now() + 15 * 60_000),
      });
      await db.delete(loginAttempts).where(and(eq(loginAttempts.kind, "email"), eq(loginAttempts.key, email)));
      return { token, expiresInMinutes: 15 };
    }),

  /** Step 2 of a reset: set the new password with the token from step 1. */
  completeReset: publicProcedure
    .input(z.object({ token: z.string().min(1), newPassword: z.string().min(8, "Use at least 8 characters") }))
    .mutation(async ({ input }) => {
      const [row] = await db
        .select()
        .from(passwordResets)
        .where(eq(passwordResets.tokenHash, sha256(input.token)))
        .limit(1);
      if (!row || row.usedAt || row.expiresAt.getTime() < Date.now()) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "That reset link has expired or already been used. Start again with another recovery code.",
        });
      }
      const passwordHash = await bcryptHash(input.newPassword, 10);
      await db.update(users).set({ passwordHash }).where(eq(users.id, row.userId));
      await db.update(passwordResets).set({ usedAt: new Date() }).where(eq(passwordResets.id, row.id));
      await revokeSessions(row.userId);
      return { ok: true };
    }),
});

// ── Access: who can use this book, and in what role ──────────────────────────
/**
 * The treasurer's control panel for other people.
 *
 * A colleague is created here with a password the treasurer hands over, and a
 * role. There is no email service, so there is no invitation link — the
 * treasurer sets a temporary password and tells them to change it. That is
 * honest about the constraint rather than pretending an email went out.
 */
const accessRouter = router({
  /** Everyone with access to this book, including the owner. */
  list: bookProcedure.query(async ({ ctx }) => {
    const [owner] = await db.select().from(users).where(eq(users.id, ctx.ownerId)).limit(1);
    const rows = await db
      .select({
        id: orgMembers.id,
        userId: orgMembers.userId,
        role: orgMembers.role,
        displayName: orgMembers.displayName,
        createdAt: orgMembers.createdAt,
        email: users.email,
        name: users.name,
      })
      .from(orgMembers)
      .innerJoin(users, eq(orgMembers.userId, users.id))
      .where(eq(orgMembers.ownerId, ctx.ownerId))
      .orderBy(asc(orgMembers.createdAt));

    return {
      owner: owner
        ? { userId: owner.id, email: owner.email, name: owner.name, role: "treasurer" as const }
        : null,
      members: rows,
      myRole: ctx.bookRole,
    };
  }),

  /**
   * Create a colleague's account and grant them a role in this book.
   *
   * The password is set by the treasurer and shown once, because there is no
   * email to send it to. The new user is told to change it on first sign-in.
   */
  invite: writeProcedure
    .input(
      z.object({
        email: z.string().email(),
        name: z.string().min(1, "Give the person a name"),
        role: z.enum(BOOK_ROLES),
        password: z.string().min(8, "Use at least 8 characters"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      if (input.role === "treasurer") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message:
            "There is one treasurer — the owner of the book. Add this person as an admin (full access) or as auditor/president (read-only).",
        });
      }
      const email = input.email.toLowerCase();
      const [existing] = await db.select().from(users).where(eq(users.email, email)).limit(1);

      let userId: string;
      if (existing) {
        // Already has an account somewhere. Refuse rather than silently
        // re-pointing their password: that would be taking over their login.
        const [alreadyMember] = await db
          .select()
          .from(orgMembers)
          .where(eq(orgMembers.userId, existing.id))
          .limit(1);
        if (alreadyMember) {
          throw new TRPCError({
            code: "CONFLICT",
            message: `${email} already has access to a book. Remove them there first.`,
          });
        }
        if (existing.id === ctx.ownerId) {
          throw new TRPCError({ code: "CONFLICT", message: "That is the treasurer's own account." });
        }
        userId = existing.id;
      } else {
        const passwordHash = await bcryptHash(input.password, 10);
        const [created] = await db
          .insert(users)
          .values({ email, passwordHash, name: input.name })
          .returning();
        userId = created.id;
      }

      const [row] = await db
        .insert(orgMembers)
        .values({
          ownerId: ctx.ownerId,
          userId,
          role: input.role,
          displayName: input.name,
          createdBy: ctx.user.id,
        })
        .returning();

      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "access",
        entityId: row.id,
        action: "created",
        summary: `Gave ${input.name} (${email}) ${input.role} access`,
        after: { email, role: input.role },
      });

      return { id: row.id, userId, email, role: input.role, password: existing ? null : input.password };
    }),

  /** Change someone's role. The owner's own role cannot be changed. */
  setRole: writeProcedure
    .input(z.object({ id: z.string().uuid(), role: z.enum(BOOK_ROLES) }))
    .mutation(async ({ ctx, input }) => {
      if (input.role === "treasurer") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "There is one treasurer — the owner of the book." });
      }
      const [before] = await db
        .select()
        .from(orgMembers)
        .where(and(eq(orgMembers.id, input.id), eq(orgMembers.ownerId, ctx.ownerId)))
        .limit(1);
      if (!before) throw new TRPCError({ code: "NOT_FOUND" });
      const [row] = await db
        .update(orgMembers)
        .set({ role: input.role })
        .where(eq(orgMembers.id, input.id))
        .returning();
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "access",
        entityId: input.id,
        action: "updated",
        summary: `Changed ${before.displayName ?? "a user"}'s role from ${before.role} to ${input.role}`,
        before: { role: before.role },
        after: { role: input.role },
      });
      return row;
    }),

  /** Revoke someone's access to this book. Their account survives. */
  remove: writeProcedure
    .input(z.object({ id: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      const [before] = await db
        .select()
        .from(orgMembers)
        .where(and(eq(orgMembers.id, input.id), eq(orgMembers.ownerId, ctx.ownerId)))
        .limit(1);
      if (!before) throw new TRPCError({ code: "NOT_FOUND" });
      await db.delete(orgMembers).where(eq(orgMembers.id, input.id));
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "access",
        entityId: input.id,
        action: "deleted",
        summary: `Revoked ${before.displayName ?? "a user"}'s access`,
        before: { role: before.role },
      });
      return { ok: true };
    }),

  /** Turn the public signup form on or off. */
  setPublicSignup: writeProcedure
    .input(z.object({ allow: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const [row] = await db
        .update(orgs)
        .set({ allowPublicSignup: input.allow })
        .where(eq(orgs.ownerId, ctx.ownerId))
        .returning();
      if (!row) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Save the organisation details first." });
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "settings",
        entityId: "allowPublicSignup",
        action: "updated",
        summary: `Public signup ${input.allow ? "opened" : "closed"}`,
        after: { allowPublicSignup: input.allow },
      });
      return row;
    }),
});

// ── Change log ───────────────────────────────────────────────────────────────
const changeLogRouter = router({
  list: bookProcedure
    .input(
      z
        .object({
          entity: z.string().optional(),
          limit: z.number().int().min(1).max(500).default(100),
          offset: z.number().int().min(0).default(0),
        })
        .optional(),
    )
    .query(async ({ ctx, input }) => {
      const conds = [eq(changeLog.ownerId, ctx.ownerId)];
      if (input?.entity) conds.push(eq(changeLog.entity, input.entity));
      const rows = await db
        .select()
        .from(changeLog)
        .where(and(...conds))
        .orderBy(desc(changeLog.createdAt))
        .limit(input?.limit ?? 100)
        .offset(input?.offset ?? 0);
      const [count] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(changeLog)
        .where(and(...conds));
      return { rows, total: count?.n ?? 0 };
    }),
});

// ── Full-book export ─────────────────────────────────────────────────────────
/**
 * A restorable archive of the WHOLE book — every table, not a statement.
 *
 * The five report CSVs prove the figures; this is what rebuilds them. It is
 * deliberately a plain JSON document with a version and a checksum, so it can be
 * read by a human and diffed between months.
 *
 * There is NO import/restore procedure: `validate` only re-reads a file and
 * checks it balances. Re-importing is a manual developer job. Do not describe
 * this archive as restorable in the UI.
 */
const BOOK_TABLES = [
  "orgs",
  "opening_balances",
  "cash_accounts",
  "fiscal_periods",
  "activities",
  "members",
  "dues",
  "sponsorship",
  "transactions",
  "journal_entries",
  "journal_lines",
  "evidence",
  "liabilities",
  "assets",
  "reconciliations",
  "reconciliation_items",
  "budgets",
  "budget_lines",
  "change_log",
] as const;

const exportRouter = router({
  /**
   * Build the archive. Returned as a JSON string the client downloads.
   *
   * This is a BACKUP, not a report: it is a restorable copy of every table, and
   * it is the one download that could be used to reconstruct the book elsewhere.
   * The auditor may read and export every report, but a full-book archive is
   * book management — the same tier as the Backup tab that offers it.
   */
  book: writeProcedure.mutation(async ({ ctx }) => {
    const ownerId = ctx.ownerId;
    const data: Record<string, unknown[]> = {};

    for (const table of BOOK_TABLES) {
      const rows = await db.execute(
        sql.raw(`select * from ${table} where owner_id = '${ownerId.replace(/'/g, "''")}'`),
      );
      data[table] = rows.rows as unknown[];
    }

    // The chart of accounts is global reference data, but a restore into a fresh
    // database needs it, so it travels with the book.
    const chart = await db.select().from(accounts).orderBy(asc(accounts.sortOrder));
    data.accounts = chart;

    const [org] = await db.select().from(orgs).where(eq(orgs.ownerId, ownerId)).limit(1);

    const payload = {
      format: "urpsa-book-archive",
      version: 1,
      exportedAt: new Date().toISOString(),
      exportedBy: ctx.user.name ?? ctx.user.email,
      organisation: org ? { legalName: org.legalName, shortName: org.shortName } : null,
      counts: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, v.length])),
      data,
    };

    const json = JSON.stringify(payload, null, 2);
    const checksum = sha256(json);
    return {
      filename: `urpsa-book-${new Date().toISOString().slice(0, 10)}.json`,
      json,
      checksum,
      counts: payload.counts,
      bytes: Buffer.byteLength(json, "utf8"),
    };
  }),

  /**
   * Validate an archive without touching the database.
   *
   * This is what makes the export trustworthy: the treasurer can prove the file
   * they downloaded is complete and internally consistent before they need it.
   */
  validate: bookProcedure
    .input(z.object({ json: z.string().min(2) }))
    .mutation(async ({ input }) => {
      let parsed: any;
      try {
        parsed = JSON.parse(input.json);
      } catch {
        throw new TRPCError({ code: "BAD_REQUEST", message: "That file is not valid JSON." });
      }
      if (parsed?.format !== "urpsa-book-archive") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "That is not a URPSA book archive." });
      }
      const data = parsed.data ?? {};
      const problems: string[] = [];

      // The archive must be internally consistent: every journal entry balanced,
      // every line pointing at an entry that is present.
      const entries: any[] = data.journal_entries ?? [];
      const lines: any[] = data.journal_lines ?? [];
      const entryIds = new Set(entries.map((e) => e.id));
      const unbalanced = entries.filter(
        (e) => Number(e.total_debit) !== Number(e.total_credit),
      );
      if (unbalanced.length > 0) problems.push(`${unbalanced.length} journal entries are unbalanced`);
      const orphans = lines.filter((l) => !entryIds.has(l.entry_id));
      if (orphans.length > 0) problems.push(`${orphans.length} journal lines point at a missing entry`);

      const totalDebit = lines.reduce((s, l) => s + Number(l.debit ?? 0), 0);
      const totalCredit = lines.reduce((s, l) => s + Number(l.credit ?? 0), 0);
      const difference = Math.round((totalDebit - totalCredit) * 100) / 100;
      if (difference !== 0) problems.push(`Journal lines do not balance (difference ${difference})`);

      return {
        ok: problems.length === 0,
        problems,
        counts: parsed.counts ?? {},
        exportedAt: parsed.exportedAt ?? null,
        organisation: parsed.organisation ?? null,
        totalDebit: Math.round(totalDebit * 100) / 100,
        totalCredit: Math.round(totalCredit * 100) / 100,
        difference,
      };
    }),
});

// ── Bank reconciliation ──────────────────────────────────────────────────────
/**
 * Prove the cash book against a bank statement.
 *
 * The arithmetic is the point, so it is computed here rather than in the page:
 *   book balance    = ledger cash for that account up to the statement date
 *   cleared total   = the transactions ticked off
 *   uncleared total = book balance − cleared total (items in transit)
 *   difference      = statement closing balance − book balance
 * Only a zero difference is "reconciled".
 */
const reconciliationRouter = router({
  /** The transactions available to tick off, with their current cleared state. */
  candidates: bookProcedure
    .input(z.object({ cashAccountCode: z.string().min(1), to: z.string().min(10) }))
    .query(async ({ ctx, input }) => {
      const rows = await db
        .select()
        .from(transactions)
        .where(
          and(
            eq(transactions.ownerId, ctx.ownerId),
            eq(transactions.cashAccountCode, input.cashAccountCode),
            lte(transactions.txnDate, input.to),
          ),
        )
        .orderBy(asc(transactions.txnDate), asc(transactions.txnId));

      const bookBalance = await rep.cashTotalForAccount(ctx.ownerId, input.cashAccountCode, input.to);
      return { rows, bookBalance };
    }),

  list: bookProcedure.query(async ({ ctx }) => {
    return db
      .select()
      .from(reconciliations)
      .where(eq(reconciliations.ownerId, ctx.ownerId))
      .orderBy(desc(reconciliations.statementDate), asc(reconciliations.cashAccountCode));
  }),

  get: bookProcedure
    .input(z.object({ id: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const [rec] = await db
        .select()
        .from(reconciliations)
        .where(and(eq(reconciliations.id, input.id), eq(reconciliations.ownerId, ctx.ownerId)))
        .limit(1);
      if (!rec) throw new TRPCError({ code: "NOT_FOUND" });
      const items = await db
        .select()
        .from(reconciliationItems)
        .where(eq(reconciliationItems.reconciliationId, rec.id));
      return { rec, items };
    }),

  /**
   * Save a reconciliation. Re-saving the same account+month replaces it, so a
   * corrected statement does not leave two competing reconciliations.
   */
  save: writeProcedure
    .input(
      z.object({
        cashAccountCode: z.string().min(1),
        statementDate: z.string().min(10),
        statementBalance: z.number(),
        clearedTransactionIds: z.array(z.string().uuid()).default([]),
        notes: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const ownerId = ctx.ownerId;
      const month = `${input.statementDate.slice(0, 7)}-01`;

      const bookBalance = await rep.cashTotalForAccount(ownerId, input.cashAccountCode, input.statementDate);

      // Only transactions that actually belong to this account and date range
      // may be marked cleared — a client cannot clear someone else's row.
      const all = await db
        .select()
        .from(transactions)
        .where(
          and(
            eq(transactions.ownerId, ownerId),
            eq(transactions.cashAccountCode, input.cashAccountCode),
            lte(transactions.txnDate, input.statementDate),
          ),
        );
      const byId = new Map(all.map((t) => [t.id, t]));
      const cleared = input.clearedTransactionIds.filter((id) => byId.has(id));

      const clearedTotal = money(
        cleared.reduce((s, id) => {
          const t = byId.get(id)!;
          const amt = num(t.amount);
          return s + (t.txnType === "Income" ? amt : -amt);
        }, 0),
      );
      const unclearedTotal = money(bookBalance - clearedTotal);
      const difference = money(input.statementBalance - bookBalance);
      const status = difference === 0 ? "reconciled" : "difference";

      const values = {
        ownerId,
        month,
        cashAccountCode: input.cashAccountCode,
        statementDate: input.statementDate,
        statementBalance: money(input.statementBalance).toFixed(2),
        ledgerBalance: bookBalance.toFixed(2),
        clearedTotal: clearedTotal.toFixed(2),
        unclearedTotal: unclearedTotal.toFixed(2),
        difference: difference.toFixed(2),
        clearedCount: cleared.length,
        unclearedCount: all.length - cleared.length,
        reviewedBy: ctx.user.name ?? ctx.user.email,
        status,
        notes: input.notes ?? null,
      };

      const [existing] = await db
        .select()
        .from(reconciliations)
        .where(
          and(
            eq(reconciliations.ownerId, ownerId),
            eq(reconciliations.month, month),
            eq(reconciliations.cashAccountCode, input.cashAccountCode),
          ),
        )
        .limit(1);

      let rec;
      if (existing) {
        [rec] = await db
          .update(reconciliations)
          .set(values)
          .where(eq(reconciliations.id, existing.id))
          .returning();
        await db.delete(reconciliationItems).where(eq(reconciliationItems.reconciliationId, existing.id));
      } else {
        [rec] = await db.insert(reconciliations).values(values).returning();
      }

      if (cleared.length > 0) {
        await db.insert(reconciliationItems).values(
          cleared.map((id) => {
            const t = byId.get(id)!;
            return {
              ownerId,
              reconciliationId: rec.id,
              transactionId: t.id,
              txnId: t.txnId,
              txnDate: t.txnDate,
              amount: t.amount,
              cleared: true,
            };
          }),
        );
      }

      await logChange({
        ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "reconciliation",
        entityId: rec.id,
        action: "posted",
        summary: `Reconciled ${input.cashAccountCode} at ${input.statementDate} — difference ${difference.toFixed(2)}`,
        after: { status, difference, clearedCount: cleared.length },
      });

      return rec;
    }),

  remove: writeProcedure
    .input(z.object({ id: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      const [before] = await db
        .select()
        .from(reconciliations)
        .where(and(eq(reconciliations.id, input.id), eq(reconciliations.ownerId, ctx.ownerId)))
        .limit(1);
      if (!before) throw new TRPCError({ code: "NOT_FOUND" });
      await db.delete(reconciliations).where(eq(reconciliations.id, input.id));
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "reconciliation",
        entityId: input.id,
        action: "deleted",
        summary: `Deleted the ${before.cashAccountCode} reconciliation for ${String(before.month).slice(0, 7)}`,
      });
      return { ok: true };
    }),
});

// ── Org (one row per treasurer) ───────────────────────────────────────────────
const orgRouter = router({
  get: bookProcedure.query(async ({ ctx }) => {
    const [row] = await db.select().from(orgs).where(eq(orgs.ownerId, ctx.ownerId)).limit(1);
    return row ?? null;
  }),

  upsert: writeProcedure
    .input(
      z.object({
        legalName: z.string().min(1, "Your association needs a name"),
        shortName: z.string().optional(),
        institution: z.string().optional(),
        faculty: z.string().optional(),
        initials: z.string().max(4).optional(),
        contactEmail: z.string().optional(),
        contactPhone: z.string().optional(),
        baseCurrency: z.string().default("NGN"),
        periodStart: z.string().min(10),
        periodEnd: z.string().min(10),
        conversionDate: z.string().min(10),
        financialSecretary: z.string().optional(),
        treasurer: z.string().optional(),
        president: z.string().optional(),
        memberIdRule: z.string().optional(),
        capitalisationThreshold: z.number().nonnegative().default(50000),
        evidenceRequiredAbove: z.number().nonnegative().default(5000),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [existing] = await db.select().from(orgs).where(eq(orgs.ownerId, ctx.ownerId)).limit(1);
      const values = {
        legalName: input.legalName,
        shortName: input.shortName ?? null,
        institution: input.institution ?? null,
        faculty: input.faculty ?? null,
        initials: input.initials ?? null,
        contactEmail: input.contactEmail ?? null,
        contactPhone: input.contactPhone ?? null,
        baseCurrency: input.baseCurrency,
        periodStart: input.periodStart,
        periodEnd: input.periodEnd,
        conversionDate: input.conversionDate,
        financialSecretary: input.financialSecretary ?? null,
        treasurer: input.treasurer ?? null,
        president: input.president ?? null,
        memberIdRule: input.memberIdRule ?? null,
        capitalisationThreshold: input.capitalisationThreshold.toFixed(2),
        evidenceRequiredAbove: input.evidenceRequiredAbove.toFixed(2),
      };
      if (existing) {
        const [row] = await db.update(orgs).set(values).where(eq(orgs.ownerId, ctx.ownerId)).returning();
        await logChange({
          ownerId: ctx.ownerId,
          actor: ctx.user, bookRole: ctx.bookRole,
          entity: "settings",
          entityId: row.id,
          action: "updated",
          summary: `Updated organisation details (${row.legalName})`,
          before: { legalName: existing.legalName, shortName: existing.shortName, periodStart: existing.periodStart, periodEnd: existing.periodEnd },
          after: { legalName: row.legalName, shortName: row.shortName, periodStart: row.periodStart, periodEnd: row.periodEnd },
        });
        return row;
      }
      const [row] = await db
        .insert(orgs)
        .values({ ownerId: ctx.ownerId, ...values })
        .returning();
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "settings",
        entityId: row.id,
        action: "created",
        summary: `Set up the organisation (${row.legalName})`,
        after: { legalName: row.legalName },
      });
      return row;
    }),
});

// ── Opening balances ──────────────────────────────────────────────────────────
/**
 * The figures the ledger starts from. Saving posts a real opening journal entry
 * through the posting engine, so the trial balance, balance sheet and cash flow
 * all reconcile from the first naira.
 */
const openingRouter = router({
  get: bookProcedure.query(async ({ ctx }) => {
    const [row] = await db
      .select()
      .from(openingBalances)
      .where(eq(openingBalances.ownerId, ctx.ownerId))
      .limit(1);
    if (!row) return null;
    // The entry may have been removed by a wipe; report what is actually posted.
    let entry: { entryNo: string; entryDate: string; totalDebit: string } | null = null;
    if (row.entryId) {
      const [e] = await db
        .select({
          entryNo: journalEntries.entryNo,
          entryDate: journalEntries.entryDate,
          totalDebit: journalEntries.totalDebit,
        })
        .from(journalEntries)
        .where(and(eq(journalEntries.id, row.entryId), eq(journalEntries.ownerId, ctx.ownerId)))
        .limit(1);
      entry = e ?? null;
    }
    return { ...row, entry };
  }),

  /**
   * Save (or replace) the opening balances.
   *
   * Re-posting REPLACES the previous opening entry — the old one is removed and
   * the corrected one posted — so the book never carries two competing openings.
   */
  save: writeProcedure
    .input(
      z.object({
        bankAmount: z.number().nonnegative(),
        cashAmount: z.number().nonnegative(),
        receivableAmount: z.number().nonnegative().default(0),
        payableAmount: z.number().nonnegative().default(0),
        fundAmount: z.number().nonnegative().default(0),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [org] = await db.select().from(orgs).where(eq(orgs.ownerId, ctx.ownerId)).limit(1);
      if (!org) {
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message: "Save the organisation details first — the opening entry is dated at the start of the year.",
        });
      }
      const [existing] = await db
        .select()
        .from(openingBalances)
        .where(eq(openingBalances.ownerId, ctx.ownerId))
        .limit(1);

      const actor = ctx.user.name ?? ctx.user.email ?? "Treasurer";
      let entry;
      try {
        entry = await postOpeningEntry({
          ownerId: ctx.ownerId,
          entryDate: String(org.periodStart).slice(0, 10),
          bankAmount: input.bankAmount,
          cashAmount: input.cashAmount,
          receivableAmount: input.receivableAmount,
          payableAmount: input.payableAmount,
          fundAmount: input.fundAmount,
          preparedBy: actor,
          replacesEntryId: existing?.entryId ?? null,
        });
      } catch (e) {
        asTrpc(e);
      }

      const values = {
        bankAmount: money(input.bankAmount).toFixed(2),
        cashAmount: money(input.cashAmount).toFixed(2),
        receivableAmount: money(input.receivableAmount).toFixed(2),
        payableAmount: money(input.payableAmount).toFixed(2),
        fundAmount: money(input.fundAmount).toFixed(2),
        entryId: entry!.id,
        postedAt: new Date(),
        updatedAt: new Date(),
      };

      if (existing) {
        await db.update(openingBalances).set(values).where(eq(openingBalances.ownerId, ctx.ownerId));
      } else {
        await db.insert(openingBalances).values({ ownerId: ctx.ownerId, ...values });
      }

      // Keep the cash accounts' own opening figures in step with the entry, so
      // the register and the ledger cannot disagree about what was brought in.
      await db
        .update(cashAccounts)
        .set({ openingBalance: money(input.bankAmount).toFixed(2), openingDate: String(org.periodStart).slice(0, 10) })
        .where(and(eq(cashAccounts.ownerId, ctx.ownerId), eq(cashAccounts.code, "BANK-01")));
      await db
        .update(cashAccounts)
        .set({ openingBalance: money(input.cashAmount).toFixed(2), openingDate: String(org.periodStart).slice(0, 10) })
        .where(and(eq(cashAccounts.ownerId, ctx.ownerId), eq(cashAccounts.code, "CASH-01")));

      return { entryId: entry!.id, entryNo: entry!.entryNo };
    }),
});

// ── Chart of accounts ─────────────────────────────────────────────────────────
const accountsRouter = router({
  list: bookProcedure.query(async () => {
    return db.select().from(accounts).orderBy(asc(accounts.sortOrder));
  }),

  postable: bookProcedure.query(async () => {
    return db
      .select()
      .from(accounts)
      .where(and(eq(accounts.isPostable, true), eq(accounts.isActive, true)))
      .orderBy(asc(accounts.sortOrder));
  }),
});

// ── Cash accounts ─────────────────────────────────────────────────────────────
const cashRouter = router({
  list: bookProcedure.query(async ({ ctx }) => {
    return db
      .select()
      .from(cashAccounts)
      .where(eq(cashAccounts.ownerId, ctx.ownerId))
      .orderBy(asc(cashAccounts.code));
  }),

  upsert: writeProcedure
    .input(
      z.object({
        code: z.string().min(1),
        name: z.string().min(1),
        accountType: z.enum(["bank", "cash"]).default("bank"),
        /** The GL account this cash account posts to. Defaults by type. */
        glAccountCode: z.string().optional(),
        details: z.string().optional(),
        openingBalance: z.number().default(0),
        openingDate: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [existing] = await db
        .select()
        .from(cashAccounts)
        .where(and(eq(cashAccounts.ownerId, ctx.ownerId), eq(cashAccounts.code, input.code)))
        .limit(1);
      const values = {
        name: input.name,
        accountType: input.accountType,
        // Never leave this null on a new row: a null mapping is what let every
        // petty-cash movement post to the bank account.
        glAccountCode:
          input.glAccountCode?.trim() || (input.accountType === "cash" ? "1011" : "1012"),
        details: input.details ?? null,
        openingBalance: input.openingBalance.toFixed(2),
        openingDate: input.openingDate ?? null,
      };
      if (existing) {
        const [row] = await db
          .update(cashAccounts)
          .set(values)
          .where(eq(cashAccounts.id, existing.id))
          .returning();
        return row;
      }
      const [row] = await db
        .insert(cashAccounts)
        .values({ ownerId: ctx.ownerId, code: input.code, ...values })
        .returning();
      return row;
    }),
});

// ── Fiscal periods ────────────────────────────────────────────────────────────
const periodsRouter = router({
  list: bookProcedure.query(async ({ ctx }) => {
    return db
      .select()
      .from(fiscalPeriods)
      .where(eq(fiscalPeriods.ownerId, ctx.ownerId))
      .orderBy(asc(fiscalPeriods.fiscalYear), asc(fiscalPeriods.periodNo));
  }),

  /** Create the 12 monthly periods of an administration year. */
  createYear: writeProcedure
    .input(z.object({ fiscalYear: z.number().int(), periodStart: z.string().min(10) }))
    .mutation(async ({ ctx, input }) => {
      const months = fiscalMonths(input.periodStart);
      const existing = await db
        .select({ n: fiscalPeriods.periodNo })
        .from(fiscalPeriods)
        .where(and(eq(fiscalPeriods.ownerId, ctx.ownerId), eq(fiscalPeriods.fiscalYear, input.fiscalYear)));
      const have = new Set(existing.map((e) => e.n));
      const toInsert = months
        .filter((m) => !have.has(m.no))
        .map((m) => ({
          ownerId: ctx.ownerId,
          fiscalYear: input.fiscalYear,
          periodNo: m.no,
          startDate: m.start,
          endDate: m.end,
          status: "open",
        }));
      if (toInsert.length > 0) await db.insert(fiscalPeriods).values(toInsert);
      return { created: toInsert.length };
    }),

  setStatus: writeProcedure
    .input(z.object({ id: z.string().uuid(), status: z.enum(["future", "open", "closed", "locked"]) }))
    .mutation(async ({ ctx, input }) => {
      const [before] = await db
        .select()
        .from(fiscalPeriods)
        .where(and(eq(fiscalPeriods.id, input.id), eq(fiscalPeriods.ownerId, ctx.ownerId)))
        .limit(1);
      if (!before) throw new TRPCError({ code: "NOT_FOUND" });

      // Closing a period is the year-end control: it must not be possible to
      // close a month that still holds unposted work, and it must be recorded.
      const [row] = await db
        .update(fiscalPeriods)
        .set({ status: input.status })
        .where(eq(fiscalPeriods.id, input.id))
        .returning();

      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "period",
        entityId: row.id,
        action: "updated",
        summary: `Period ${row.fiscalYear}-${String(row.periodNo).padStart(2, "0")} set to ${input.status}`,
        before: { status: before.status },
        after: { status: row.status },
      });
      return row;
    }),

  /**
   * What is in a period, so the treasurer can see what they are closing.
   *
   * Closing a month with postings in it is legitimate — that is what closing
   * means — but closing one blind is not. This returns the count and value of
   * the entries the period holds.
   */
  summary: bookProcedure
    .input(z.object({ id: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const [p] = await db
        .select()
        .from(fiscalPeriods)
        .where(and(eq(fiscalPeriods.id, input.id), eq(fiscalPeriods.ownerId, ctx.ownerId)))
        .limit(1);
      if (!p) throw new TRPCError({ code: "NOT_FOUND" });
      const [row] = await db
        .select({
          entries: sql<number>`count(*)::int`,
          total: sql<string>`coalesce(sum(${journalEntries.totalDebit}),0)`,
        })
        .from(journalEntries)
        .where(
          and(
            eq(journalEntries.ownerId, ctx.ownerId),
            gte(journalEntries.entryDate, p.startDate),
            lte(journalEntries.entryDate, p.endDate),
          ),
        );
      return { period: p, entries: row?.entries ?? 0, total: num(row?.total) };
    }),
});

// ── Activities ────────────────────────────────────────────────────────────────
const activitiesRouter = router({
  list: bookProcedure.query(async ({ ctx }) => {
    return db
      .select()
      .from(activities)
      .where(eq(activities.ownerId, ctx.ownerId))
      .orderBy(asc(activities.code));
  }),

  upsert: writeProcedure
    .input(
      z.object({
        code: z.string().min(1),
        name: z.string().min(1),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
        budgetCategory: z.string().optional(),
        approvedBudget: z.number().default(0),
        approver: z.string().optional(),
        approvalDate: z.string().optional(),
        fundCode: z.string().default("GEN"),
        status: z.enum(["planned", "active", "completed", "cancelled"]).default("planned"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [existing] = await db
        .select()
        .from(activities)
        .where(and(eq(activities.ownerId, ctx.ownerId), eq(activities.code, input.code)))
        .limit(1);
      const values = {
        name: input.name,
        startDate: input.startDate ?? null,
        endDate: input.endDate ?? null,
        budgetCategory: input.budgetCategory ?? null,
        approvedBudget: input.approvedBudget.toFixed(2),
        approver: input.approver ?? null,
        approvalDate: input.approvalDate ?? null,
        fundCode: input.fundCode,
        status: input.status,
      };
      if (existing) {
        const [row] = await db.update(activities).set(values).where(eq(activities.id, existing.id)).returning();
        return row;
      }
      const [row] = await db
        .insert(activities)
        .values({ ownerId: ctx.ownerId, code: input.code, ...values })
        .returning();
      return row;
    }),
});

// ── Members ───────────────────────────────────────────────────────────────────
const membersRouter = router({
  list: bookProcedure
    .input(
      z
        .object({
          search: z.string().optional(),
          status: z.string().optional(),
          includeArchived: z.boolean().optional(),
        })
        .optional(),
    )
    .query(async ({ ctx, input }) => {
      const conds = [eq(members.ownerId, ctx.ownerId)];
      if (!input?.includeArchived) conds.push(sql`${members.archivedAt} is null`);
      if (input?.status) conds.push(eq(members.status, input.status));
      if (input?.search) {
        conds.push(sql`(${members.fullName} ilike ${"%" + input.search + "%"} or ${members.memberId} ilike ${"%" + input.search + "%"})`);
      }
      return db.select().from(members).where(and(...conds)).orderBy(asc(members.memberId));
    }),

  upsert: writeProcedure
    .input(
      z.object({
        memberId: z.string().min(1),
        admissionYear: z.string().optional(),
        matricNumber: z.string().optional(),
        fullName: z.string().min(1),
        level: z.string().optional(),
        phone: z.string().optional(),
        email: z.string().optional(),
        status: z.enum(["active", "inactive", "graduated"]).default("active"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [existing] = await db
        .select()
        .from(members)
        .where(and(eq(members.ownerId, ctx.ownerId), eq(members.memberId, input.memberId)))
        .limit(1);
      const values = {
        admissionYear: input.admissionYear ?? null,
        matricNumber: input.matricNumber ?? null,
        fullName: input.fullName,
        level: input.level ?? null,
        phone: input.phone ?? null,
        email: input.email ?? null,
        status: input.status,
      };
      if (existing) {
        const [row] = await db.update(members).set(values).where(eq(members.id, existing.id)).returning();
        return row;
      }
      const [row] = await db
        .insert(members)
        .values({ ownerId: ctx.ownerId, memberId: input.memberId, ...values })
        .returning();
      return row;
    }),

  /** The next ID in the series — the form shows it before you save. */
  nextId: bookProcedure
    .input(z.object({ admissionYear: z.string().optional() }).optional())
    .query(async ({ ctx, input }) => {
      const year = (input?.admissionYear ?? String(new Date().getFullYear())).slice(0, 4);
      return { memberId: await nextMemberId(ctx.ownerId, year) };
    }),

  create: writeProcedure
    .input(
      z.object({
        fullName: z.string().min(1, "A member needs a name"),
        admissionYear: z.string().optional(),
        matricNumber: z.string().optional(),
        level: z.string().optional(),
        phone: z.string().optional(),
        email: z.string().optional(),
        status: z.enum(["active", "inactive", "graduated"]).default("active"),
        memberId: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const year = (input.admissionYear ?? String(new Date().getFullYear())).slice(0, 4);
      const memberId = (input.memberId?.trim() || (await nextMemberId(ctx.ownerId, year))).toUpperCase();
      assertMemberId(memberId);
      const [dupe] = await db
        .select({ id: members.id })
        .from(members)
        .where(and(eq(members.ownerId, ctx.ownerId), eq(members.memberId, memberId)))
        .limit(1);
      if (dupe) {
        throw new TRPCError({
          code: "CONFLICT",
          message: `Member ID ${memberId} is already taken. Use the next free one.`,
        });
      }
      const [row] = await db
        .insert(members)
        .values({
          ownerId: ctx.ownerId,
          memberId,
          fullName: input.fullName.trim(),
          admissionYear: input.admissionYear ?? year,
          matricNumber: input.matricNumber ?? null,
          level: input.level ?? null,
          phone: input.phone ?? null,
          email: input.email ?? null,
          status: input.status,
        })
        .returning();
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "member",
        entityId: row.id,
        action: "created",
        summary: `Added member ${row.memberId} — ${row.fullName}`,
        after: { memberId: row.memberId, fullName: row.fullName, status: row.status },
      });
      return row;
    }),

  update: writeProcedure
    .input(
      z.object({
        id: z.string().uuid(),
        fullName: z.string().min(1),
        memberId: z.string().min(1),
        admissionYear: z.string().optional(),
        matricNumber: z.string().optional(),
        level: z.string().optional(),
        phone: z.string().optional(),
        email: z.string().optional(),
        status: z.enum(["active", "inactive", "graduated"]),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const memberId = input.memberId.trim().toUpperCase();
      assertMemberId(memberId);
      const [existing] = await db
        .select()
        .from(members)
        .where(and(eq(members.id, input.id), eq(members.ownerId, ctx.ownerId)))
        .limit(1);
      if (!existing) throw new TRPCError({ code: "NOT_FOUND" });
      if (memberId !== existing.memberId) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message:
            "A member ID is the key every transaction and dues record points at — it cannot be changed once issued.",
        });
      }
      const [row] = await db
        .update(members)
        .set({
          fullName: input.fullName.trim(),
          admissionYear: input.admissionYear ?? null,
          matricNumber: input.matricNumber ?? null,
          level: input.level ?? null,
          phone: input.phone ?? null,
          email: input.email ?? null,
          status: input.status,
        })
        .where(eq(members.id, existing.id))
        .returning();
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "member",
        entityId: row.id,
        action: "updated",
        summary: `Edited member ${row.memberId} — ${row.fullName}`,
        before: { fullName: existing.fullName, level: existing.level, status: existing.status, phone: existing.phone },
        after: { fullName: row.fullName, level: row.level, status: row.status, phone: row.phone },
      });
      return row;
    }),

  /** Archive: leaves the active register, keeps every historical reference. */
  archive: writeProcedure
    .input(z.object({ id: z.string().uuid(), archived: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const [row] = await db
        .update(members)
        .set({ archivedAt: input.archived ? new Date() : null, status: input.archived ? "inactive" : "active" })
        .where(and(eq(members.id, input.id), eq(members.ownerId, ctx.ownerId)))
        .returning();
      if (!row) throw new TRPCError({ code: "NOT_FOUND" });
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "member",
        entityId: row.id,
        action: input.archived ? "archived" : "restored",
        summary: `${input.archived ? "Archived" : "Restored"} member ${row.memberId} — ${row.fullName}`,
        after: { archived: input.archived },
      });
      return row;
    }),

  /** Delete is only allowed when nothing in the books points at the member. */
  remove: writeProcedure
    .input(z.object({ id: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      const [m] = await db
        .select()
        .from(members)
        .where(and(eq(members.id, input.id), eq(members.ownerId, ctx.ownerId)))
        .limit(1);
      if (!m) throw new TRPCError({ code: "NOT_FOUND" });
      const [t] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(transactions)
        .where(and(eq(transactions.ownerId, ctx.ownerId), eq(transactions.memberId, m.memberId)));
      const [d] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(dues)
        .where(and(eq(dues.ownerId, ctx.ownerId), eq(dues.memberId, m.memberId)));
      const tn = t?.n ?? 0;
      const dn = d?.n ?? 0;
      if (tn > 0 || dn > 0) {
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message: `${m.fullName} is named on ${tn} transaction(s) and ${dn} dues record(s). Archive them instead — deleting would orphan that history.`,
        });
      }
      await db.delete(members).where(eq(members.id, m.id));
      return { ok: true, memberId: m.memberId };
    }),
});

// ── Dues ──────────────────────────────────────────────────────────────────────
const duesRouter = router({
  list: bookProcedure.query(async ({ ctx }) => {
    return db.select().from(dues).where(eq(dues.ownerId, ctx.ownerId)).orderBy(asc(dues.duesRef));
  }),

  /** Dues with what has actually been collected against each member. */
  collection: bookProcedure.query(async ({ ctx }) => {
    const rows = await db.execute(sql`
      select d.id, d.dues_ref, d.member_id, m.full_name, d.dues_type, d.due_date, d.amount_assessed,
             coalesce((
               select sum(t.amount) from transactions t
               where t.owner_id = d.owner_id and t.member_id = d.member_id
                 and t.txn_type = 'Income' and t.category_code = '4001'
             ), 0) as collected
      from dues d
      left join members m on m.owner_id = d.owner_id and m.member_id = d.member_id
      where d.owner_id = ${ctx.ownerId}
      order by d.dues_ref
    `);
    return (rows.rows as any[]).map((r) => {
      const assessed = money(r.amount_assessed);
      const collected = money(r.collected);
      return {
        id: r.id,
        duesRef: r.dues_ref,
        memberId: r.member_id,
        fullName: r.full_name,
        duesType: r.dues_type,
        dueDate: r.due_date,
        assessed,
        collected,
        outstanding: money(assessed - collected),
      };
    });
  }),

  upsert: writeProcedure
    .input(
      z.object({
        duesRef: z.string().min(1),
        memberId: z.string().min(1),
        duesType: z.string().min(1),
        dueDate: z.string().optional(),
        amountAssessed: z.number().default(0),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [existing] = await db
        .select()
        .from(dues)
        .where(and(eq(dues.ownerId, ctx.ownerId), eq(dues.duesRef, input.duesRef)))
        .limit(1);
      const values = {
        memberId: input.memberId,
        duesType: input.duesType,
        dueDate: input.dueDate ?? null,
        amountAssessed: input.amountAssessed.toFixed(2),
      };
      if (existing) {
        const [row] = await db.update(dues).set(values).where(eq(dues.id, existing.id)).returning();
        return row;
      }
      const [row] = await db
        .insert(dues)
        .values({ ownerId: ctx.ownerId, duesRef: input.duesRef, ...values })
        .returning();
      return row;
    }),

  /** Change what a member is assessed — the collection view recomputes from it. */
  update: writeProcedure
    .input(
      z.object({
        id: z.string().uuid(),
        duesType: z.string().min(1),
        dueDate: z.string().optional(),
        amountAssessed: z.number().nonnegative(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [before] = await db
        .select()
        .from(dues)
        .where(and(eq(dues.id, input.id), eq(dues.ownerId, ctx.ownerId)))
        .limit(1);
      const [row] = await db
        .update(dues)
        .set({
          duesType: input.duesType,
          dueDate: input.dueDate ?? null,
          amountAssessed: input.amountAssessed.toFixed(2),
        })
        .where(and(eq(dues.id, input.id), eq(dues.ownerId, ctx.ownerId)))
        .returning();
      if (!row) throw new TRPCError({ code: "NOT_FOUND" });
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "dues",
        entityId: row.id,
        action: "updated",
        summary: `Edited dues ${row.duesRef} for ${row.memberId} — ${row.duesType} ${row.amountAssessed}`,
        before: before ? { duesType: before.duesType, amountAssessed: before.amountAssessed, dueDate: before.dueDate } : undefined,
        after: { duesType: row.duesType, amountAssessed: row.amountAssessed, dueDate: row.dueDate },
      });
      return row;
    }),

  remove: writeProcedure
    .input(z.object({ id: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      const [row] = await db
        .delete(dues)
        .where(and(eq(dues.id, input.id), eq(dues.ownerId, ctx.ownerId)))
        .returning();
      if (!row) throw new TRPCError({ code: "NOT_FOUND" });
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "dues",
        entityId: row.id,
        action: "deleted",
        summary: `Deleted dues ${row.duesRef} for ${row.memberId}`,
        before: { duesType: row.duesType, amountAssessed: row.amountAssessed },
      });
      return { ok: true };
    }),
});

// ── Sponsorship ───────────────────────────────────────────────────────────────
const sponsorshipRouter = router({
  list: bookProcedure.query(async ({ ctx }) => {
    const rows = await db.execute(sql`
      select s.*, coalesce((
        select sum(t.amount) from transactions t
        where t.owner_id = s.owner_id and t.txn_type = 'Income' and t.category_code = '4002'
          and (t.reference = s.sponsorship_id or t.payee = s.sponsor)
      ), 0) as received
      from sponsorship s
      where s.owner_id = ${ctx.ownerId}
      order by s.sponsorship_id
    `);
    return (rows.rows as any[]).map((r) => ({
      id: r.id,
      sponsorshipId: r.sponsorship_id,
      sponsor: r.sponsor,
      purpose: r.purpose,
      contact: r.contact,
      commitmentDate: r.commitment_date,
      expectedDate: r.expected_date,
      amountPledged: money(r.amount_pledged),
      stage: r.stage,
      restriction: r.restriction ?? "restricted",
      notes: r.notes,
      activityCode: r.activity_code,
      received: money(r.received),
      outstanding: money(money(r.amount_pledged) - money(r.received)),
    }));
  }),

  get: bookProcedure
    .input(z.object({ id: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const [row] = await db
        .select()
        .from(sponsorship)
        .where(and(eq(sponsorship.id, input.id), eq(sponsorship.ownerId, ctx.ownerId)))
        .limit(1);
      if (!row) throw new TRPCError({ code: "NOT_FOUND" });
      const receipts = await db
        .select()
        .from(transactions)
        .where(
          and(
            eq(transactions.ownerId, ctx.ownerId),
            eq(transactions.categoryCode, "4002"),
            sql`(${transactions.reference} = ${row.sponsorshipId} or ${transactions.payee} = ${row.sponsor})`,
          ),
        )
        .orderBy(desc(transactions.txnDate));
      return { pledge: row, receipts };
    }),

  upsert: writeProcedure
    .input(
      z.object({
        /** Omit to create; the next SPT-000N is allocated for you. */
        sponsorshipId: z.string().optional(),
        sponsor: z.string().min(1, "A pledge needs a sponsor"),
        purpose: z.string().optional(),
        contact: z.string().optional(),
        commitmentDate: z.string().optional(),
        expectedDate: z.string().optional(),
        amountPledged: z.number().nonnegative().default(0),
        stage: z
          .enum(["approached", "proposal_sent", "negotiating", "contract_signed", "pledged", "received", "declined"])
          .default("pledged"),
        restriction: z.enum(["unrestricted", "restricted", "designated"]).default("restricted"),
        notes: z.string().optional(),
        activityCode: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const sponsorshipId = (
        input.sponsorshipId?.trim() || (await nextRegisterRef("sponsorship", ctx.ownerId, "SPT"))
      ).toUpperCase();
      const [existing] = await db
        .select()
        .from(sponsorship)
        .where(and(eq(sponsorship.ownerId, ctx.ownerId), eq(sponsorship.sponsorshipId, sponsorshipId)))
        .limit(1);
      const values = {
        sponsor: input.sponsor.trim(),
        purpose: input.purpose ?? null,
        contact: input.contact ?? null,
        commitmentDate: input.commitmentDate ?? null,
        expectedDate: input.expectedDate ?? null,
        amountPledged: input.amountPledged.toFixed(2),
        stage: input.stage,
        restriction: input.restriction,
        notes: input.notes ?? null,
        activityCode: input.activityCode ?? null,
      };
      if (existing) {
        const [row] = await db.update(sponsorship).set(values).where(eq(sponsorship.id, existing.id)).returning();
        await logChange({
          ownerId: ctx.ownerId,
          actor: ctx.user, bookRole: ctx.bookRole,
          entity: "sponsor",
          entityId: row.id,
          action: "updated",
          summary: `Edited pledge ${row.sponsorshipId} — ${row.sponsor}`,
          before: { sponsor: existing.sponsor, amountPledged: existing.amountPledged, stage: existing.stage, restriction: existing.restriction },
          after: { sponsor: row.sponsor, amountPledged: row.amountPledged, stage: row.stage, restriction: row.restriction },
        });
        return row;
      }
      const [row] = await db
        .insert(sponsorship)
        .values({ ownerId: ctx.ownerId, sponsorshipId, ...values })
        .returning();
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "sponsor",
        entityId: row.id,
        action: "created",
        summary: `Added pledge ${row.sponsorshipId} — ${row.sponsor} for ${row.amountPledged}`,
        after: { sponsor: row.sponsor, amountPledged: row.amountPledged, stage: row.stage },
      });
      return row;
    }),

  /**
   * Record a receipt against a pledge. The money moves through the posting
   * engine as sponsorship income (4002) into the chosen cash account, so the
   * pledge total and the ledger can never disagree. The transaction carries the
   * pledge reference, which is how `list`/`get` match receipts back.
   */
  recordReceipt: registerWriteProcedure
    .input(
      z.object({
        id: z.string().uuid(),
        amount: z.number().positive("A receipt must be greater than zero"),
        receivedDate: z.string().min(10),
        cashAccountCode: z.string().min(1),
        reference: z.string().optional(),
        notes: z.string().optional(),
        evidenceIds: z.array(z.string().uuid()).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [pledge] = await db
        .select()
        .from(sponsorship)
        .where(and(eq(sponsorship.id, input.id), eq(sponsorship.ownerId, ctx.ownerId)))
        .limit(1);
      if (!pledge) throw new TRPCError({ code: "NOT_FOUND" });

      const txnId = await nextRef(transactions, transactions.txnId, ctx.ownerId, "TXN");
      const description = `Sponsorship receipt — ${pledge.sponsor}`;

      let entry;
      try {
        entry = await postTransaction({
          ownerId: ctx.ownerId,
          txnType: "Income",
          txnDate: input.receivedDate,
          categoryCode: "4002",
          cashAccountCode: input.cashAccountCode,
          amount: input.amount,
          description,
          activityCode: pledge.activityCode ?? null,
          documentRef: pledge.sponsorshipId,
          preparedBy: ctx.user.name ?? ctx.user.email,
          evidenceIds: input.evidenceIds,
        });
      } catch (e) {
        asTrpc(e);
      }

      const [txn] = await db
        .insert(transactions)
        .values({
          ownerId: ctx.ownerId,
          txnId,
          txnType: "Income",
          txnDate: input.receivedDate,
          categoryCode: "4002",
          cashAccountCode: input.cashAccountCode,
          payee: pledge.sponsor,
          // The pledge reference is what ties this receipt back to the pledge.
          reference: pledge.sponsorshipId,
          amount: input.amount.toFixed(2),
          activityCode: pledge.activityCode ?? null,
          approvalStatus: "Approved",
          approvedBy: ctx.user.name ?? ctx.user.email,
          notes: input.notes ?? input.reference ?? null,
          entryId: entry!.id,
        })
        .returning();

      if (input.evidenceIds?.length) {
        for (const id of input.evidenceIds) {
          await db
            .update(evidence)
            .set({ transactionId: txnId })
            .where(and(eq(evidence.id, id), eq(evidence.ownerId, ctx.ownerId)));
        }
      }

      // Advance the stage once the pledge is fully received.
      const [receivedRow] = await db.execute(sql`
        select coalesce(sum(t.amount),0) as received from transactions t
        where t.owner_id = ${ctx.ownerId} and t.txn_type = 'Income'
          and t.category_code = '4002' and t.reference = ${pledge.sponsorshipId}
      `).then((r) => r.rows as any[]);
      if (money(receivedRow?.received) >= money(pledge.amountPledged) && money(pledge.amountPledged) > 0) {
        await db.update(sponsorship).set({ stage: "received" }).where(eq(sponsorship.id, pledge.id));
      }

      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "sponsor",
        entityId: pledge.id,
        action: "posted",
        summary: `Recorded receipt ${txnId} of ${input.amount.toFixed(2)} against ${pledge.sponsorshipId} — ${pledge.sponsor}`,
        after: { txnId, amount: input.amount.toFixed(2), receivedDate: input.receivedDate },
      });

      return txn;
    }),

  remove: writeProcedure
    .input(z.object({ id: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      const [pledge] = await db
        .select()
        .from(sponsorship)
        .where(and(eq(sponsorship.id, input.id), eq(sponsorship.ownerId, ctx.ownerId)))
        .limit(1);
      if (!pledge) throw new TRPCError({ code: "NOT_FOUND" });
      const [r] = await db.execute(sql`
        select count(*)::int as n from transactions t
        where t.owner_id = ${ctx.ownerId} and t.category_code = '4002'
          and (t.reference = ${pledge.sponsorshipId} or t.payee = ${pledge.sponsor})
      `).then((x) => x.rows as any[]);
      if ((r?.n ?? 0) > 0) {
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message: `${pledge.sponsor} has ${r.n} receipt(s) posted to the ledger. Reverse those transactions first, then the pledge can be deleted.`,
        });
      }
      await db.delete(sponsorship).where(eq(sponsorship.id, pledge.id));
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "sponsor",
        entityId: pledge.id,
        action: "deleted",
        summary: `Deleted pledge ${pledge.sponsorshipId} — ${pledge.sponsor}`,
        before: { sponsor: pledge.sponsor, amountPledged: pledge.amountPledged },
      });
      return { ok: true, sponsorshipId: pledge.sponsorshipId };
    }),
});

// ── Evidence ──────────────────────────────────────────────────────────────────
const evidenceRouter = router({
  list: bookProcedure.query(async ({ ctx }) => {
    return db
      .select()
      .from(evidence)
      .where(eq(evidence.ownerId, ctx.ownerId))
      .orderBy(desc(evidence.createdAt));
  }),

  create: registerWriteProcedure
    .input(
      z.object({
        docType: z.string().default("receipt"),
        description: z.string().optional(),
        storageKey: z.string().optional(),
        filePath: z.string().optional(),
        mimeType: z.string().optional(),
        fileSizeBytes: z.number().optional(),
        transactionId: z.string().optional(),
        submittedBy: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const evidenceId = await nextRef(evidence, evidence.evidenceId, ctx.ownerId, "EV");
      const [created] = await db
        .insert(evidence)
        .values({
          ownerId: ctx.ownerId,
          evidenceId,
          transactionId: input.transactionId ?? null,
          docType: input.docType,
          description: input.description ?? null,
          filePath: input.filePath ?? null,
          storageKey: input.storageKey ?? null,
          mimeType: input.mimeType ?? null,
          fileSizeBytes: input.fileSizeBytes ?? null,
          dateReceived: today(),
          submittedBy: input.submittedBy ?? ctx.user.name ?? ctx.user.email,
          status: "pending",
        })
        .returning();
      return created;
    }),

  setStatus: writeProcedure
    .input(
      z.object({
        id: z.string().uuid(),
        status: z.enum(["pending", "verified", "query", "rejected"]),
        exceptionReason: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [row] = await db
        .update(evidence)
        .set({
          status: input.status,
          exceptionReason: input.exceptionReason ?? null,
          reviewedBy: ctx.user.name ?? ctx.user.email,
        })
        .where(and(eq(evidence.id, input.id), eq(evidence.ownerId, ctx.ownerId)))
        .returning();
      if (!row) throw new TRPCError({ code: "NOT_FOUND" });
      return row;
    }),
});

// ── Transactions (the master register) ────────────────────────────────────────
const transactionsRouter = router({
  /**
   * The register, paged.
   *
   * It used to cap at 200 rows with no way past them, which is not a book — a
   * treasurer with 300 transactions could not see the oldest 100. Now it returns
   * a page plus the total, so the page can offer real pagination.
   */
  list: bookProcedure
    .input(
      z
        .object({
          from: z.string().optional(),
          to: z.string().optional(),
          type: z.enum(["Income", "Expense"]).optional(),
          activityCode: z.string().optional(),
          search: z.string().optional(),
          limit: z.number().int().min(1).max(500).default(50),
          offset: z.number().int().min(0).default(0),
        })
        .optional(),
    )
    .query(async ({ ctx, input }) => {
      const conds = [eq(transactions.ownerId, ctx.ownerId)];
      if (input?.from) conds.push(gte(transactions.txnDate, input.from));
      if (input?.to) conds.push(lte(transactions.txnDate, input.to));
      if (input?.type) conds.push(eq(transactions.txnType, input.type));
      if (input?.activityCode) conds.push(eq(transactions.activityCode, input.activityCode));
      if (input?.search) {
        conds.push(
          sql`(${transactions.payee} ilike ${"%" + input.search + "%"} or ${transactions.reference} ilike ${"%" + input.search + "%"} or ${transactions.txnId} ilike ${"%" + input.search + "%"})`,
        );
      }
      const where = and(...conds);
      const rows = await db
        .select()
        .from(transactions)
        .where(where)
        .orderBy(desc(transactions.txnDate), desc(transactions.txnId))
        .limit(input?.limit ?? 50)
        .offset(input?.offset ?? 0);

      const [count] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(transactions)
        .where(where);

      return {
        rows,
        total: count?.n ?? 0,
        limit: input?.limit ?? 50,
        offset: input?.offset ?? 0,
      };
    }),

  get: bookProcedure
    .input(z.object({ id: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const [txn] = await db
        .select()
        .from(transactions)
        .where(and(eq(transactions.id, input.id), eq(transactions.ownerId, ctx.ownerId)))
        .limit(1);
      if (!txn) throw new TRPCError({ code: "NOT_FOUND" });
      const lines = txn.entryId
        ? await db.select().from(journalLines).where(eq(journalLines.entryId, txn.entryId)).orderBy(asc(journalLines.lineNo))
        : [];
      const [entry] = txn.entryId
        ? await db.select().from(journalEntries).where(eq(journalEntries.id, txn.entryId)).limit(1)
        : [null];
      const docs = await db
        .select()
        .from(evidence)
        .where(and(eq(evidence.ownerId, ctx.ownerId), eq(evidence.transactionId, txn.txnId)));
      return { txn, lines, entry: entry ?? null, evidence: docs };
    }),

  /** Create a transaction AND post its balanced double entry, atomically. */
  create: registerWriteProcedure
    .input(
      z.object({
        txnType: z.enum(["Income", "Expense"]),
        txnDate: z.string().min(10),
        categoryCode: z.string().min(1),
        cashAccountCode: z.string().min(1),
        payee: z.string().optional(),
        memberId: z.string().optional(),
        reference: z.string().optional(),
        amount: z.number().positive("The amount must be greater than zero"),
        activityCode: z.string().optional(),
        notes: z.string().optional(),
        evidenceIds: z.array(z.string().uuid()).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const txnId = await nextRef(transactions, transactions.txnId, ctx.ownerId, "TXN");

      const description =
        input.payee?.trim() ||
        `${input.txnType === "Income" ? "Receipt" : "Payment"} — ${input.categoryCode}`;

      let entry;
      try {
        entry = await postTransaction({
          ownerId: ctx.ownerId,
          txnType: input.txnType,
          txnDate: input.txnDate,
          categoryCode: input.categoryCode,
          cashAccountCode: input.cashAccountCode,
          amount: input.amount,
          description,
          activityCode: input.activityCode ?? null,
          documentRef: input.reference ?? null,
          preparedBy: ctx.user.name ?? ctx.user.email,
          evidenceIds: input.evidenceIds,
        });
      } catch (e) {
        asTrpc(e);
      }

      const [created] = await db
        .insert(transactions)
        .values({
          ownerId: ctx.ownerId,
          txnId,
          txnType: input.txnType,
          txnDate: input.txnDate,
          categoryCode: input.categoryCode,
          cashAccountCode: input.cashAccountCode,
          payee: input.payee ?? null,
          memberId: input.memberId ?? null,
          reference: input.reference ?? null,
          amount: input.amount.toFixed(2),
          activityCode: input.activityCode ?? null,
          approvalStatus: "Approved",
          approvedBy: ctx.user.name ?? ctx.user.email,
          notes: input.notes ?? null,
          entryId: entry!.id,
        })
        .returning();

      // Link any attached evidence to this transaction.
      if (input.evidenceIds && input.evidenceIds.length > 0) {
        for (const id of input.evidenceIds) {
          await db
            .update(evidence)
            .set({ transactionId: txnId })
            .where(and(eq(evidence.id, id), eq(evidence.ownerId, ctx.ownerId)));
        }
      }

      // Attribute the posting. The ledger itself is immutable, but WHO entered a
      // figure is exactly what the treasurer needs when reviewing the book — and
      // it is the only thing that makes an auditor's entries distinguishable from
      // the treasurer's.
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "transaction",
        entityId: created.id,
        action: "posted",
        summary: `Posted ${txnId} — ${input.txnType} ${input.amount.toFixed(2)} ${input.categoryCode}${input.payee ? ` (${input.payee})` : ""}`,
        after: {
          txnId,
          txnType: input.txnType,
          txnDate: input.txnDate,
          categoryCode: input.categoryCode,
          cashAccountCode: input.cashAccountCode,
          amount: input.amount.toFixed(2),
          entryId: entry!.id,
        },
      });

      return created;
    }),

  reverse: writeProcedure
    .input(z.object({ id: z.string().uuid(), reason: z.string().min(1, "Give a reason for the reversal") }))
    .mutation(async ({ ctx, input }) => {
      const [txn] = await db
        .select()
        .from(transactions)
        .where(and(eq(transactions.id, input.id), eq(transactions.ownerId, ctx.ownerId)))
        .limit(1);
      if (!txn) throw new TRPCError({ code: "NOT_FOUND" });
      if (!txn.entryId) throw new TRPCError({ code: "BAD_REQUEST", message: "That transaction has no ledger entry." });
      try {
        const rev = await reverseEntry({
          ownerId: ctx.ownerId,
          entryId: txn.entryId,
          reason: input.reason,
          actor: ctx.user.name ?? ctx.user.email,
        });
        return rev;
      } catch (e) {
        asTrpc(e);
      }
    }),
});

// ── Assets ────────────────────────────────────────────────────────────────────
const assetsRouter = router({
  list: bookProcedure.query(async ({ ctx }) => {
    return db.select().from(assets).where(eq(assets.ownerId, ctx.ownerId)).orderBy(asc(assets.assetId));
  }),

  upsert: registerWriteProcedure
    .input(
      z.object({
        /** Omit to create; the next AST-000N is allocated for you. */
        assetId: z.string().optional(),
        description: z.string().min(1, "An asset needs a description"),
        category: z.string().default("equipment"),
        serial: z.string().optional(),
        custodian: z.string().optional(),
        location: z.string().optional(),
        purchaseDate: z.string().optional(),
        purchaseTxnId: z.string().optional(),
        cost: z.number().nonnegative().default(0),
        condition: z.enum(["new", "good", "fair", "poor"]).default("good"),
        lastVerified: z.string().optional(),
        notes: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const assetId = (
        input.assetId?.trim() || (await nextRegisterRef("assets", ctx.ownerId, "AST"))
      ).toUpperCase();
      const [existing] = await db
        .select()
        .from(assets)
        .where(and(eq(assets.ownerId, ctx.ownerId), eq(assets.assetId, assetId)))
        .limit(1);
      const values = {
        description: input.description.trim(),
        category: input.category,
        serial: input.serial ?? null,
        custodian: input.custodian ?? null,
        location: input.location ?? null,
        purchaseDate: input.purchaseDate ?? null,
        purchaseTxnId: input.purchaseTxnId ?? null,
        cost: input.cost.toFixed(2),
        condition: input.condition,
        lastVerified: input.lastVerified ?? null,
        notes: input.notes ?? null,
      };
      if (existing) {
        const [row] = await db.update(assets).set(values).where(eq(assets.id, existing.id)).returning();
        await logChange({
          ownerId: ctx.ownerId,
          actor: ctx.user, bookRole: ctx.bookRole,
          entity: "asset",
          entityId: row.id,
          action: "updated",
          summary: `Edited asset ${row.assetId} — ${row.description}`,
          before: { description: existing.description, cost: existing.cost, condition: existing.condition, custodian: existing.custodian },
          after: { description: row.description, cost: row.cost, condition: row.condition, custodian: row.custodian },
        });
        return row;
      }
      const [row] = await db
        .insert(assets)
        .values({ ownerId: ctx.ownerId, assetId, ...values })
        .returning();
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "asset",
        entityId: row.id,
        action: "created",
        summary: `Added asset ${row.assetId} — ${row.description} (${row.cost})`,
        after: { description: row.description, cost: row.cost, category: row.category },
      });
      return row;
    }),

  /**
   * Dispose of an asset. The register row is kept (status `disposed`) rather
   * than deleted, and any proceeds are posted to the ledger as other income —
   * so the cash and the register move together.
   */
  dispose: writeProcedure
    .input(
      z.object({
        id: z.string().uuid(),
        disposalDate: z.string().min(10),
        disposalReason: z.string().min(1, "Record why the asset left the register"),
        proceeds: z.number().nonnegative().default(0),
        cashAccountCode: z.string().optional(),
        evidenceIds: z.array(z.string().uuid()).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [asset] = await db
        .select()
        .from(assets)
        .where(and(eq(assets.id, input.id), eq(assets.ownerId, ctx.ownerId)))
        .limit(1);
      if (!asset) throw new TRPCError({ code: "NOT_FOUND" });
      if (asset.status === "disposed") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "That asset has already been disposed of." });
      }

      let entryId: string | null = null;
      if (input.proceeds > 0) {
        if (!input.cashAccountCode) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Choose the account the proceeds were paid into.",
          });
        }
        try {
          const entry = await postTransaction({
            ownerId: ctx.ownerId,
            txnType: "Income",
            txnDate: input.disposalDate,
            categoryCode: "4005",
            cashAccountCode: input.cashAccountCode,
            amount: input.proceeds,
            description: `Disposal proceeds — ${asset.description}`,
            documentRef: asset.assetId,
            preparedBy: ctx.user.name ?? ctx.user.email,
            evidenceIds: input.evidenceIds,
          });
          entryId = entry.id;
        } catch (e) {
          asTrpc(e);
        }
      }

      const [row] = await db
        .update(assets)
        .set({
          status: "disposed",
          disposalDate: input.disposalDate,
          disposalReason: input.disposalReason,
          disposalProceeds: input.proceeds.toFixed(2),
          disposalEntryId: entryId,
        })
        .where(eq(assets.id, asset.id))
        .returning();
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "asset",
        entityId: row.id,
        action: "disposed",
        summary: `Disposed of ${row.assetId} — ${row.description} (proceeds ${row.disposalProceeds ?? "0.00"})`,
        before: { status: asset.status },
        after: { status: "disposed", disposalDate: row.disposalDate, proceeds: row.disposalProceeds },
      });
      return row;
    }),

  remove: writeProcedure
    .input(z.object({ id: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      const [asset] = await db
        .select()
        .from(assets)
        .where(and(eq(assets.id, input.id), eq(assets.ownerId, ctx.ownerId)))
        .limit(1);
      if (!asset) throw new TRPCError({ code: "NOT_FOUND" });
      if (asset.disposalEntryId) {
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message: "This asset has disposal proceeds posted to the ledger. Reverse that transaction before deleting the record.",
        });
      }
      await db.delete(assets).where(eq(assets.id, asset.id));
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "asset",
        entityId: asset.id,
        action: "deleted",
        summary: `Deleted asset ${asset.assetId} — ${asset.description}`,
        before: { description: asset.description, cost: asset.cost },
      });
      return { ok: true, assetId: asset.assetId };
    }),
});

// ── Liabilities ───────────────────────────────────────────────────────────────
const liabilitiesRouter = router({
  list: bookProcedure.query(async ({ ctx }) => {
    return db
      .select()
      .from(liabilities)
      .where(eq(liabilities.ownerId, ctx.ownerId))
      .orderBy(asc(liabilities.liabilityId));
  }),

  upsert: registerWriteProcedure
    .input(
      z.object({
        /** Omit to create; the next LIA-000N is allocated for you. */
        liabilityId: z.string().optional(),
        payee: z.string().min(1, "A commitment needs a payee"),
        description: z.string().optional(),
        activityCode: z.string().optional(),
        dateIncurred: z.string().optional(),
        dueDate: z.string().optional(),
        amountCommitted: z.number().nonnegative().default(0),
        approvalStatus: z.enum(["Approved", "Pending"]).default("Approved"),
        expenseAccountCode: z.string().optional(),
        evidenceIds: z.array(z.string().uuid()).optional(),
        status: z.enum(["outstanding", "settled"]).default("outstanding"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const liabilityId = (
        input.liabilityId?.trim() || (await nextRegisterRef("liabilities", ctx.ownerId, "LIA"))
      ).toUpperCase();
      const [existing] = await db
        .select()
        .from(liabilities)
        .where(and(eq(liabilities.ownerId, ctx.ownerId), eq(liabilities.liabilityId, liabilityId)))
        .limit(1);
      const expenseAccountCode = input.expenseAccountCode || existing?.expenseAccountCode || "5007";
      const values = {
        payee: input.payee.trim(),
        description: input.description ?? null,
        activityCode: input.activityCode ?? null,
        dateIncurred: input.dateIncurred ?? null,
        dueDate: input.dueDate ?? null,
        amountCommitted: input.amountCommitted.toFixed(2),
        approvalStatus: input.approvalStatus,
        expenseAccountCode,
        status: input.status,
      };
      if (existing) {
        const [row] = await db.update(liabilities).set(values).where(eq(liabilities.id, existing.id)).returning();
        await logChange({
          ownerId: ctx.ownerId,
          actor: ctx.user, bookRole: ctx.bookRole,
          entity: "liability",
          entityId: row.id,
          action: "updated",
          summary: `Edited commitment ${row.liabilityId} — ${row.payee}`,
          before: { payee: existing.payee, amountCommitted: existing.amountCommitted, approvalStatus: existing.approvalStatus, dueDate: existing.dueDate },
          after: { payee: row.payee, amountCommitted: row.amountCommitted, approvalStatus: row.approvalStatus, dueDate: row.dueDate },
        });
        return row;
      }
      const [row] = await db
        .insert(liabilities)
        .values({ ownerId: ctx.ownerId, liabilityId, ...values })
        .returning();
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "liability",
        entityId: row.id,
        action: "created",
        summary: `Added commitment ${row.liabilityId} — ${row.payee} (${row.amountCommitted})`,
        after: { payee: row.payee, amountCommitted: row.amountCommitted, approvalStatus: row.approvalStatus },
      });

      // Recognise it in the books at the moment it is recorded. A commitment is
      // money the society owes; until it is accrued it exists only as a memo
      // line, and paying it later would drive the liability account negative.
      // An approved commitment therefore posts Dr expense / Cr 2011 now, and its
      // settlement posts Dr 2011 / Cr cash against it.
      if (input.amountCommitted > 0 && input.approvalStatus === "Approved") {
        const accrualDate = input.dateIncurred ?? new Date().toISOString().slice(0, 10);
        try {
          const entry = await postEntry({
            ownerId: ctx.ownerId,
            entryDate: accrualDate,
            description: `Commitment recognised — ${input.payee.trim()}`,
            documentRef: liabilityId,
            preparedBy: ctx.user.name ?? ctx.user.email,
            evidenceIds: input.evidenceIds,
            lines: [
              {
                accountCode: expenseAccountCode,
                activityCode: input.activityCode ?? undefined,
                debit: input.amountCommitted,
                memo: `Commitment ${liabilityId}`,
              },
              {
                accountCode: "2011",
                credit: input.amountCommitted,
                memo: `Owed to ${input.payee.trim()}`,
              },
            ],
          });
          const [accrued] = await db
            .update(liabilities)
            .set({ accrualEntryId: entry.id })
            .where(eq(liabilities.id, row.id))
            .returning();
          return accrued;
        } catch (e) {
          // A pending approval is a legitimate memo; a failed accrual is not —
          // the row would then be unpayable, so remove it and surface why.
          await db.delete(liabilities).where(eq(liabilities.id, row.id));
          asTrpc(e);
        }
      }
      return row;
    }),

  /** Recognise an existing commitment in the books (Dr expense / Cr 2011). */
  accrue: registerWriteProcedure
    .input(
      z.object({
        id: z.string().uuid(),
        entryDate: z.string().optional(),
        expenseAccountCode: z.string().optional(),
        evidenceIds: z.array(z.string().uuid()).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [lia] = await db
        .select()
        .from(liabilities)
        .where(and(eq(liabilities.id, input.id), eq(liabilities.ownerId, ctx.ownerId)))
        .limit(1);
      if (!lia) throw new TRPCError({ code: "NOT_FOUND" });
      if (lia.accrualEntryId) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "That commitment is already recognised in the books." });
      }
      if (num(lia.amountCommitted) <= 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Set an amount before recognising the commitment." });
      }
      let entry;
      try {
        entry = await postEntry({
          ownerId: ctx.ownerId,
          entryDate: input.entryDate ?? lia.dateIncurred ?? new Date().toISOString().slice(0, 10),
          description: `Commitment recognised — ${lia.payee}`,
          documentRef: lia.liabilityId,
          preparedBy: ctx.user.name ?? ctx.user.email,
          evidenceIds: input.evidenceIds,
          lines: [
            {
              accountCode: input.expenseAccountCode || lia.expenseAccountCode,
              activityCode: lia.activityCode ?? undefined,
              debit: num(lia.amountCommitted),
              memo: `Commitment ${lia.liabilityId}`,
            },
            { accountCode: "2011", credit: num(lia.amountCommitted), memo: `Owed to ${lia.payee}` },
          ],
        });
      } catch (e) {
        asTrpc(e);
      }
      const [row] = await db
        .update(liabilities)
        .set({ accrualEntryId: entry!.id })
        .where(eq(liabilities.id, lia.id))
        .returning();
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "liability",
        entityId: row.id,
        action: "posted",
        summary: `Recognised commitment ${row.liabilityId} — ${row.payee} for ${row.amountCommitted}`,
        after: { accrualEntryId: entry!.id },
      });
      return row;
    }),

  /**
   * Settle a commitment: Dr liabilities (2011) / Cr cash. The liability leaves
   * the balance sheet at the same moment the cash does, through the engine.
   */
  settle: registerWriteProcedure
    .input(
      z.object({
        id: z.string().uuid(),
        settledDate: z.string().min(10),
        amount: z.number().positive("A settlement must be greater than zero"),
        cashAccountCode: z.string().min(1),
        settlementRef: z.string().optional(),
        evidenceIds: z.array(z.string().uuid()).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [lia] = await db
        .select()
        .from(liabilities)
        .where(and(eq(liabilities.id, input.id), eq(liabilities.ownerId, ctx.ownerId)))
        .limit(1);
      if (!lia) throw new TRPCError({ code: "NOT_FOUND" });
      if (lia.status === "settled") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "That commitment is already settled." });
      }
      if (!lia.accrualEntryId) {
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message:
            "This commitment is not recognised in the books yet, so there is nothing on the balance sheet to settle. Recognise it first (Dr expense / Cr liabilities), then record the payment.",
        });
      }
      const committed = num(lia.amountCommitted);
      if (input.amount > committed + 0.005) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `You cannot settle ${input.amount.toFixed(2)} against a commitment of ${committed.toFixed(2)}.`,
        });
      }

      let entry;
      try {
        entry = await postEntry({
          ownerId: ctx.ownerId,
          entryDate: input.settledDate,
          description: `Settlement of ${lia.liabilityId} — ${lia.payee}`,
          documentRef: input.settlementRef ?? lia.liabilityId,
          preparedBy: ctx.user.name ?? ctx.user.email,
          evidenceIds: input.evidenceIds,
          lines: [
            {
              accountCode: "2011",
              debit: input.amount,
              memo: `Clear commitment ${lia.liabilityId}`,
            },
            {
              accountCode: "1012",
              cashAccountCode: input.cashAccountCode,
              credit: input.amount,
              memo: `Paid from ${input.cashAccountCode}`,
            },
          ],
        });
      } catch (e) {
        asTrpc(e);
      }

      const [row] = await db
        .update(liabilities)
        .set({
          status: "settled",
          settledDate: input.settledDate,
          settledAmount: input.amount.toFixed(2),
          settlementEntryId: entry!.id,
          settlementRef: input.settlementRef ?? null,
        })
        .where(eq(liabilities.id, lia.id))
        .returning();
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "liability",
        entityId: row.id,
        action: "settled",
        summary: `Settled commitment ${row.liabilityId} — ${row.payee} for ${row.settledAmount}`,
        before: { status: lia.status },
        after: { status: "settled", settledDate: row.settledDate, settledAmount: row.settledAmount },
      });
      return row;
    }),

  remove: writeProcedure
    .input(z.object({ id: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      const [lia] = await db
        .select()
        .from(liabilities)
        .where(and(eq(liabilities.id, input.id), eq(liabilities.ownerId, ctx.ownerId)))
        .limit(1);
      if (!lia) throw new TRPCError({ code: "NOT_FOUND" });
      if (lia.settlementEntryId) {
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message: "This commitment has a settlement posted to the ledger. Reverse that transaction before deleting the record.",
        });
      }
      await db.delete(liabilities).where(eq(liabilities.id, lia.id));
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "liability",
        entityId: lia.id,
        action: "deleted",
        summary: `Deleted commitment ${lia.liabilityId} — ${lia.payee}`,
        before: { payee: lia.payee, amountCommitted: lia.amountCommitted },
      });
      return { ok: true, liabilityId: lia.liabilityId };
    }),
});

// ── Budgets ───────────────────────────────────────────────────────────────────
const budgetsRouter = router({
  /**
   * Every budget with the size of the plan attached, so the picker can say what
   * each one covers without a second round trip per budget.
   */
  list: bookProcedure.query(async ({ ctx }) => {
    const rows = await db.execute(sql`
      select b.id, b.fiscal_year, b.name, b.version, b.status, b.created_at,
             count(bl.id)::int as line_count,
             coalesce(sum(bl.amount), 0) as total
      from budgets b
      left join budget_lines bl on bl.budget_id = b.id
      where b.owner_id = ${ctx.ownerId}
      group by b.id
      order by b.fiscal_year desc, b.version desc
    `);
    return (rows.rows as any[]).map((r) => ({
      id: r.id,
      fiscalYear: r.fiscal_year,
      name: r.name,
      version: r.version,
      status: r.status,
      createdAt: r.created_at,
      lineCount: r.line_count,
      total: money(r.total),
    }));
  }),

  /**
   * Everything the wizard needs to plan a year, in one call: the organisation's
   * calendar, what may be budgeted, which activities exist, and what last year
   * actually looked like so it can be copied forward.
   */
  wizardContext: bookProcedure
    /** fiscalYear omitted → the server picks the organisation's own next year. */
    .input(z.object({ fiscalYear: z.number().int().optional(), copyFrom: z.string().uuid().optional() }).optional())
    .query(async ({ ctx, input }) => {
      const [org] = await db.select().from(orgs).where(eq(orgs.ownerId, ctx.ownerId)).limit(1);

      // The stored fiscalYear is the year the administration year ENDS in
      // (2026/2027 → 2027). Without an explicit year the wizard opens on NEXT
      // year: the current year's budget already exists, and "build next year's"
      // is the whole point of the wizard.
      const openYear = org ? Number(org.periodEnd.slice(0, 4)) : new Date().getFullYear();
      const fiscalYear = input?.fiscalYear ?? openYear + 1;

      const accts = await db
        .select()
        .from(accounts)
        .where(and(eq(accounts.isPostable, true), eq(accounts.isActive, true)))
        .orderBy(asc(accounts.sortOrder));

      const acts = await db
        .select()
        .from(activities)
        .where(eq(activities.ownerId, ctx.ownerId))
        .orderBy(asc(activities.code));

      const budgetRows = await db.execute(sql`
        select id, fiscal_year, name, version, status
        from budgets where owner_id = ${ctx.ownerId}
        order by fiscal_year desc, version desc
      `);

      // Where to copy from: the budget named, else the most recent one BEFORE
      // the year being planned. Copying from the same year would just duplicate
      // the plan being replaced.
      let sourceId = input?.copyFrom ?? null;
      if (!sourceId) {
        const prior = (budgetRows.rows as any[]).find((b) => b.fiscal_year < fiscalYear);
        sourceId = prior?.id ?? null;
      }

      let sourceLines: any[] = [];
      let sourceName: string | null = null;
      if (sourceId) {
        const src = (budgetRows.rows as any[]).find((b) => b.id === sourceId);
        if (src) {
          sourceName = src.name;
          const rows = await db.execute(sql`
            select bl.account_code, bl.activity_code, bl.period_no, bl.amount,
                   a.name as account_name, a.type as account_type
            from budget_lines bl
            join accounts a on a.code = bl.account_code
            where bl.owner_id = ${ctx.ownerId} and bl.budget_id = ${sourceId}
            order by bl.activity_code nulls first, bl.account_code, bl.period_no
          `);
          sourceLines = (rows.rows as any[]).map((r) => ({
            accountCode: r.account_code,
            accountName: r.account_name,
            kind: r.account_type === "income" ? "income" : "expense",
            activityCode: r.activity_code,
            periodNo: r.period_no,
            amount: money(r.amount),
          }));
        }
      }

      return {
        org: org
          ? {
              legalName: org.legalName,
              shortName: org.shortName,
              periodStart: org.periodStart,
              periodEnd: org.periodEnd,
              baseCurrency: org.baseCurrency,
            }
          : null,
        fiscalYear,
        fiscalYearChoices: fiscalYearChoices(fiscalYear),
        budgets: (budgetRows.rows as any[]).map((b) => ({
          id: b.id,
          fiscalYear: b.fiscal_year,
          name: b.name,
          version: b.version,
          status: b.status,
        })),
        budgetsForYear: (budgetRows.rows as any[])
          .filter((b) => b.fiscal_year === fiscalYear)
          .map((b) => ({ id: b.id, name: b.name, version: b.version, status: b.status })),
        accounts: accts.map((a) => ({
          code: a.code,
          name: a.name,
          type: a.type,
          category: a.category,
        })),
        activities: acts.map((a) => ({
          code: a.code,
          name: a.name,
          startDate: a.startDate,
          endDate: a.endDate,
          budgetCategory: a.budgetCategory,
          fundCode: a.fundCode,
          status: a.status,
        })),
        copySource: sourceId
          ? { id: sourceId, name: sourceName, fiscalYear: (budgetRows.rows as any[]).find((b) => b.id === sourceId)?.fiscal_year ?? null }
          : null,
        copyLines: sourceLines,
      };
    }),

  /**
   * Commit a whole plan at once: any new activities it introduces, the budget
   * header, and every line. Writes land in ONE transaction, so a plan is never
   * half-saved.
   *
   * Budget lines are PLANS, not journal entries: they never reach the posting
   * engine and never touch the ledger. That is exactly why they can be edited
   * and deleted freely without unbalancing anything, and why this procedure
   * takes no evidence — a plan is not a payment.
   */
  commit: writeProcedure
    .input(
      z.object({
        id: z.string().uuid().optional(),
        fiscalYear: z.number().int(),
        name: z.string().min(1, "Give the budget a name"),
        status: z.enum(["draft", "approved", "locked", "superseded"]).default("draft"),
        /** Replace the lines of an existing budget rather than adding to them. */
        replaceExisting: z.boolean().default(false),
        activities: z
          .array(
            z.object({
              code: z.string().min(1),
              name: z.string().min(1),
              startDate: z.string().optional(),
              endDate: z.string().optional(),
              budgetCategory: z.string().optional(),
              fundCode: z.string().default("GEN"),
              status: z.enum(["planned", "active", "completed", "cancelled"]).default("planned"),
            }),
          )
          .default([]),
        lines: z
          .array(
            z.object({
              accountCode: z.string().min(1),
              activityCode: z.string().optional(),
              periodNo: z.number().int().min(0).max(12).default(0),
              amount: z.number().nonnegative("A budget cannot be negative"),
            }),
          )
          .min(1, "A budget needs at least one line"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      // ── Validate against the chart, before writing anything ──
      const accts = await db
        .select()
        .from(accounts)
        .where(and(eq(accounts.isPostable, true), eq(accounts.isActive, true)));
      const acctMap = new Map(accts.map((a) => [a.code, a]));

      for (const l of input.lines) {
        const a = acctMap.get(l.accountCode);
        if (!a) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: `${l.accountCode} is not a postable account, so it cannot be budgeted.`,
          });
        }
        if (a.type !== "income" && a.type !== "expense") {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: `${a.code} ${a.name} is a ${a.type} account — only income and expenditure can be budgeted.`,
          });
        }
      }

      // Every activity a line names must already exist or be in this batch.
      const existingActs = await db
        .select({ code: activities.code })
        .from(activities)
        .where(eq(activities.ownerId, ctx.ownerId));
      const known = new Set([...existingActs.map((a) => a.code), ...input.activities.map((a) => a.code)]);
      for (const l of input.lines) {
        if (l.activityCode && !known.has(l.activityCode)) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: `Activity ${l.activityCode} is not in this plan or the register.`,
          });
        }
      }

      // One line per (activity, account, period): two would be ambiguous to read
      // back and would double-count in the variance.
      const seen = new Set<string>();
      for (const l of input.lines) {
        const k = `${l.activityCode ?? ""}|${l.accountCode}|${l.periodNo}`;
        if (seen.has(k)) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message:
              `${l.accountCode} is listed more than once for ` +
              `${l.activityCode ?? "general spend"} — combine those rows.`,
          });
        }
        seen.add(k);
      }

      // ── Decide the header target ──
      const budgetId = input.id ?? randomUUID();
      const activityIds = input.activities.map((a) => ({ ...a, id: randomUUID() }));
      const isNew = !input.id;

      if (input.id) {
        const [existing] = await db
          .select()
          .from(budgets)
          .where(and(eq(budgets.id, input.id), eq(budgets.ownerId, ctx.ownerId)))
          .limit(1);
        if (!existing) throw new TRPCError({ code: "NOT_FOUND", message: "That budget no longer exists." });
      }

      const headerValues = {
        fiscalYear: input.fiscalYear,
        name: input.name,
        status: input.status,
      };

      const lineValues = input.lines.map((l) => ({
        ownerId: ctx.ownerId,
        budgetId,
        accountCode: l.accountCode,
        activityCode: l.activityCode || null,
        periodNo: l.periodNo,
        amount: l.amount.toFixed(2),
      }));

      // Every statement leaves together: a plan is never half-saved.
      await atomic((d) => {
        const ops: any[] = [];

        // 1. Activities the plan introduces (existing codes are left untouched).
        if (isNew && activityIds.length > 0) {
          ops.push(
            d
              .insert(activities)
              .values(
                activityIds.map((a) => ({
                  id: a.id,
                  ownerId: ctx.ownerId,
                  code: a.code,
                  name: a.name,
                  startDate: a.startDate || null,
                  endDate: a.endDate || null,
                  budgetCategory: a.budgetCategory || null,
                  fundCode: a.fundCode,
                  status: a.status,
                })),
              )
              .onConflictDoNothing({ target: [activities.ownerId, activities.code] }),
          );
        } else if (activityIds.length > 0) {
          // Editing a plan may still add an activity; same conflict rule.
          ops.push(
            d
              .insert(activities)
              .values(
                activityIds.map((a) => ({
                  id: a.id,
                  ownerId: ctx.ownerId,
                  code: a.code,
                  name: a.name,
                  startDate: a.startDate || null,
                  endDate: a.endDate || null,
                  budgetCategory: a.budgetCategory || null,
                  fundCode: a.fundCode,
                  status: a.status,
                })),
              )
              .onConflictDoNothing({ target: [activities.ownerId, activities.code] }),
          );
        }

        // 2. Header.
        if (isNew) {
          ops.push(d.insert(budgets).values({ id: budgetId, ownerId: ctx.ownerId, ...headerValues }).returning());
        } else {
          ops.push(
            d
              .update(budgets)
              .set(headerValues)
              .where(and(eq(budgets.id, budgetId), eq(budgets.ownerId, ctx.ownerId)))
              .returning(),
          );
        }

        // 3. Lines — clear the old plan first when replacing.
        if (!isNew && input.replaceExisting) {
          ops.push(d.delete(budgetLines).where(eq(budgetLines.budgetId, budgetId)));
        }
        ops.push(d.insert(budgetLines).values(lineValues).returning());

        return ops as [any, ...any[]];
      });

      const [saved] = await db
        .select()
        .from(budgets)
        .where(and(eq(budgets.id, budgetId), eq(budgets.ownerId, ctx.ownerId)))
        .limit(1);

      return { budget: saved, lineCount: lineValues.length, created: isNew };
    }),

  /** Rename, re-year or re-status a budget without touching its lines. */
  updateHeader: writeProcedure
    .input(
      z.object({
        id: z.string().uuid(),
        name: z.string().min(1).optional(),
        fiscalYear: z.number().int().optional(),
        status: z.enum(["draft", "approved", "locked", "superseded"]).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [row] = await db
        .update(budgets)
        .set({
          ...(input.name !== undefined ? { name: input.name } : {}),
          ...(input.fiscalYear !== undefined ? { fiscalYear: input.fiscalYear } : {}),
          ...(input.status !== undefined ? { status: input.status } : {}),
        })
        .where(and(eq(budgets.id, input.id), eq(budgets.ownerId, ctx.ownerId)))
        .returning();
      if (!row) throw new TRPCError({ code: "NOT_FOUND" });
      return row;
    }),

  /**
   * Delete a whole budget. Its lines cascade. Nothing in the ledger refers to a
   * budget, so this cannot unbalance the books — the transactions a budget was
   * measuring stay exactly as they were.
   */
  remove: writeProcedure
    .input(z.object({ id: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      const [row] = await db
        .delete(budgets)
        .where(and(eq(budgets.id, input.id), eq(budgets.ownerId, ctx.ownerId)))
        .returning();
      if (!row) throw new TRPCError({ code: "NOT_FOUND" });
      return { ok: true };
    }),

  /**
   * Start next year's plan from an existing one — the common case. Copies the
   * lines into a NEW budget, optionally scaled, and does not touch the source.
   */
  duplicate: writeProcedure
    .input(
      z.object({
        sourceId: z.string().uuid(),
        fiscalYear: z.number().int(),
        name: z.string().min(1),
        upliftPct: z.number().default(0),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const rows = await db.execute(sql`
        select bl.account_code, bl.activity_code, bl.period_no, bl.amount
        from budget_lines bl
        where bl.owner_id = ${ctx.ownerId} and bl.budget_id = ${input.sourceId}
      `);
      if ((rows.rows as any[]).length === 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "That budget has no lines to copy." });
      }

      const budgetId = randomUUID();
      const factor = 1 + (input.upliftPct ?? 0) / 100;
      const lineValues = (rows.rows as any[]).map((r) => ({
        ownerId: ctx.ownerId,
        budgetId,
        accountCode: r.account_code,
        activityCode: r.activity_code,
        periodNo: r.period_no,
        amount: money(money(r.amount) * factor).toFixed(2),
      }));

      await atomic((d) => [
        d
          .insert(budgets)
          .values({
            id: budgetId,
            ownerId: ctx.ownerId,
            fiscalYear: input.fiscalYear,
            name: input.name,
            status: "draft",
          })
          .returning(),
        d.insert(budgetLines).values(lineValues).returning(),
      ]);

      return { id: budgetId, lineCount: lineValues.length };
    }),

  create: writeProcedure
    .input(
      z.object({
        fiscalYear: z.number().int(),
        name: z.string().min(1),
        lines: z
          .array(
            z.object({
              accountCode: z.string().min(1),
              activityCode: z.string().optional(),
              amount: z.number(),
            }),
          )
          .default([]),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const [budget] = await db
        .insert(budgets)
        .values({ ownerId: ctx.ownerId, fiscalYear: input.fiscalYear, name: input.name, status: "approved" })
        .returning();
      if (input.lines.length > 0) {
        await db.insert(budgetLines).values(
          input.lines.map((l) => ({
            ownerId: ctx.ownerId,
            budgetId: budget.id,
            accountCode: l.accountCode,
            activityCode: l.activityCode ?? null,
            periodNo: 0,
            amount: l.amount.toFixed(2),
          })),
        );
      }
      return budget;
    }),

  variance: bookProcedure
    .input(z.object({ budgetId: z.string().uuid(), to: z.string().optional() }))
    .query(async ({ ctx, input }) => {
      return rep.budgetVsActual(ctx.ownerId, input.budgetId, input.to);
    }),

  /**
   * The individual transactions behind ONE budget line.
   *
   * A budget line is (activity, account). So a line's actual spend is the sum of
   * the expense lines of every posted entry that carries that account AND that
   * activity. This returns the transactions themselves so an event can be opened
   * and its own receipts inspected one by one.
   */
  lineDetail: bookProcedure
    .input(
      z.object({
        /** Omit to list every account in the activity (activity-level drill-down). */
        accountCode: z.string().optional(),
        activityCode: z.string().optional(),
        to: z.string().optional(),
      }),
    )
    .query(async ({ ctx, input }) => {
      if (!input.accountCode && !input.activityCode) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Ask for a budget line or an activity — not the whole ledger.",
        });
      }
      const acctJ = input.accountCode ? sql`and jl.account_code = ${input.accountCode}` : sql``;
      const actJ = input.activityCode ? sql`and jl.activity_code = ${input.activityCode}` : sql`and jl.activity_code is null`;
      const acctT = input.accountCode ? sql`and t.category_code = ${input.accountCode}` : sql``;
      const actT = input.activityCode ? sql`and t.activity_code = ${input.activityCode}` : sql`and t.activity_code is null`;
      const toT = input.to ? sql`and t.txn_date <= ${input.to}::date` : sql``;
      const toJ = input.to ? sql`and je.entry_date <= ${input.to}::date` : sql``;

      const rows = await db.execute(sql`
        select t.id, t.txn_id, t.txn_date, t.payee, t.reference, t.amount, t.activity_code,
               t.cash_account_code, t.approval_status, t.category_code, t.notes
        from transactions t
        where t.owner_id = ${ctx.ownerId}
          and t.txn_type = 'Expense'
          ${acctT} ${actT} ${toT}
        order by t.txn_date desc, t.txn_id desc
      `);

      // Cross-check against the journal, so the drill-down can never silently
      // under-report spend that reached the ledger by a non-transaction route.
      const posted = await db.execute(sql`
        select coalesce(sum(jl.debit - jl.credit), 0) as amount, count(*)::int as lines
        from journal_lines jl
        join journal_entries je on je.id = jl.entry_id
        where jl.owner_id = ${ctx.ownerId}
          ${acctJ} ${actJ} ${toJ}
      `);

      const items = (rows.rows as any[]).map((r) => ({
        id: r.id,
        txnId: r.txn_id,
        txnDate: r.txn_date,
        payee: r.payee,
        reference: r.reference,
        amount: money(r.amount),
        cashAccountCode: r.cash_account_code,
        approvalStatus: r.approval_status,
        notes: r.notes,
      }));

      const postedRow = (posted.rows as any[])[0] ?? {};
      const listed = money(items.reduce((s, r) => s + r.amount, 0));
      const ledger = money(postedRow.amount);

      return {
        accountCode: input.accountCode ?? null,
        activityCode: input.activityCode ?? null,
        items,
        count: items.length,
        total: listed,
        /** What the journal says this line actually cost. */
        ledgerTotal: ledger,
        /** Listed receipts vs journal — should always be zero. */
        difference: money(ledger - listed),
      };
    }),

  /** Create a budget line, or update one in place. */
  saveLine: registerWriteProcedure
    .input(
      z.object({
        id: z.string().uuid().optional(),
        budgetId: z.string().uuid().optional(),
        fiscalYear: z.number().int().optional(),
        name: z.string().optional(),
        accountCode: z.string().min(1, "Choose an account"),
        activityCode: z.string().optional(),
        periodNo: z.number().int().min(0).max(12).default(0),
        amount: z.number().nonnegative("A budget cannot be negative"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      // A line needs a budget. If none is named, use this year's, creating it.
      let budgetId = input.budgetId ?? null;
      if (!budgetId) {
        // Fall back to the organisation's own calendar rather than the clock:
        // the fiscalYear is the year the administration year ENDS in.
        const [org] = await db.select().from(orgs).where(eq(orgs.ownerId, ctx.ownerId)).limit(1);
        const year = input.fiscalYear ?? (org ? Number(org.periodEnd.slice(0, 4)) : new Date().getFullYear());
        const [existing] = await db
          .select()
          .from(budgets)
          .where(and(eq(budgets.ownerId, ctx.ownerId), eq(budgets.fiscalYear, year)))
          .limit(1);
        if (existing) {
          budgetId = existing.id;
        } else {
          const [created] = await db
            .insert(budgets)
            .values({
              ownerId: ctx.ownerId,
              fiscalYear: year,
              name: input.name ?? `Budget ${year}`,
              status: "approved",
            })
            .returning();
          budgetId = created.id;
        }
      }

      const [acc] = await db.select().from(accounts).where(eq(accounts.code, input.accountCode)).limit(1);
      if (!acc) throw new TRPCError({ code: "BAD_REQUEST", message: `Account ${input.accountCode} does not exist.` });
      if (!acc.isPostable) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `${acc.code} ${acc.name} is a heading, not a budgetable account.`,
        });
      }
      if (acc.type !== "expense" && acc.type !== "income") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `You can only budget income or expenditure. ${acc.code} is a ${acc.type} account.`,
        });
      }

      if (input.activityCode) {
        const [act] = await db
          .select({ id: activities.id })
          .from(activities)
          .where(and(eq(activities.ownerId, ctx.ownerId), eq(activities.code, input.activityCode)))
          .limit(1);
        if (!act) {
          throw new TRPCError({ code: "BAD_REQUEST", message: `Activity ${input.activityCode} does not exist.` });
        }
      }

      const values = {
        accountCode: input.accountCode,
        activityCode: input.activityCode || null,
        periodNo: input.periodNo,
        amount: input.amount.toFixed(2),
      };

      if (input.id) {
        const [before] = await db
          .select()
          .from(budgetLines)
          .where(and(eq(budgetLines.id, input.id), eq(budgetLines.ownerId, ctx.ownerId)))
          .limit(1);
        const [row] = await db
          .update(budgetLines)
          .set(values)
          .where(and(eq(budgetLines.id, input.id), eq(budgetLines.ownerId, ctx.ownerId)))
          .returning();
        if (!row) throw new TRPCError({ code: "NOT_FOUND" });
        await logChange({
          ownerId: ctx.ownerId,
          actor: ctx.user, bookRole: ctx.bookRole,
          entity: "budget_line",
          entityId: row.id,
          action: "updated",
          summary: `Edited budget line ${row.accountCode}${row.activityCode ? ` / ${row.activityCode}` : ""} to ${row.amount}`,
          before: before ? { accountCode: before.accountCode, amount: before.amount, periodNo: before.periodNo } : undefined,
          after: { accountCode: row.accountCode, amount: row.amount, periodNo: row.periodNo },
        });
        return row;
      }

      const [row] = await db
        .insert(budgetLines)
        .values({ ownerId: ctx.ownerId, budgetId: budgetId!, ...values })
        .returning();
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "budget_line",
        entityId: row.id,
        action: "created",
        summary: `Added budget line ${row.accountCode}${row.activityCode ? ` / ${row.activityCode}` : ""} for ${row.amount}`,
        after: { accountCode: row.accountCode, amount: row.amount, periodNo: row.periodNo },
      });
      return row;
    }),

  deleteLine: writeProcedure
    .input(z.object({ id: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      const [row] = await db
        .delete(budgetLines)
        .where(and(eq(budgetLines.id, input.id), eq(budgetLines.ownerId, ctx.ownerId)))
        .returning();
      if (!row) throw new TRPCError({ code: "NOT_FOUND" });
      await logChange({
        ownerId: ctx.ownerId,
        actor: ctx.user, bookRole: ctx.bookRole,
        entity: "budget_line",
        entityId: row.id,
        action: "deleted",
        summary: `Deleted budget line ${row.accountCode}${row.activityCode ? ` / ${row.activityCode}` : ""} (${row.amount})`,
        before: { accountCode: row.accountCode, amount: row.amount, periodNo: row.periodNo },
      });
      return { ok: true };
    }),

  /** The raw lines of a budget, for the editor (variance is the read view). */
  lines: bookProcedure
    .input(z.object({ budgetId: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const rows = await db.execute(sql`
        select bl.id, bl.account_code, a.name as account_name, a.type as account_type,
               bl.activity_code, bl.period_no, bl.amount
        from budget_lines bl
        join accounts a on a.code = bl.account_code
        where bl.owner_id = ${ctx.ownerId} and bl.budget_id = ${input.budgetId}
        order by bl.activity_code nulls first, bl.account_code
      `);
      return (rows.rows as any[]).map((r) => ({
        id: r.id,
        accountCode: r.account_code,
        accountName: r.account_name,
        accountType: r.account_type,
        activityCode: r.activity_code,
        periodNo: r.period_no,
        amount: money(r.amount),
      }));
    }),
});

// ── Reports ───────────────────────────────────────────────────────────────────
const reportsRouter = router({
  incomeAndExpenditure: bookProcedure
    .input(z.object({ from: z.string().optional(), to: z.string().optional() }).optional())
    .query(async ({ ctx, input }) => rep.incomeAndExpenditure(ctx.ownerId, input?.from, input?.to)),

  financialPosition: bookProcedure
    .input(z.object({ to: z.string().optional() }).optional())
    .query(async ({ ctx, input }) => rep.financialPosition(ctx.ownerId, input?.to)),

  cashFlow: bookProcedure
    .input(z.object({ from: z.string().optional(), to: z.string().optional() }).optional())
    .query(async ({ ctx, input }) => rep.cashFlow(ctx.ownerId, input?.from, input?.to)),

  trialBalance: bookProcedure
    .input(z.object({ to: z.string().optional() }).optional())
    .query(async ({ ctx, input }) => rep.trialBalance(ctx.ownerId, input?.to)),

  controlChecks: bookProcedure
    .input(z.object({ to: z.string().optional() }).optional())
    .query(async ({ ctx, input }) => rep.controlChecks(ctx.ownerId, input?.to)),

  accountBalances: bookProcedure
    .input(z.object({ from: z.string().optional(), to: z.string().optional() }).optional())
    .query(async ({ ctx, input }) => rep.accountBalances(ctx.ownerId, input?.from, input?.to)),
});

// ── Dashboard ─────────────────────────────────────────────────────────────────
const dashboardRouter = router({
  summary: bookProcedure.query(async ({ ctx }) => {
    const ownerId = ctx.ownerId;
    const [org] = await db.select().from(orgs).where(eq(orgs.ownerId, ownerId)).limit(1);
    const from = org ? String(org.periodStart) : undefined;
    const to = org ? String(org.periodEnd) : undefined;

    const ie = await rep.incomeAndExpenditure(ownerId, from, to);
    const cash = await rep.cashTotal(ownerId, undefined, to);
    const pos = await rep.financialPosition(ownerId, to);
    const checks = await rep.controlChecks(ownerId, to);

    const [txnCount] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(transactions)
      .where(eq(transactions.ownerId, ownerId));

    // Monthly income / expenditure for the trend strip.
    const monthly = await db.execute(sql`
      select to_char(je.entry_date, 'YYYY-MM') as ym,
             sum(case when a.type = 'income' then jl.credit - jl.debit else 0 end) as income,
             sum(case when a.type = 'expense' then jl.debit - jl.credit else 0 end) as expense
      from journal_lines jl
      join journal_entries je on je.id = jl.entry_id
      join accounts a on a.code = jl.account_code
      where jl.owner_id = ${ownerId}
      group by 1 order by 1
    `);

    const byCategory = await db.execute(sql`
      select a.code, a.name, a.type, sum(jl.debit - jl.credit) as net
      from journal_lines jl
      join accounts a on a.code = jl.account_code
      where jl.owner_id = ${ownerId} and a.type in ('income','expense')
      group by a.code, a.name, a.type
      order by a.code
    `);

    const recent = await db
      .select()
      .from(transactions)
      .where(eq(transactions.ownerId, ownerId))
      .orderBy(desc(transactions.txnDate), desc(transactions.txnId))
      .limit(8);

    return {
      org: org ?? null,
      income: ie.totalIncome,
      expenditure: ie.totalExpenditure,
      surplus: ie.surplus,
      cash,
      totalAssets: pos.totalAssets,
      totalLiabilities: pos.totalLiabilities,
      totalFunds: pos.totalFunds,
      txnCount: txnCount?.n ?? 0,
      checks,
      monthly: (monthly.rows as any[]).map((r) => ({
        ym: r.ym,
        income: money(r.income),
        expense: money(r.expense),
      })),
      byCategory: (byCategory.rows as any[]).map((r) => ({
        code: r.code,
        name: r.name,
        type: r.type,
        net: money(r.net),
      })),
      recent,
    };
  }),
});

// ── Files (evidence upload) ───────────────────────────────────────────────────
const filesRouter = router({
  uploadUrl: writeProcedure
    .input(z.object({ name: z.string().min(1), contentType: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const key = `${crypto.randomUUID()}-${sanitizeBasename(input.name)}`;
      try {
        const { uploadUrl, publicPath } = await storagePutUrl(key, input.contentType, {
          ownerId: ctx.ownerId,
        });
        return { key, uploadUrl, publicPath };
      } catch (e) {
        if (e instanceof StorageError && e.code === "failed") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "That file type is not accepted." });
        }
        throw e;
      }
    }),

  commit: writeProcedure
    .input(z.object({ key: z.string().min(1), name: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      try {
        return await storageCommit(input.key, { ownerId: ctx.ownerId, name: input.name });
      } catch (e) {
        if (e instanceof StorageError && e.code === "not_found") {
          throw new TRPCError({ code: "NOT_FOUND", message: "upload not found — did the PUT succeed?" });
        }
        if (e instanceof StorageError && e.code === "forbidden") {
          throw new TRPCError({ code: "FORBIDDEN", message: "that key belongs to another user" });
        }
        throw e;
      }
    }),

  list: bookProcedure.query(({ ctx }) => storageListByOwner(ctx.ownerId)),

  remove: writeProcedure
    .input(z.object({ key: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      try {
        return await storageDeleteOwned(ctx.ownerId, input.key);
      } catch (e) {
        if (e instanceof StorageError && e.code === "forbidden") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "malformed key" });
        }
        throw e;
      }
    }),
});

export function sanitizeBasename(name: string): string {
  const last = name.split(/[/\\]/).pop() ?? "";
  const dot = last.lastIndexOf(".");
  const rawStem = dot > 0 ? last.slice(0, dot) : last;
  const rawExt = dot > 0 ? last.slice(dot + 1) : "";
  const stem = rawStem.replace(/[^A-Za-z0-9._-]/g, "").replace(/^\.+/, "") || "upload";
  const ext = rawExt.replace(/[^A-Za-z0-9]/g, "").slice(0, 10);
  return ext ? `${stem}.${ext}` : stem;
}

export const appRouter = router({
  auth: authRouter,
  access: accessRouter,
  changeLog: changeLogRouter,
  export: exportRouter,
  reconciliation: reconciliationRouter,
  org: orgRouter,
  opening: openingRouter,
  accounts: accountsRouter,
  cash: cashRouter,
  periods: periodsRouter,
  activities: activitiesRouter,
  members: membersRouter,
  dues: duesRouter,
  sponsorship: sponsorshipRouter,
  evidence: evidenceRouter,
  transactions: transactionsRouter,
  assets: assetsRouter,
  liabilities: liabilitiesRouter,
  budgets: budgetsRouter,
  reports: reportsRouter,
  dashboard: dashboardRouter,
  files: filesRouter,
});

export type AppRouter = typeof appRouter;
