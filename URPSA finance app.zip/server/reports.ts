// ──────────────────────────────────────────────────────────────────────────────
// THE REPORTS ENGINE — every figure derives from journal_lines.
//
// Nothing here reads a stored balance. Each statement aggregates the posted
// double entry, so a report can never drift from the ledger. The control checks
// at the bottom are the same identities the workbook's "Error Checks" sheet
// asserts, computed rather than typed.
// ──────────────────────────────────────────────────────────────────────────────
import { and, eq, sql } from "drizzle-orm";
import { db } from "./_core/db";
import { accounts, journalEntries, journalLines } from "../drizzle/schema";
import { money, num } from "../shared/finance";

export interface AccountBalance {
  code: string;
  name: string;
  type: string;
  reportGroup: string | null;
  debit: number;
  credit: number;
  /** Signed balance in the account's natural direction. */
  balance: number;
}

/** Every postable account with its period movement, from journal_lines. */
export async function accountBalances(
  ownerId: string,
  from?: string,
  to?: string,
): Promise<AccountBalance[]> {
  const conds = [eq(journalLines.ownerId, ownerId)];
  if (from) conds.push(sql`${journalEntries.entryDate} >= ${from}::date`);
  if (to) conds.push(sql`${journalEntries.entryDate} <= ${to}::date`);

  const rows = await db
    .select({
      code: journalLines.accountCode,
      name: accounts.name,
      type: accounts.type,
      reportGroup: accounts.reportGroup,
      debit: sql<string>`sum(${journalLines.debit})`,
      credit: sql<string>`sum(${journalLines.credit})`,
    })
    .from(journalLines)
    .innerJoin(journalEntries, eq(journalLines.entryId, journalEntries.id))
    .innerJoin(accounts, eq(journalLines.accountCode, accounts.code))
    .where(and(...conds))
    .groupBy(journalLines.accountCode, accounts.name, accounts.type, accounts.reportGroup)
    .orderBy(journalLines.accountCode);

  return rows.map((r) => {
    const debit = money(r.debit);
    const credit = money(r.credit);
    // Assets/expenses are debit-natural; everything else credit-natural.
    const debitNatural = r.type === "asset" || r.type === "expense";
    return {
      code: r.code,
      name: r.name,
      type: r.type,
      reportGroup: r.reportGroup,
      debit,
      credit,
      balance: money(debitNatural ? debit - credit : credit - debit),
    };
  });
}

/** Cash movement per cash account, from the lines that carry a cash account. */
export async function cashBalances(ownerId: string, to?: string) {
  const conds = [eq(journalLines.ownerId, ownerId), sql`${journalLines.cashAccountCode} is not null`];
  if (to) conds.push(sql`${journalEntries.entryDate} <= ${to}::date`);
  const rows = await db
    .select({
      code: journalLines.cashAccountCode,
      debit: sql<string>`sum(${journalLines.debit})`,
      credit: sql<string>`sum(${journalLines.credit})`,
    })
    .from(journalLines)
    .innerJoin(journalEntries, eq(journalLines.entryId, journalEntries.id))
    .where(and(...conds))
    .groupBy(journalLines.cashAccountCode)
    .orderBy(journalLines.cashAccountCode);
  return rows.map((r) => ({
    code: r.code as string,
    debit: money(r.debit),
    credit: money(r.credit),
    balance: money(num(r.debit) - num(r.credit)),
  }));
}

// ── Income & Expenditure ─────────────────────────────────────────────────────
export interface IEStatement {
  income: { code: string; name: string; amount: number }[];
  expenditure: { code: string; name: string; amount: number }[];
  totalIncome: number;
  totalExpenditure: number;
  surplus: number;
}

export async function incomeAndExpenditure(
  ownerId: string,
  from?: string,
  to?: string,
): Promise<IEStatement> {
  const bals = await accountBalances(ownerId, from, to);
  const income = bals
    .filter((b) => b.type === "income" && b.balance !== 0)
    .map((b) => ({ code: b.code, name: b.name, amount: b.balance }));
  const expenditure = bals
    .filter((b) => b.type === "expense" && b.balance !== 0)
    .map((b) => ({ code: b.code, name: b.name, amount: b.balance }));
  const totalIncome = money(income.reduce((s, r) => s + r.amount, 0));
  const totalExpenditure = money(expenditure.reduce((s, r) => s + r.amount, 0));
  return {
    income,
    expenditure,
    totalIncome,
    totalExpenditure,
    surplus: money(totalIncome - totalExpenditure),
  };
}

// ── Statement of Financial Position ──────────────────────────────────────────
export interface PositionStatement {
  assets: { code: string; name: string; amount: number }[];
  liabilities: { code: string; name: string; amount: number }[];
  funds: { code: string; name: string; amount: number }[];
  totalAssets: number;
  totalLiabilities: number;
  totalFunds: number;
  /** Accumulated surplus not yet closed to the fund account. */
  currentSurplus: number;
  difference: number;
}

export async function financialPosition(ownerId: string, to?: string): Promise<PositionStatement> {
  const bals = await accountBalances(ownerId, undefined, to);
  const assets = bals
    .filter((b) => b.type === "asset" && b.balance !== 0)
    .map((b) => ({ code: b.code, name: b.name, amount: b.balance }));
  const liabilities = bals
    .filter((b) => b.type === "liability" && b.balance !== 0)
    .map((b) => ({ code: b.code, name: b.name, amount: b.balance }));
  const funds = bals
    .filter((b) => b.type === "equity" && b.balance !== 0)
    .map((b) => ({ code: b.code, name: b.name, amount: b.balance }));

  const totalAssets = money(assets.reduce((s, r) => s + r.amount, 0));
  const totalLiabilities = money(liabilities.reduce((s, r) => s + r.amount, 0));
  const totalFunds = money(funds.reduce((s, r) => s + r.amount, 0));

  // Income less expenditure to date — the period result the fund account has
  // not yet absorbed. It belongs to funds, so the identity closes.
  const ie = await incomeAndExpenditure(ownerId, undefined, to);
  const currentSurplus = ie.surplus;

  const difference = money(totalAssets - (totalLiabilities + totalFunds + currentSurplus));
  return {
    assets,
    liabilities,
    funds,
    totalAssets,
    totalLiabilities,
    totalFunds,
    currentSurplus,
    difference,
  };
}

// ── Cash Flow ────────────────────────────────────────────────────────────────
export interface CashFlowStatement {
  operating: number;
  investing: number;
  financing: number;
  netMovement: number;
  openingCash: number;
  closingCash: number;
  difference: number;
  lines: { label: string; amount: number; cls: string }[];
}

/**
 * Cash flow, classified by the COUNTERPARTY account's cash_flow_class — never
 * by the cash account's own class (which is always "operating" and would file
 * every purchase as operating).
 */
export async function cashFlow(ownerId: string, from?: string, to?: string): Promise<CashFlowStatement> {
  const dateConds = [eq(journalLines.ownerId, ownerId)];
  if (from) dateConds.push(sql`${journalEntries.entryDate} >= ${from}::date`);
  if (to) dateConds.push(sql`${journalEntries.entryDate} <= ${to}::date`);

  // Fetch EVERY line of every entry that touches cash — not just the cash lines.
  // Filtering to cash lines alone would hide the counterparty, and the
  // classification would collapse to the cash account's own class (always
  // "operating"), filing every purchase as operating.
  const rows = await db
    .select({
      entryId: journalLines.entryId,
      accountCode: journalLines.accountCode,
      cashAccountCode: journalLines.cashAccountCode,
      debit: journalLines.debit,
      credit: journalLines.credit,
      cls: accounts.cashFlowClass,
      name: accounts.name,
    })
    .from(journalLines)
    .innerJoin(journalEntries, eq(journalLines.entryId, journalEntries.id))
    .innerJoin(accounts, eq(journalLines.accountCode, accounts.code))
    .where(
      and(
        ...dateConds,
        sql`${journalLines.entryId} in (
          select distinct entry_id from journal_lines
          where owner_id = ${ownerId} and cash_account_code is not null
        )`,
      ),
    );

  const byEntry = new Map<string, typeof rows>();
  for (const r of rows) {
    const list = byEntry.get(r.entryId) ?? [];
    list.push(r);
    byEntry.set(r.entryId, list);
  }

  const buckets: Record<string, number> = { operating: 0, investing: 0, financing: 0 };
  const detail: { label: string; amount: number; cls: string }[] = [];

  for (const [, lines] of byEntry) {
    const cashLines = lines.filter((l) => l.cashAccountCode);
    const otherLines = lines.filter((l) => !l.cashAccountCode);
    const cashMovement = money(
      cashLines.reduce((s, l) => s + num(l.debit) - num(l.credit), 0),
    );
    if (cashMovement === 0) continue;
    // Classify by the counterparty: the largest non-cash line decides.
    const driver = otherLines
      .slice()
      .sort((a, b) => Math.abs(num(b.debit) - num(b.credit)) - Math.abs(num(a.debit) - num(a.credit)))[0];
    const cls = driver?.cls && driver.cls !== "none" ? driver.cls : "operating";
    buckets[cls] = money((buckets[cls] ?? 0) + cashMovement);
    detail.push({
      label: driver?.name ?? "Cash movement",
      amount: cashMovement,
      cls,
    });
  }

  const operating = money(buckets.operating ?? 0);
  const investing = money(buckets.investing ?? 0);
  const financing = money(buckets.financing ?? 0);
  const netMovement = money(operating + investing + financing);

  // Opening cash = everything before `from`; closing = everything to `to`.
  const openingCash = from ? await cashTotal(ownerId, undefined, prevDay(from)) : 0;
  const closingCash = await cashTotal(ownerId, undefined, to);
  const difference = money(openingCash + netMovement - closingCash);

  return {
    operating,
    investing,
    financing,
    netMovement,
    openingCash,
    closingCash,
    difference,
    lines: detail,
  };
}

function prevDay(d: string): string {
  const dt = new Date(d + "T00:00:00Z");
  dt.setUTCDate(dt.getUTCDate() - 1);
  return dt.toISOString().slice(0, 10);
}

/** Total cash on hand at a date, from the cash-carrying lines. */
export async function cashTotal(ownerId: string, from?: string, to?: string): Promise<number> {
  const conds = [eq(journalLines.ownerId, ownerId), sql`${journalLines.cashAccountCode} is not null`];
  if (from) conds.push(sql`${journalEntries.entryDate} >= ${from}::date`);
  if (to) conds.push(sql`${journalEntries.entryDate} <= ${to}::date`);
  const [row] = await db
    .select({
      d: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
      c: sql<string>`coalesce(sum(${journalLines.credit}),0)`,
    })
    .from(journalLines)
    .innerJoin(journalEntries, eq(journalLines.entryId, journalEntries.id))
    .where(and(...conds));
  return money(num(row?.d) - num(row?.c));
}

/**
 * The book balance of ONE cash account at a date.
 *
 * This is the figure a bank reconciliation proves: what the ledger says is in
 * that account, not the total across every cash account. Summing all of them
 * would make a bank statement impossible to reconcile against.
 */
export async function cashTotalForAccount(
  ownerId: string,
  cashAccountCode: string,
  to?: string,
): Promise<number> {
  const conds = [
    eq(journalLines.ownerId, ownerId),
    eq(journalLines.cashAccountCode, cashAccountCode),
  ];
  if (to) conds.push(sql`${journalEntries.entryDate} <= ${to}::date`);
  const [row] = await db
    .select({
      d: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
      c: sql<string>`coalesce(sum(${journalLines.credit}),0)`,
    })
    .from(journalLines)
    .innerJoin(journalEntries, eq(journalLines.entryId, journalEntries.id))
    .where(and(...conds));
  return money(num(row?.d) - num(row?.c));
}

// ── Trial Balance ────────────────────────────────────────────────────────────
export interface TrialBalance {
  rows: { code: string; name: string; debit: number; credit: number }[];
  totalDebit: number;
  totalCredit: number;
  difference: number;
}

export async function trialBalance(ownerId: string, to?: string): Promise<TrialBalance> {
  const bals = await accountBalances(ownerId, undefined, to);
  const rows = bals
    .filter((b) => b.debit !== 0 || b.credit !== 0)
    .map((b) => ({ code: b.code, name: b.name, debit: b.debit, credit: b.credit }));
  const totalDebit = money(rows.reduce((s, r) => s + r.debit, 0));
  const totalCredit = money(rows.reduce((s, r) => s + r.credit, 0));
  return { rows, totalDebit, totalCredit, difference: money(totalDebit - totalCredit) };
}

// ── Control Checks ───────────────────────────────────────────────────────────
export interface ControlCheck {
  name: string;
  detail: string;
  value: number;
  pass: boolean;
}

export async function controlChecks(ownerId: string, to?: string): Promise<ControlCheck[]> {
  const tb = await trialBalance(ownerId, to);
  const pos = await financialPosition(ownerId, to);
  const cf = await cashFlow(ownerId, undefined, to);

  // Every entry must be internally balanced.
  const [unbalanced] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(journalEntries)
    .where(
      and(
        eq(journalEntries.ownerId, ownerId),
        sql`${journalEntries.totalDebit} <> ${journalEntries.totalCredit}`,
      ),
    );

  // No line may be both a debit and a credit, or neither.
  const [badLines] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(journalLines)
    .where(
      and(
        eq(journalLines.ownerId, ownerId),
        sql`((${journalLines.debit} > 0 and ${journalLines.credit} > 0) or (${journalLines.debit} = 0 and ${journalLines.credit} = 0))`,
      ),
    );

  // Cash on the balance sheet must equal cash in the cash accounts.
  //
  // Sum the accounts FLAGGED as cash, never every 101x code: 1013 Receivable is
  // an asset but not cash, and a prefix test would count money owed to the
  // association as money in the bank — the check would then fail on a perfectly
  // correct ledger the moment an opening receivable exists.
  const cashFromLines = await cashTotal(ownerId, undefined, to);
  const cashAccountRows = await db
    .select({ code: accounts.code })
    .from(accounts)
    .where(eq(accounts.isCash, true));
  const cashCodes = new Set(cashAccountRows.map((a) => a.code));
  const cashOnSheet = money(
    pos.assets.filter((a) => cashCodes.has(a.code)).reduce((s, a) => s + a.amount, 0),
  );

  return [
    {
      name: "Trial balance balances",
      detail: `Debits ${tb.totalDebit.toFixed(2)} = credits ${tb.totalCredit.toFixed(2)}`,
      value: tb.difference,
      pass: tb.difference === 0,
    },
    {
      name: "Balance sheet identity",
      detail: `Assets = liabilities + funds + period result`,
      value: pos.difference,
      pass: pos.difference === 0,
    },
    {
      name: "Cash flow reconciles",
      detail: `Opening + net movement = closing`,
      value: cf.difference,
      pass: cf.difference === 0,
    },
    {
      name: "Cash agrees to the ledger",
      detail: `Cash accounts ${cashFromLines.toFixed(2)} = balance sheet ${cashOnSheet.toFixed(2)}`,
      value: money(cashFromLines - cashOnSheet),
      pass: money(cashFromLines - cashOnSheet) === 0,
    },
    {
      name: "Every entry is balanced",
      detail: `${unbalanced?.n ?? 0} entries with unequal debits and credits`,
      value: unbalanced?.n ?? 0,
      pass: (unbalanced?.n ?? 0) === 0,
    },
    {
      name: "Every line is one-sided",
      detail: `${badLines?.n ?? 0} lines that are both or neither`,
      value: badLines?.n ?? 0,
      pass: (badLines?.n ?? 0) === 0,
    },
  ];
}

// ── Budget vs Actual ─────────────────────────────────────────────────────────
export interface BudgetVariance {
  rows: {
    accountCode: string;
    name: string;
    activityCode: string | null;
    budget: number;
    actual: number;
    variance: number;
    usedPct: number;
  }[];
  totalBudget: number;
  totalActual: number;
  totalVariance: number;
}

export async function budgetVsActual(
  ownerId: string,
  budgetId: string,
  to?: string,
): Promise<BudgetVariance> {
  const budgetRows = await db.execute(sql`
    select bl.account_code, a.name, bl.activity_code, sum(bl.amount) as budget
    from budget_lines bl
    join accounts a on a.code = bl.account_code
    where bl.owner_id = ${ownerId} and bl.budget_id = ${budgetId}
    group by bl.account_code, a.name, bl.activity_code
    order by bl.account_code
  `);

  const actualRows = await db.execute(sql`
    select jl.account_code, jl.activity_code, sum(jl.debit - jl.credit) as actual
    from journal_lines jl
    join journal_entries je on je.id = jl.entry_id
    join accounts a on a.code = jl.account_code
    where jl.owner_id = ${ownerId} and a.type = 'expense'
      ${to ? sql`and je.entry_date <= ${to}::date` : sql``}
    group by jl.account_code, jl.activity_code
  `);

  const actualMap = new Map<string, number>();
  for (const r of actualRows.rows as any[]) {
    actualMap.set(`${r.account_code}|${r.activity_code ?? ""}`, money(r.actual));
  }

  const rows = (budgetRows.rows as any[]).map((r) => {
    const budget = money(r.budget);
    const actual = actualMap.get(`${r.account_code}|${r.activity_code ?? ""}`) ?? 0;
    return {
      accountCode: r.account_code,
      name: r.name,
      activityCode: r.activity_code ?? null,
      budget,
      actual,
      variance: money(budget - actual),
      usedPct: budget === 0 ? 0 : Math.round((actual / budget) * 1000) / 10,
    };
  });

  const totalBudget = money(rows.reduce((s, r) => s + r.budget, 0));
  const totalActual = money(rows.reduce((s, r) => s + r.actual, 0));
  return { rows, totalBudget, totalActual, totalVariance: money(totalBudget - totalActual) };
}
