ALTER TABLE "cash_accounts" ADD COLUMN IF NOT EXISTS "gl_account_code" text;
--> statement-breakpoint
UPDATE "cash_accounts" SET "gl_account_code" = CASE
  WHEN "code" = 'BANK-01' THEN '1012'
  WHEN "code" = 'CASH-01' THEN '1011'
  ELSE CASE WHEN "account_type" = 'cash' THEN '1011' ELSE '1012' END
END
WHERE "gl_account_code" IS NULL;
