-- ─────────────────────────────────────────────────────────────────────────────
-- 0005 — access control, account recovery, change log, reconciliation detail.
--
-- Adds the tables the deployment-readiness audit called for:
--   org_members          who may use this book, and in what role
--   login_attempts       failed-login ledger for throttling
--   recovery_codes       one-time codes (bcrypt hashes only)
--   password_resets      short-lived single-use reset tokens
--   user_security        session-revocation watermark
--   change_log           who changed what, and when
--   reconciliation_items which transactions a reconciliation cleared
-- and the columns a reconciliation needs to prove a statement.
-- ─────────────────────────────────────────────────────────────────────────────

--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "org_members" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "owner_id" uuid NOT NULL,
  "user_id" uuid NOT NULL,
  "role" text DEFAULT 'auditor' NOT NULL,
  "display_name" text,
  "created_by" uuid,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "org_members_user_id_unique" UNIQUE("user_id")
);
--> statement-breakpoint
DO $$ BEGIN
  ALTER TABLE "org_members" ADD CONSTRAINT "org_members_owner_id_users_id_fk"
    FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN null; END $$;
--> statement-breakpoint
DO $$ BEGIN
  ALTER TABLE "org_members" ADD CONSTRAINT "org_members_user_id_users_id_fk"
    FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN null; END $$;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "org_members_owner_idx" ON "org_members" USING btree ("owner_id");
--> statement-breakpoint

CREATE TABLE IF NOT EXISTS "login_attempts" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "kind" text NOT NULL,
  "key" text NOT NULL,
  "success" boolean DEFAULT false NOT NULL,
  "attempted_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "login_attempts_kind_key_idx"
  ON "login_attempts" USING btree ("kind","key","attempted_at");
--> statement-breakpoint

CREATE TABLE IF NOT EXISTS "recovery_codes" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "user_id" uuid NOT NULL,
  "code_hash" text NOT NULL,
  "hint" text,
  "used_at" timestamp with time zone,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
DO $$ BEGIN
  ALTER TABLE "recovery_codes" ADD CONSTRAINT "recovery_codes_user_id_users_id_fk"
    FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN null; END $$;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "recovery_codes_user_idx" ON "recovery_codes" USING btree ("user_id");
--> statement-breakpoint

CREATE TABLE IF NOT EXISTS "password_resets" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "user_id" uuid NOT NULL,
  "token_hash" text NOT NULL,
  "expires_at" timestamp with time zone NOT NULL,
  "used_at" timestamp with time zone,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
DO $$ BEGIN
  ALTER TABLE "password_resets" ADD CONSTRAINT "password_resets_user_id_users_id_fk"
    FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN null; END $$;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "password_resets_user_idx" ON "password_resets" USING btree ("user_id");
--> statement-breakpoint

CREATE TABLE IF NOT EXISTS "user_security" (
  "user_id" uuid PRIMARY KEY NOT NULL,
  "sessions_valid_after" timestamp with time zone DEFAULT now() NOT NULL,
  "password_changed_at" timestamp with time zone,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
DO $$ BEGIN
  ALTER TABLE "user_security" ADD CONSTRAINT "user_security_user_id_users_id_fk"
    FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN null; END $$;
--> statement-breakpoint

CREATE TABLE IF NOT EXISTS "change_log" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "owner_id" uuid NOT NULL,
  "actor_id" uuid,
  "actor_name" text,
  "actor_role" text,
  "entity" text NOT NULL,
  "entity_id" text,
  "action" text NOT NULL,
  "summary" text NOT NULL,
  "before" text,
  "after" text,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
DO $$ BEGIN
  ALTER TABLE "change_log" ADD CONSTRAINT "change_log_owner_id_users_id_fk"
    FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN null; END $$;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "change_log_owner_created_idx" ON "change_log" USING btree ("owner_id","created_at");
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "change_log_owner_entity_idx" ON "change_log" USING btree ("owner_id","entity");
--> statement-breakpoint

CREATE TABLE IF NOT EXISTS "reconciliation_items" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "owner_id" uuid NOT NULL,
  "reconciliation_id" uuid NOT NULL,
  "transaction_id" uuid NOT NULL,
  "txn_id" text,
  "txn_date" date,
  "amount" numeric(15, 2) DEFAULT '0.00' NOT NULL,
  "cleared" boolean DEFAULT true NOT NULL
);
--> statement-breakpoint
DO $$ BEGIN
  ALTER TABLE "reconciliation_items" ADD CONSTRAINT "reconciliation_items_owner_id_users_id_fk"
    FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN null; END $$;
--> statement-breakpoint
DO $$ BEGIN
  ALTER TABLE "reconciliation_items" ADD CONSTRAINT "reconciliation_items_reconciliation_id_reconciliations_id_fk"
    FOREIGN KEY ("reconciliation_id") REFERENCES "public"."reconciliations"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION WHEN duplicate_object THEN null; END $$;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "reconciliation_items_rec_idx" ON "reconciliation_items" USING btree ("reconciliation_id");
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "reconciliation_items_owner_idx" ON "reconciliation_items" USING btree ("owner_id");
--> statement-breakpoint

-- Reconciliation arithmetic, so a saved reconciliation carries its own proof.
ALTER TABLE "reconciliations" ADD COLUMN IF NOT EXISTS "cleared_total" numeric(15, 2) DEFAULT '0.00' NOT NULL;
--> statement-breakpoint
ALTER TABLE "reconciliations" ADD COLUMN IF NOT EXISTS "uncleared_total" numeric(15, 2) DEFAULT '0.00' NOT NULL;
--> statement-breakpoint
ALTER TABLE "reconciliations" ADD COLUMN IF NOT EXISTS "difference" numeric(15, 2) DEFAULT '0.00' NOT NULL;
--> statement-breakpoint
ALTER TABLE "reconciliations" ADD COLUMN IF NOT EXISTS "cleared_count" integer DEFAULT 0 NOT NULL;
--> statement-breakpoint
ALTER TABLE "reconciliations" ADD COLUMN IF NOT EXISTS "uncleared_count" integer DEFAULT 0 NOT NULL;
--> statement-breakpoint

-- Organisation settings: closed-by-default signup, and an optional logo.
ALTER TABLE "orgs" ADD COLUMN IF NOT EXISTS "allow_public_signup" boolean DEFAULT false NOT NULL;
--> statement-breakpoint
ALTER TABLE "orgs" ADD COLUMN IF NOT EXISTS "logo_url" text;
