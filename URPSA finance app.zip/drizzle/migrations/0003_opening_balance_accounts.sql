INSERT INTO accounts (code, name, type, category, report_group, parent_code, is_postable, is_cash, cash_flow_class, requires_activity, requires_evidence, is_contra, is_active, sort_order, notes)
VALUES ('1013','Amounts owed to the association','asset','Receivables','SUB_CASH','1010',true,false,'operating',false,false,false,true,113,'Opening balances: money owed TO the association at the start of the year')
ON CONFLICT (code) DO NOTHING;
--> statement-breakpoint
UPDATE accounts SET notes = 'Opening balances: money owed BY the association at the start of the year' WHERE code = '2011';
--> statement-breakpoint
UPDATE accounts SET notes = 'Opening balances: accumulated fund brought forward' WHERE code = '3010';
