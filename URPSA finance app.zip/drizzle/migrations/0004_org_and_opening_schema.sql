ALTER TABLE orgs ADD COLUMN IF NOT EXISTS institution text;
--> statement-breakpoint
ALTER TABLE orgs ADD COLUMN IF NOT EXISTS faculty text;
--> statement-breakpoint
ALTER TABLE orgs ADD COLUMN IF NOT EXISTS initials text;
--> statement-breakpoint
ALTER TABLE orgs ADD COLUMN IF NOT EXISTS contact_email text;
--> statement-breakpoint
ALTER TABLE orgs ADD COLUMN IF NOT EXISTS contact_phone text;
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS opening_balances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  bank_amount numeric(15,2) NOT NULL DEFAULT '0.00',
  cash_amount numeric(15,2) NOT NULL DEFAULT '0.00',
  receivable_amount numeric(15,2) NOT NULL DEFAULT '0.00',
  payable_amount numeric(15,2) NOT NULL DEFAULT '0.00',
  fund_amount numeric(15,2) NOT NULL DEFAULT '0.00',
  entry_id uuid,
  posted_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);
