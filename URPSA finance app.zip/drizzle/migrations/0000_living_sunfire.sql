CREATE TABLE "accounts" (
	"code" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"type" text NOT NULL,
	"category" text,
	"report_group" text,
	"parent_code" text,
	"is_postable" boolean DEFAULT false NOT NULL,
	"is_cash" boolean DEFAULT false NOT NULL,
	"cash_flow_class" text DEFAULT 'none' NOT NULL,
	"requires_activity" boolean DEFAULT false NOT NULL,
	"requires_evidence" boolean DEFAULT false NOT NULL,
	"is_contra" boolean DEFAULT false NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"notes" text
);
--> statement-breakpoint
CREATE TABLE "activities" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"code" text NOT NULL,
	"name" text NOT NULL,
	"start_date" date,
	"end_date" date,
	"budget_category" text,
	"approved_budget" numeric(15, 2),
	"approver" text,
	"approval_date" date,
	"fund_code" text DEFAULT 'GEN' NOT NULL,
	"status" text DEFAULT 'planned' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "assets" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"asset_id" text NOT NULL,
	"description" text NOT NULL,
	"category" text DEFAULT 'equipment' NOT NULL,
	"serial" text,
	"custodian" text,
	"location" text,
	"purchase_date" date,
	"purchase_txn_id" text,
	"cost" numeric(15, 2) DEFAULT '0.00' NOT NULL,
	"condition" text DEFAULT 'good' NOT NULL,
	"last_verified" date,
	"notes" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "budget_lines" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"budget_id" uuid NOT NULL,
	"account_code" text NOT NULL,
	"activity_code" text,
	"period_no" integer DEFAULT 0 NOT NULL,
	"amount" numeric(15, 2) DEFAULT '0.00' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "budgets" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"fiscal_year" integer NOT NULL,
	"name" text NOT NULL,
	"version" integer DEFAULT 1 NOT NULL,
	"status" text DEFAULT 'approved' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "cash_accounts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"code" text NOT NULL,
	"name" text NOT NULL,
	"account_type" text DEFAULT 'bank' NOT NULL,
	"details" text,
	"opening_balance" numeric(15, 2),
	"opening_date" date,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "dues" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"dues_ref" text NOT NULL,
	"member_id" text NOT NULL,
	"dues_type" text NOT NULL,
	"due_date" date,
	"amount_assessed" numeric(15, 2) DEFAULT '0.00' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "evidence" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"evidence_id" text NOT NULL,
	"transaction_id" text,
	"doc_type" text DEFAULT 'receipt' NOT NULL,
	"description" text,
	"file_path" text,
	"storage_key" text,
	"mime_type" text,
	"file_size_bytes" integer,
	"date_received" date,
	"submitted_by" text,
	"reviewed_by" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"exception_reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "files" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"key" text NOT NULL,
	"owner_id" uuid,
	"name" text NOT NULL,
	"size" bigint NOT NULL,
	"content_type" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "files_key_unique" UNIQUE("key")
);
--> statement-breakpoint
CREATE TABLE "fiscal_periods" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"fiscal_year" integer NOT NULL,
	"period_no" integer NOT NULL,
	"start_date" date NOT NULL,
	"end_date" date NOT NULL,
	"status" text DEFAULT 'open' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "items" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"title" text NOT NULL,
	"notes" text,
	"cover_url" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "journal_entries" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"entry_no" text NOT NULL,
	"entry_date" date NOT NULL,
	"period_id" uuid,
	"source" text DEFAULT 'manual' NOT NULL,
	"status" text DEFAULT 'posted' NOT NULL,
	"description" text NOT NULL,
	"document_ref" text,
	"currency" text DEFAULT 'NGN' NOT NULL,
	"total_debit" numeric(15, 2) DEFAULT '0.00' NOT NULL,
	"total_credit" numeric(15, 2) DEFAULT '0.00' NOT NULL,
	"reverses_entry_id" uuid,
	"prepared_by" text NOT NULL,
	"approved_by" text,
	"posted_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "journal_lines" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"entry_id" uuid NOT NULL,
	"line_no" integer NOT NULL,
	"account_code" text NOT NULL,
	"activity_code" text,
	"cash_account_code" text,
	"debit" numeric(15, 2) DEFAULT '0.00' NOT NULL,
	"credit" numeric(15, 2) DEFAULT '0.00' NOT NULL,
	"memo" text
);
--> statement-breakpoint
CREATE TABLE "liabilities" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"liability_id" text NOT NULL,
	"payee" text NOT NULL,
	"description" text,
	"activity_code" text,
	"date_incurred" date,
	"due_date" date,
	"amount_committed" numeric(15, 2) DEFAULT '0.00' NOT NULL,
	"approval_status" text DEFAULT 'Approved' NOT NULL,
	"status" text DEFAULT 'outstanding' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "members" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"member_id" text NOT NULL,
	"admission_year" text,
	"matric_number" text,
	"full_name" text NOT NULL,
	"level" text,
	"phone" text,
	"email" text,
	"status" text DEFAULT 'active' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "orgs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"legal_name" text NOT NULL,
	"short_name" text,
	"base_currency" text DEFAULT 'NGN' NOT NULL,
	"period_start" date NOT NULL,
	"period_end" date NOT NULL,
	"conversion_date" date NOT NULL,
	"opening_balance_status" numeric(15, 2) DEFAULT '0.00' NOT NULL,
	"financial_secretary" text,
	"treasurer" text,
	"president" text,
	"member_id_rule" text,
	"capitalisation_threshold" numeric(15, 2) DEFAULT '50000.00' NOT NULL,
	"evidence_required_above" numeric(15, 2) DEFAULT '5000.00' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "orgs_owner_id_unique" UNIQUE("owner_id")
);
--> statement-breakpoint
CREATE TABLE "reconciliations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"month" date NOT NULL,
	"cash_account_code" text NOT NULL,
	"statement_date" date,
	"statement_balance" numeric(15, 2),
	"ledger_balance" numeric(15, 2),
	"reviewed_by" text,
	"status" text DEFAULT 'not_ready' NOT NULL,
	"notes" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sponsorship" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"sponsorship_id" text NOT NULL,
	"sponsor" text NOT NULL,
	"purpose" text,
	"contact" text,
	"commitment_date" date,
	"amount_pledged" numeric(15, 2) DEFAULT '0.00' NOT NULL,
	"stage" text DEFAULT 'pledged' NOT NULL,
	"activity_code" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "transactions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"txn_id" text NOT NULL,
	"txn_type" text NOT NULL,
	"txn_date" date NOT NULL,
	"category_code" text NOT NULL,
	"cash_account_code" text NOT NULL,
	"payee" text,
	"member_id" text,
	"reference" text,
	"amount" numeric(15, 2) DEFAULT '0.00' NOT NULL,
	"evidence_id" text,
	"activity_code" text,
	"approval_status" text DEFAULT 'Approved' NOT NULL,
	"approved_by" text,
	"notes" text,
	"entry_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"email" text NOT NULL,
	"password_hash" text,
	"name" text,
	"role" text DEFAULT 'user' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
ALTER TABLE "activities" ADD CONSTRAINT "activities_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "assets" ADD CONSTRAINT "assets_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "budget_lines" ADD CONSTRAINT "budget_lines_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "budget_lines" ADD CONSTRAINT "budget_lines_budget_id_budgets_id_fk" FOREIGN KEY ("budget_id") REFERENCES "public"."budgets"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "budgets" ADD CONSTRAINT "budgets_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cash_accounts" ADD CONSTRAINT "cash_accounts_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "dues" ADD CONSTRAINT "dues_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "evidence" ADD CONSTRAINT "evidence_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "files" ADD CONSTRAINT "files_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "fiscal_periods" ADD CONSTRAINT "fiscal_periods_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "items" ADD CONSTRAINT "items_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "journal_entries" ADD CONSTRAINT "journal_entries_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "journal_entries" ADD CONSTRAINT "journal_entries_period_id_fiscal_periods_id_fk" FOREIGN KEY ("period_id") REFERENCES "public"."fiscal_periods"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "journal_lines" ADD CONSTRAINT "journal_lines_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "journal_lines" ADD CONSTRAINT "journal_lines_entry_id_journal_entries_id_fk" FOREIGN KEY ("entry_id") REFERENCES "public"."journal_entries"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "liabilities" ADD CONSTRAINT "liabilities_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "members" ADD CONSTRAINT "members_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "orgs" ADD CONSTRAINT "orgs_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reconciliations" ADD CONSTRAINT "reconciliations_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sponsorship" ADD CONSTRAINT "sponsorship_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "accounts_type_idx" ON "accounts" USING btree ("type");--> statement-breakpoint
CREATE INDEX "accounts_sort_idx" ON "accounts" USING btree ("sort_order");--> statement-breakpoint
CREATE UNIQUE INDEX "activities_owner_code_uq" ON "activities" USING btree ("owner_id","code");--> statement-breakpoint
CREATE INDEX "activities_owner_idx" ON "activities" USING btree ("owner_id");--> statement-breakpoint
CREATE UNIQUE INDEX "assets_owner_ref_uq" ON "assets" USING btree ("owner_id","asset_id");--> statement-breakpoint
CREATE INDEX "assets_owner_idx" ON "assets" USING btree ("owner_id");--> statement-breakpoint
CREATE INDEX "budget_lines_budget_idx" ON "budget_lines" USING btree ("budget_id");--> statement-breakpoint
CREATE INDEX "budget_lines_owner_account_idx" ON "budget_lines" USING btree ("owner_id","account_code");--> statement-breakpoint
CREATE INDEX "budgets_owner_year_idx" ON "budgets" USING btree ("owner_id","fiscal_year");--> statement-breakpoint
CREATE UNIQUE INDEX "cash_accounts_owner_code_uq" ON "cash_accounts" USING btree ("owner_id","code");--> statement-breakpoint
CREATE INDEX "cash_accounts_owner_idx" ON "cash_accounts" USING btree ("owner_id");--> statement-breakpoint
CREATE UNIQUE INDEX "dues_owner_ref_uq" ON "dues" USING btree ("owner_id","dues_ref");--> statement-breakpoint
CREATE INDEX "dues_owner_member_idx" ON "dues" USING btree ("owner_id","member_id");--> statement-breakpoint
CREATE UNIQUE INDEX "evidence_owner_ref_uq" ON "evidence" USING btree ("owner_id","evidence_id");--> statement-breakpoint
CREATE INDEX "evidence_owner_txn_idx" ON "evidence" USING btree ("owner_id","transaction_id");--> statement-breakpoint
CREATE INDEX "files_owner_idx" ON "files" USING btree ("owner_id");--> statement-breakpoint
CREATE INDEX "files_created_idx" ON "files" USING btree ("created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "fiscal_periods_owner_year_no_uq" ON "fiscal_periods" USING btree ("owner_id","fiscal_year","period_no");--> statement-breakpoint
CREATE INDEX "fiscal_periods_owner_idx" ON "fiscal_periods" USING btree ("owner_id");--> statement-breakpoint
CREATE INDEX "items_owner_idx" ON "items" USING btree ("owner_id");--> statement-breakpoint
CREATE UNIQUE INDEX "journal_entries_owner_no_uq" ON "journal_entries" USING btree ("owner_id","entry_no");--> statement-breakpoint
CREATE INDEX "journal_entries_owner_date_idx" ON "journal_entries" USING btree ("owner_id","entry_date");--> statement-breakpoint
CREATE INDEX "journal_entries_owner_idx" ON "journal_entries" USING btree ("owner_id");--> statement-breakpoint
CREATE INDEX "journal_lines_entry_idx" ON "journal_lines" USING btree ("entry_id");--> statement-breakpoint
CREATE INDEX "journal_lines_owner_account_idx" ON "journal_lines" USING btree ("owner_id","account_code");--> statement-breakpoint
CREATE INDEX "journal_lines_owner_activity_idx" ON "journal_lines" USING btree ("owner_id","activity_code");--> statement-breakpoint
CREATE UNIQUE INDEX "liabilities_owner_ref_uq" ON "liabilities" USING btree ("owner_id","liability_id");--> statement-breakpoint
CREATE INDEX "liabilities_owner_idx" ON "liabilities" USING btree ("owner_id");--> statement-breakpoint
CREATE UNIQUE INDEX "members_owner_member_id_uq" ON "members" USING btree ("owner_id","member_id");--> statement-breakpoint
CREATE INDEX "members_owner_idx" ON "members" USING btree ("owner_id");--> statement-breakpoint
CREATE UNIQUE INDEX "reconciliations_owner_month_acct_uq" ON "reconciliations" USING btree ("owner_id","month","cash_account_code");--> statement-breakpoint
CREATE INDEX "reconciliations_owner_idx" ON "reconciliations" USING btree ("owner_id");--> statement-breakpoint
CREATE UNIQUE INDEX "sponsorship_owner_ref_uq" ON "sponsorship" USING btree ("owner_id","sponsorship_id");--> statement-breakpoint
CREATE INDEX "sponsorship_owner_idx" ON "sponsorship" USING btree ("owner_id");--> statement-breakpoint
CREATE UNIQUE INDEX "transactions_owner_txn_uq" ON "transactions" USING btree ("owner_id","txn_id");--> statement-breakpoint
CREATE INDEX "transactions_owner_date_idx" ON "transactions" USING btree ("owner_id","txn_date");--> statement-breakpoint
CREATE INDEX "transactions_owner_activity_idx" ON "transactions" USING btree ("owner_id","activity_code");