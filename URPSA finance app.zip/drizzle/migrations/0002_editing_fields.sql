-- Editing capability: the columns each editor needs to record a real lifecycle
-- rather than just a static row.
--
--   members      archived_at           archive/restore without losing history
--   sponsorship  restriction, expected_date, notes
--   assets       status + disposal fields  (an asset is disposed, never deleted)
--   liabilities  settlement fields         (settling posts to the ledger)
--
-- Every column is nullable or has a default, so existing rows stay valid.

ALTER TABLE "members" ADD COLUMN IF NOT EXISTS "archived_at" timestamp with time zone;
--> statement-breakpoint

ALTER TABLE "sponsorship" ADD COLUMN IF NOT EXISTS "restriction" text DEFAULT 'restricted' NOT NULL;
--> statement-breakpoint
ALTER TABLE "sponsorship" ADD COLUMN IF NOT EXISTS "expected_date" date;
--> statement-breakpoint
ALTER TABLE "sponsorship" ADD COLUMN IF NOT EXISTS "notes" text;
--> statement-breakpoint

ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "status" text DEFAULT 'in_use' NOT NULL;
--> statement-breakpoint
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "disposal_date" date;
--> statement-breakpoint
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "disposal_proceeds" numeric(15, 2);
--> statement-breakpoint
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "disposal_reason" text;
--> statement-breakpoint
ALTER TABLE "assets" ADD COLUMN IF NOT EXISTS "disposal_entry_id" uuid;
--> statement-breakpoint

ALTER TABLE "liabilities" ADD COLUMN IF NOT EXISTS "settled_date" date;
--> statement-breakpoint
ALTER TABLE "liabilities" ADD COLUMN IF NOT EXISTS "settled_amount" numeric(15, 2);
--> statement-breakpoint
ALTER TABLE "liabilities" ADD COLUMN IF NOT EXISTS "settlement_entry_id" uuid;
--> statement-breakpoint
ALTER TABLE "liabilities" ADD COLUMN IF NOT EXISTS "settlement_ref" text;
--> statement-breakpoint
-- Recognition: a commitment must be an expense and a liability before it can be
-- settled, otherwise paying it drives the liability account negative.
ALTER TABLE "liabilities" ADD COLUMN IF NOT EXISTS "expense_account_code" text NOT NULL DEFAULT '5007';
--> statement-breakpoint
ALTER TABLE "liabilities" ADD COLUMN IF NOT EXISTS "accrual_entry_id" uuid;
