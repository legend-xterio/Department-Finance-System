-- URPSA reference data: the chart of accounts from the workbook's
-- "Chart of Accounts" sheet (4001-4005 income, 5001-5007 expense) plus the
-- minimum system accounts a double entry needs (cash, liabilities, fund).
-- Idempotent: safe to meet rows that already exist.
INSERT INTO accounts (code, name, type, category, report_group, parent_code, is_postable, is_cash, cash_flow_class, requires_activity, requires_evidence, is_contra, is_active, sort_order) VALUES
('1000','ASSETS','asset','Balance sheet','HEAD_ASSETS',NULL,false,false,'none',false,false,false,true,100),
('1010','Cash and cash equivalents','asset','Cash at bank and in hand','SUB_CASH','1000',false,false,'operating',false,false,false,true,110),
('1011','Cash on hand','asset','Cash at bank and in hand','SUB_CASH','1010',true,true,'operating',false,false,false,true,111),
('1012','Bank - URPSA UNILAG','asset','Cash at bank and in hand','SUB_CASH','1010',true,true,'operating',false,false,false,true,112),
('2000','LIABILITIES','liability','Balance sheet','HEAD_LIAB',NULL,false,false,'none',false,false,false,true,200),
('2010','Commitments and payables','liability','Commitments','SUB_LIAB','2000',false,false,'none',false,false,false,true,210),
('2011','Liabilities and commitments','liability','Commitments','SUB_LIAB','2010',true,false,'financing',false,false,false,true,211),
('3000','FUNDS','equity','Balance sheet','HEAD_FUND',NULL,false,false,'none',false,false,false,true,300),
('3010','Accumulated fund','equity','Accumulated fund','SUB_FUND','3000',true,false,'financing',false,false,false,true,310),
('4000','INCOME','income','Income and expenditure','HEAD_INC',NULL,false,false,'none',false,false,false,true,400),
('4001','Membership dues','income','Income and expenditure','SUB_INC','4000',true,false,'operating',false,false,false,true,401),
('4002','Sponsorship','income','Income and expenditure','SUB_INC','4000',true,false,'operating',false,false,false,true,402),
('4003','Conference income','income','Income and expenditure','SUB_INC','4000',true,false,'operating',false,false,false,true,403),
('4004','Fundraising','income','Income and expenditure','SUB_INC','4000',true,false,'operating',false,false,false,true,404),
('4005','Other income','income','Income and expenditure','SUB_INC','4000',true,false,'operating',false,false,false,true,405),
('5000','EXPENDITURE','expense','Income and expenditure','HEAD_EXP',NULL,false,false,'none',false,false,false,true,500),
('5001','Administration','expense','Income and expenditure','SUB_EXP','5000',true,false,'operating',false,false,false,true,501),
('5002','Transport','expense','Income and expenditure','SUB_EXP','5000',true,false,'operating',false,false,false,true,502),
('5003','Activities and events','expense','Income and expenditure','SUB_EXP','5000',true,false,'operating',false,false,false,true,503),
('5004','Conference expense','expense','Income and expenditure','SUB_EXP','5000',true,false,'operating',false,false,false,true,504),
('5005','Welfare','expense','Income and expenditure','SUB_EXP','5000',true,false,'operating',false,false,false,true,505),
('5006','Bank charges','expense','Income and expenditure','SUB_EXP','5000',true,false,'operating',false,false,false,true,506),
('5007','Other expense','expense','Income and expenditure','SUB_EXP','5000',true,false,'operating',false,false,false,true,507)
ON CONFLICT (code) DO NOTHING;
