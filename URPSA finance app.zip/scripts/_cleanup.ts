import "dotenv/config";
import { db } from "../server/_core/db";
import { sql } from "drizzle-orm";
const OWNER = "7783e909-bd24-4fb0-8184-fbc8050b8026";
(async () => {
  for (const q of [
    `delete from journal_entries where owner_id='${OWNER}' and (description like 'Settlement of LIA-000%' and description like '%E2E%' or description like 'Disposal proceeds%' or description like 'E2E Test Sponsor%' or description like 'Commitment recognised — E2E%')`,
    `delete from transactions where owner_id='${OWNER}' and (payee like 'E2E Test%' or reference in (select sponsorship_id from sponsorship where sponsor like 'E2E Test%'))`,
    `delete from liabilities where owner_id='${OWNER}' and payee like 'E2E Test%'`,
    `delete from assets where owner_id='${OWNER}' and description like 'E2E Test%'`,
    `delete from sponsorship where owner_id='${OWNER}' and sponsor like 'E2E Test%'`,
    `delete from evidence where owner_id='${OWNER}' and evidence_id like 'EV-E2E-%'`,
    `delete from budget_lines where owner_id='${OWNER}' and amount = 9999.99`,
  ]) { try { await db.execute(sql.raw(q)); } catch(e:any) { console.log("skip:", e.message.slice(0,80)); } }
  const t = await db.execute(sql`select coalesce(sum(debit-credit),0) tb from journal_lines where owner_id=${OWNER}`);
  console.log("TB:", JSON.stringify(t.rows));
  process.exit(0);
})();
