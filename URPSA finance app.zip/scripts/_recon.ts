import "dotenv/config";
import { appRouter } from "../server/routers";
import { db } from "../server/_core/db";
import { orgs } from "../drizzle/schema";
function fakeCtx(){const h:Record<string,string>={host:"localhost:3000"};return{req:{url:"http://localhost:3000/trpc",header:(k:string)=>h[k.toLowerCase()]},header:(k:string,v:string)=>{h[k.toLowerCase()]=v},setCookie:()=>{},getCookie:()=>undefined} as any;}
async function main(){
  const [org] = await db.select().from(orgs).limit(1);
  const api = appRouter.createCaller({ user: { id: org.ownerId, email: "treasurer@urpsa.test", name: "T", role: "user" }, c: fakeCtx() } as any);
  const to = "2027-09-30";
  const tb = await api.reports.trialBalance({ to } as any);
  const bs = await api.reports.financialPosition({ to } as any);
  const cf = await api.reports.cashFlow({ to } as any);
  const cc = await api.reports.controlChecks({ to } as any);
  console.log("TRIAL   Dr", tb.totalDebit, "Cr", tb.totalCredit, "diff", tb.difference);
  console.log("POSITION assets", bs.totalAssets, "liab+funds", bs.totalLiabilities + bs.totalFunds + bs.currentSurplus, "diff", bs.difference);
  console.log("CASHFLOW closing", cf.closingCash, "diff", cf.difference);
  console.log("CONTROLS", cc.filter((c:any)=>c.pass).length + "/" + cc.length, "pass");
  process.exit(0);
}
main().catch(e=>{console.error("FAILED", e.message); process.exit(1);});
