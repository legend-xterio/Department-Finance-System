import "dotenv/config";
import { db } from "../server/_core/db";
import { sql } from "drizzle-orm";
const OWNER = "7783e909-bd24-4fb0-8184-fbc8050b8026";
(async () => {
  const a = await db.execute(sql`select code,name,type,is_postable from accounts order by code`);
  console.log("=== ACCOUNTS ===");
  for (const r of a.rows as any[]) console.log(`${r.code}  ${r.type.padEnd(11)} ${String(r.is_postable).padEnd(5)} ${r.name}`);
  const e = await db.execute(sql`select id, entry_date, description, document_ref from journal_entries where owner_id=${OWNER} order by entry_date, created_at limit 3`);
  console.log("\n=== FIRST ENTRIES ===");
  for (const r of e.rows as any[]) console.log(`${r.entry_date} ${r.description} [${r.document_ref}]`);
  const l = await db.execute(sql`select jl.account_code, a.name, a.type, jl.debit, jl.credit, je.description from journal_lines jl join journal_entries je on je.id=jl.entry_id join accounts a on a.code=jl.account_code where jl.owner_id=${OWNER} order by je.entry_date, je.created_at limit 8`);
  console.log("\n=== FIRST LINES ===");
  for (const r of l.rows as any[]) console.log(`${r.account_code} ${r.type.padEnd(11)} D=${r.debit} C=${r.credit}  ${r.description}`);
  const t = await db.execute(sql`select a.type, sum(jl.debit) d, sum(jl.credit) c, sum(jl.debit-jl.credit) net from journal_lines jl join accounts a on a.code=jl.account_code where jl.owner_id=${OWNER} group by a.type order by a.type`);
  console.log("\n=== BY TYPE ===");
  for (const r of t.rows as any[]) console.log(`${r.type.padEnd(11)} D=${r.d} C=${r.c} net(D-C)=${r.net}`);
  process.exit(0);
})();
