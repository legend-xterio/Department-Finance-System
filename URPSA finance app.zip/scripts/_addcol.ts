import "dotenv/config";
import { db } from "../server/_core/db";
import { sql } from "drizzle-orm";
(async () => {
  await db.execute(sql`alter table liabilities add column if not exists expense_account_code text not null default '5007'`);
  await db.execute(sql`alter table liabilities add column if not exists accrual_entry_id uuid`);
  const r = await db.execute(sql`select column_name from information_schema.columns where table_name='liabilities' order by ordinal_position`);
  console.log((r.rows as any[]).map((x) => x.column_name).join(", "));
  process.exit(0);
})();
