import { db } from "../../server/_core/db";
import { sql } from "drizzle-orm";
const r = await db.execute(sql`select code,name,type,is_cash,is_postable,cash_flow_class from accounts where code like '10%' or code like '20%' or code like '30%' order by code`);
console.table(r.rows);
const c = await db.execute(sql`select code,name,account_type from cash_accounts order by code`);
console.table(c.rows);
process.exit(0);
