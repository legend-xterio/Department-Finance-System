import "dotenv/config";
import { db } from "../server/_core/db";
import { users } from "../drizzle/schema";
const r = await db.select({ id: users.id, email: users.email }).from(users);
console.log(JSON.stringify(r));
process.exit(0);
