import "dotenv/config";
import { eq } from "drizzle-orm";
import { db } from "../server/_core/db";
import { journalLines } from "../drizzle/schema";
import { fundIncomeExpenditure, fundBalanceAt, balanceSheet } from "../server/reports";

const [u] = await db.select({ id: journalLines.ownerId }).from(journalLines).limit(1);
const ownerId = u.id;
const period = { from: "2026-01-01", to: "2026-10-25" };

const r = await fundIncomeExpenditure(ownerId, period);
const pad = (s: string | number, n = 13) => String(s).padStart(n);

console.log(
  `\n${"Fund".padEnd(6)}${"Restriction".padEnd(13)}${pad("Opening")}${pad("Income")}${pad("Expense")}${pad("Net")}${pad("Other")}${pad("Closing")}`,
);
for (const f of r.funds) {
  console.log(
    `${f.code.padEnd(6)}${f.restriction.padEnd(13)}${pad(f.opening.toFixed(2))}${pad(f.income.toFixed(2))}${pad(f.expense.toFixed(2))}${pad(f.net.toFixed(2))}${pad(f.otherMovements.toFixed(2))}${pad(f.closing.toFixed(2))}`,
  );
}
console.log(
  `${"TOTAL".padEnd(6)}${"".padEnd(13)}${pad(r.totals.opening.toFixed(2))}${pad(r.totals.income.toFixed(2))}${pad(r.totals.expense.toFixed(2))}${pad(r.totals.net.toFixed(2))}${pad("")}${pad(r.totals.closing.toFixed(2))}`,
);

console.log("\nreconciliation:", r.reconciliation);
console.log("reconciled:", r.reconciled);

// Closing per fund must equal net assets at period end.
const closing = await fundBalanceAt(ownerId, period.to);
const closingTotal = [...closing.values()].reduce((s, v) => s + v, 0);
console.log("\nnet assets per fund:", Object.fromEntries(closing));
console.log("sum net assets:", closingTotal.toFixed(2), "| totals.closing:", r.totals.closing.toFixed(2));
console.log("tie:", Math.abs(closingTotal - r.totals.closing) < 0.005);

// ...and must equal the balance sheet's total equity.
const bs = await balanceSheet(ownerId, period.to);
console.log("\nbalance sheet total equity:", bs.totalEquity.toFixed(2));
console.log("fund closing == balance sheet equity:", Math.abs(r.totals.closing - bs.totalEquity) < 0.005);

// Arithmetic identity per row: opening + net + other == closing.
const bad = r.funds.filter(
  (f) => Math.abs(f.opening + f.net + f.otherMovements - f.closing) > 0.005,
);
console.log("\nrows failing opening+net+other==closing:", bad.length);
process.exit(0);
