import "dotenv/config";
import { readFileSync } from "node:fs";
import { sql } from "drizzle-orm";
import { db } from "../server/_core/db";

const WANT = ["archived_at","restriction","expected_date","disposal_date","disposal_reason","settled_date"];

async function cols() {
  const r = await db.execute(sql.raw(`select table_name, column_name from information_schema.columns
    where table_schema='public' and column_name in ('${WANT.join("','")}') order by table_name, column_name`));
  return (r.rows as any[]).map((x) => `${x.table_name}.${x.column_name}`);
}

async function main() {
  const before = await cols();
  console.log("before:", before.join(", ") || "(none)");
  if (before.length === WANT.length) { console.log("ALREADY APPLIED — nothing to do"); return; }
  const raw = readFileSync("drizzle/migrations/0002_editing_fields.sql", "utf8")
    .split("--> statement-breakpoint")
    .map((s) => s.trim())
    .filter((s) => s && !s.split("\n").every((l) => !l.trim() || l.trim().startsWith("--")));
  for (const stmt of raw) {
    try {
      await db.execute(sql.raw(stmt));
      console.log("  ok:", stmt.split("\n").filter(l=>l.trim()&&!l.trim().startsWith("--"))[0].slice(0, 95));
    } catch (e: any) { console.log("  ERR:", e.message.slice(0,90)); }
  }
  console.log("after:", (await cols()).join(", "));
}
main().then(()=>process.exit(0)).catch(e=>{console.error(e.message);process.exit(1)});
