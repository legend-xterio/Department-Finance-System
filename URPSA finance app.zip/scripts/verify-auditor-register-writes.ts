/**
 * Prove the auditor's NEW permission tier, through the REAL router.
 *
 * The auditor may now ENTER transactional records in the registers, and must
 * still be refused everything structural. This script proves both halves, and
 * that every entry the auditor posts is attributed to them in the change log.
 *
 * It writes real rows (that is the point — "it persists" cannot be proven
 * without them), then reverses/removes what it created so the book is left
 * exactly as it was found. The final check asserts the trial balance still nets
 * to zero.
 */
import "dotenv/config";
import { and, eq, like } from "drizzle-orm";
import { appRouter } from "../server/routers";
import { db } from "../server/_core/db";
import {
  assets,
  budgetLines,
  budgets,
  changeLog,
  journalEntries,
  liabilities,
  orgMembers,
  sponsorship,
  transactions,
  users,
} from "../drizzle/schema";

const AUDITOR_EMAIL = "auditor@urpsa.test";
const AUDITOR_PW = "auditor2026";
const TREASURER_EMAIL = "treasurer@urpsa.test";

function fakeCtx() {
  const headers: Record<string, string> = { host: "localhost:3000" };
  return {
    req: { url: "http://localhost:3000/trpc", header: (k: string) => headers[k.toLowerCase()] },
    header: (k: string, v: string) => {
      headers[k.toLowerCase()] = v;
    },
    setCookie: () => {},
    getCookie: () => undefined,
  } as any;
}

let pass = 0;
let fail = 0;
function check(name: string, cond: boolean, detail = "") {
  if (cond) pass++;
  else fail++;
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${detail ? " — " + detail : ""}`);
}

async function expectRefused(fn: () => Promise<unknown>, label: string) {
  try {
    await fn();
    check(label, false, "the call SUCCEEDED — it should have been refused");
  } catch (e: any) {
    const code = String(e?.code ?? "");
    const msg = String(e?.message ?? e);
    const ok = code === "FORBIDDEN";
    check(label, ok, ok ? msg.slice(0, 70) : `wrong error: ${code} ${msg.slice(0, 60)}`);
  }
}

async function main() {
  const [auditor] = await db.select().from(users).where(eq(users.email, AUDITOR_EMAIL)).limit(1);
  const [treasurer] = await db.select().from(users).where(eq(users.email, TREASURER_EMAIL)).limit(1);
  if (!auditor || !treasurer) throw new Error("run scripts/_restore-logins.ts first");

  const [membership] = await db.select().from(orgMembers).where(eq(orgMembers.userId, auditor.id)).limit(1);
  const OWNER = membership.ownerId;

  const auditorApi = appRouter.createCaller({
    user: { id: auditor.id, email: auditor.email, name: auditor.name, role: "user" },
    c: fakeCtx(),
  } as any);
  const ownerApi = appRouter.createCaller({
    user: { id: treasurer.id, email: treasurer.email, name: treasurer.name, role: "user" },
    c: fakeCtx(),
  } as any);

  console.log("\n=== 0. THE AUDITOR STILL RESOLVES TO THE URPSA BOOK ===");
  const access = await auditorApi.access.list();
  check("role is auditor", access.myRole === "auditor", access.myRole);
  check("scoped to the URPSA book", access.owner?.email === TREASURER_EMAIL, access.owner?.email ?? "none");

  const before = await ownerApi.reports.trialBalance({ to: "2027-09-30" } as any);
  const beforeDiff = Number(before.difference ?? 0);

  console.log("\n=== 1. THE AUDITOR CAN ENTER RECORDS IN EVERY REGISTER ===");

  // 1a. A journal / transaction entry (the master register).
  const txn = await auditorApi.transactions.create({
    txnType: "Expense",
    txnDate: "2026-10-15",
    categoryCode: "5001",
    cashAccountCode: "CASH-01",
    payee: "AUDIT-PROBE petty cash",
    amount: 100,
    notes: "permission probe — removed at the end of this script",
  } as any);
  check("transactions.create succeeds", !!txn?.id, txn?.txnId ?? "none");
  const [persisted] = await db.select().from(transactions).where(eq(transactions.id, txn.id)).limit(1);
  check("the transaction PERSISTS in the database", !!persisted, persisted?.txnId ?? "missing");
  check("it posted a balanced journal entry", !!persisted?.entryId, persisted?.entryId ?? "none");

  // 1b. A petty-cash movement — same register, the cash account is the point.
  const petty = await auditorApi.transactions.create({
    txnType: "Expense",
    txnDate: "2026-10-16",
    categoryCode: "5002",
    cashAccountCode: "CASH-01",
    payee: "AUDIT-PROBE cash movement",
    amount: 50,
  } as any);
  check("a petty-cash movement succeeds", !!petty?.id, petty?.txnId ?? "none");

  // 1c. A sponsorship receipt — needs a pledge to receive against.
  const pledge = await ownerApi.sponsorship.upsert({
    sponsor: "AUDIT-PROBE Sponsor",
    amountPledged: 500,
    stage: "pledged",
    restriction: "unrestricted",
  } as any);
  const receipt = await auditorApi.sponsorship.recordReceipt({
    id: pledge.id,
    amount: 200,
    receivedDate: "2026-10-17",
    cashAccountCode: "BANK-01",
  } as any);
  check("sponsorship.recordReceipt succeeds", !!receipt?.id, receipt?.txnId ?? "none");

  // 1d. An asset.
  const asset = await auditorApi.assets.upsert({
    description: "AUDIT-PROBE projector",
    category: "equipment",
    cost: 750,
    condition: "good",
  } as any);
  check("assets.upsert succeeds", !!asset?.id, asset?.assetId ?? "none");

  // 1e. A commitment (liability) and its recognition. Created as Pending so the
  // recognition is a separate call — an Approved commitment accrues on save.
  const lia = await auditorApi.liabilities.upsert({
    payee: "AUDIT-PROBE vendor",
    amountCommitted: 300,
    dateIncurred: "2026-10-18",
    expenseAccountCode: "5003",
    approvalStatus: "Pending",
    status: "outstanding",
  } as any);
  check("liabilities.upsert succeeds", !!lia?.id, lia?.liabilityId ?? "none");
  const accrued = await auditorApi.liabilities.accrue({ id: lia.id } as any);
  check("liabilities.accrue succeeds", !!accrued?.accrualEntryId, accrued?.accrualEntryId ?? "none");

  // 1f. A budget line.
  const line = await auditorApi.budgets.saveLine({
    fiscalYear: 2026,
    name: "AUDIT-PROBE budget",
    accountCode: "5001",
    periodNo: 0,
    amount: 1000,
  } as any);
  check("budgets.saveLine succeeds", !!line?.id, line?.accountCode ?? "none");

  console.log("\n=== 2. EVERY ENTRY IS ATTRIBUTED TO THE AUDITOR ===");
  const log = await auditorApi.changeLog.list({ limit: 200 } as any);
  const mine = log.rows.filter((r: any) => r.actorId === auditor.id);
  check("the auditor's entries appear in the change log", mine.length >= 5, `${mine.length} rows`);
  check(
    "each is stamped with the auditor role, not the global 'user'",
    mine.length > 0 && mine.every((r: any) => r.actorRole === "auditor"),
    [...new Set(mine.map((r: any) => r.actorRole))].join(","),
  );
  check(
    "each names the auditor",
    mine.every((r: any) => (r.actorName ?? "").includes("Auditor")),
    mine[0]?.actorName ?? "none",
  );
  const posted = mine.filter((r: any) => r.action === "posted");
  check("postings are logged as 'posted'", posted.length >= 3, `${posted.length} posted rows`);
  check(
    "the transaction register is covered",
    mine.some((r: any) => r.entity === "transaction"),
    [...new Set(mine.map((r: any) => r.entity))].join(","),
  );

  console.log("\n=== 3. THE AUDITOR IS STILL REFUSED EVERY STRUCTURAL CHANGE ===");
  await expectRefused(() => auditorApi.org.upsert({ legalName: "Hijacked" } as any), "changing book settings");
  await expectRefused(
    () => auditorApi.periods.setStatus({ id: "00000000-0000-0000-0000-000000000000", status: "closed" } as any),
    "closing a period",
  );
  await expectRefused(
    () => auditorApi.access.invite({ email: "x@y.test", name: "X", role: "admin", password: "password123" } as any),
    "creating a user",
  );
  await expectRefused(
    () => auditorApi.access.setRole({ id: "00000000-0000-0000-0000-000000000000", role: "admin" } as any),
    "changing a role",
  );
  await expectRefused(
    () => auditorApi.access.remove({ id: "00000000-0000-0000-0000-000000000000" } as any),
    "deleting a user",
  );
  await expectRefused(() => auditorApi.access.setPublicSignup({ allow: true } as any), "opening public signup");
  await expectRefused(() => auditorApi.transactions.reverse({ id: txn.id, reason: "probe" } as any), "reversing a posted transaction");
  await expectRefused(() => auditorApi.reconciliation.save({} as any), "saving a reconciliation");
  await expectRefused(() => auditorApi.opening.save({} as any), "editing opening balances");
  await expectRefused(() => auditorApi.cash.upsert({ code: "X", name: "X" } as any), "editing the chart of accounts / cash accounts");
  await expectRefused(() => auditorApi.budgets.commit({ fiscalYear: 2026, name: "X" } as any), "committing a whole budget");
  await expectRefused(() => auditorApi.budgets.deleteLine({ id: line.id } as any), "deleting a budget line");
  await expectRefused(() => auditorApi.assets.remove({ id: asset.id } as any), "deleting an asset");
  await expectRefused(() => auditorApi.liabilities.remove({ id: lia.id } as any), "deleting a commitment");
  await expectRefused(() => auditorApi.sponsorship.remove({ id: pledge.id } as any), "deleting a sponsor");
  await expectRefused(() => auditorApi.members.create({ fullName: "X", memberType: "student" } as any), "creating a member");
  await expectRefused(() => auditorApi.export.book(), "exporting the whole book as a backup");

  console.log("\n=== 4. THE PRESIDENT IS STILL FULLY READ-ONLY ===");
  // Simulate the president by flipping the membership role for one call.
  await db.update(orgMembers).set({ role: "president" }).where(eq(orgMembers.userId, auditor.id));
  try {
    await expectRefused(
      () =>
        auditorApi.transactions.create({
          txnType: "Expense",
          txnDate: "2026-10-19",
          categoryCode: "5001",
          cashAccountCode: "CASH-01",
          amount: 10,
        } as any),
      "a president cannot post a transaction",
    );
  } finally {
    await db.update(orgMembers).set({ role: "auditor" }).where(eq(orgMembers.userId, auditor.id));
  }

  console.log("\n=== 5. CLEAN UP — THE BOOK IS LEFT AS FOUND ===");
  // Remove the probe rows. Journal entries are immutable, so the probe entries
  // are deleted directly here (this is a test harness, not the app).
  const probeTxns = await db
    .select()
    .from(transactions)
    .where(and(eq(transactions.ownerId, OWNER), like(transactions.payee, "AUDIT-PROBE%")));
  for (const t of probeTxns) {
    if (t.entryId) {
      await db.delete(journalEntries).where(eq(journalEntries.id, t.entryId));
    }
    await db.delete(transactions).where(eq(transactions.id, t.id));
  }
  const probeAssets = await db
    .select()
    .from(assets)
    .where(and(eq(assets.ownerId, OWNER), like(assets.description, "AUDIT-PROBE%")));
  for (const a of probeAssets) await db.delete(assets).where(eq(assets.id, a.id));
  const probeLias = await db
    .select()
    .from(liabilities)
    .where(and(eq(liabilities.ownerId, OWNER), like(liabilities.payee, "AUDIT-PROBE%")));
  for (const l of probeLias) {
    if (l.accrualEntryId) await db.delete(journalEntries).where(eq(journalEntries.id, l.accrualEntryId));
    await db.delete(liabilities).where(eq(liabilities.id, l.id));
  }
  const probeSponsors = await db
    .select()
    .from(sponsorship)
    .where(and(eq(sponsorship.ownerId, OWNER), like(sponsorship.sponsor, "AUDIT-PROBE%")));
  for (const s of probeSponsors) await db.delete(sponsorship).where(eq(sponsorship.id, s.id));
  const probeBudgets = await db
    .select()
    .from(budgets)
    .where(and(eq(budgets.ownerId, OWNER), like(budgets.name, "AUDIT-PROBE%")));
  for (const b of probeBudgets) {
    await db.delete(budgetLines).where(eq(budgetLines.budgetId, b.id));
    await db.delete(budgets).where(eq(budgets.id, b.id));
  }
  // The change-log rows the probe created are removed too, so the treasurer's
  // log is not polluted by a test run.
  await db.delete(changeLog).where(and(eq(changeLog.ownerId, OWNER), like(changeLog.summary, "%AUDIT-PROBE%")));

  const after = await ownerApi.reports.trialBalance({ to: "2027-09-30" } as any);
  const afterDiff = Number(after.difference ?? 0);
  check("the trial balance still nets to zero", afterDiff === 0, `difference ${afterDiff}`);
  check("it nets to the same figure as before the probe", afterDiff === beforeDiff, `${beforeDiff} → ${afterDiff}`);

  const [leftTxns] = await db
    .select({ n: transactions.id })
    .from(transactions)
    .where(and(eq(transactions.ownerId, OWNER), like(transactions.payee, "AUDIT-PROBE%")))
    .limit(1);
  check("no probe transaction is left behind", !leftTxns);

  console.log(`\n${pass} passed, ${fail} failed`);
  if (fail > 0) process.exit(1);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
