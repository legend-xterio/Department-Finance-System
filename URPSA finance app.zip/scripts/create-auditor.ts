/**
 * Create the association's read-only auditor account, scoped to the URPSA book.
 *
 * Goes through the REAL `access.invite` procedure rather than inserting rows, so
 * the account is created exactly the way the Security page creates one: same
 * password hashing, same role validation, same change-log entry. Idempotent —
 * re-running it reports the existing account instead of failing.
 *
 * The password is a temporary one the treasurer hands over; it is printed here
 * because this is a one-off setup script run by the treasurer's own agent, and
 * it is a placeholder identity meant to be renamed and re-passworded.
 */
import "dotenv/config";
import { eq } from "drizzle-orm";
import { appRouter } from "../server/routers";
import { db } from "../server/_core/db";
import { orgMembers, users } from "../drizzle/schema";

const OWNER = process.env.VERIFY_OWNER ?? "";
if (!OWNER) throw new Error("VERIFY_OWNER is not set");

const AUDITOR_EMAIL = "auditor@urpsa.test";
const AUDITOR_NAME = "URPSA Auditor";
const TEMP_PASSWORD = "auditor2026";

function fakeCtx() {
  const headers: Record<string, string> = { host: "localhost:3000" };
  return {
    req: { url: "http://localhost:3000/trpc", header: (k: string) => headers[k.toLowerCase()] },
    header: (k: string, v: string) => {
      headers[k.toLowerCase()] = v;
    },
    setCookie: () => {},
    getCookie: () => undefined,
  } as any;
}

async function main() {
  const [owner] = await db.select().from(users).where(eq(users.id, OWNER)).limit(1);
  if (!owner) throw new Error(`No owner ${OWNER}`);

  const api = appRouter.createCaller({
    user: { id: owner.id, email: owner.email, name: owner.name, role: "user" },
    c: fakeCtx(),
  } as any);

  const [existingUser] = await db.select().from(users).where(eq(users.email, AUDITOR_EMAIL)).limit(1);
  if (existingUser) {
    const [membership] = await db
      .select()
      .from(orgMembers)
      .where(eq(orgMembers.userId, existingUser.id))
      .limit(1);
    if (membership) {
      console.log(`ALREADY EXISTS: ${AUDITOR_EMAIL} → role=${membership.role} book=${membership.ownerId}`);
      console.log(`Password unchanged. Reset it from Security → Access if it is unknown.`);
      process.exit(0);
    }
    // Account exists but has no book — grant it the auditor role.
    const [row] = await db
      .insert(orgMembers)
      .values({
        ownerId: owner.id,
        userId: existingUser.id,
        role: "auditor",
        displayName: AUDITOR_NAME,
        createdBy: owner.id,
      })
      .returning();
    console.log(`GRANTED: ${AUDITOR_EMAIL} → role=${row.role} book=${row.ownerId}`);
    process.exit(0);
  }

  const res = await api.access.invite({
    email: AUDITOR_EMAIL,
    name: AUDITOR_NAME,
    role: "auditor",
    password: TEMP_PASSWORD,
  });

  console.log(`CREATED: ${res.email}`);
  console.log(`  role:     ${res.role}`);
  console.log(`  book:     ${OWNER} (URPSA)`);
  console.log(`  password: ${res.password}`);
  process.exit(0);
}

main().catch((e) => {
  console.error("FAILED:", e?.message ?? e);
  process.exit(1);
});
