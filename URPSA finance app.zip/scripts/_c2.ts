import "dotenv/config";
import { sql } from "drizzle-orm";
import { db } from "../server/_core/db";
async function main(){
  const r = await db.execute(sql.raw(`select table_name||'.'||column_name c from information_schema.columns
    where table_schema='public' and table_name in ('members','sponsorship','assets','liabilities')
    and (column_name like 'archived%' or column_name like 'restriction' or column_name like 'expected%'
      or column_name like 'disposal%' or column_name like 'settled%' or column_name like 'settlement%'
      or column_name like 'status' or column_name='notes') order by 1`));
  console.log((r.rows as any[]).map(x=>x.c).join("\n"));
  const n = await db.execute(sql.raw(`select (select count(*) from transactions) t,(select count(*) from journal_entries) je,(select count(*) from members) m,(select count(*) from assets) a,(select count(*) from liabilities) l,(select count(*) from sponsorship) s`));
  console.log("\nCOUNTS:", JSON.stringify(n.rows[0]));
}
main().then(()=>process.exit(0)).catch(e=>{console.error(e.message);process.exit(1)});
