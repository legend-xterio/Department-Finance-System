import "dotenv/config";
import { db } from "../server/_core/db";
import { sql } from "drizzle-orm";
async function main(){
  const r = await db.execute(sql`select table_name, column_name from information_schema.columns where column_name in ('archived_at','restriction','expected_date','disposal_date','settled_date','disposal_reason') order by table_name,column_name`);
  console.log(JSON.stringify(r.rows,null,1));
}
main().then(()=>process.exit(0));
