import "dotenv/config";
import { appRouter } from "../server/routers";
import { db } from "../server/_core/db";
import { sql } from "drizzle-orm";
const OWNER = "7783e909-bd24-4fb0-8184-fbc8050b8026";
const api = appRouter.createCaller({ user: { id: OWNER, email: "treasurer@urpsa.test", name: "URPSA Treasurer", role: "user" } } as any);
(async () => {
  const rows = await api.liabilities.list();
  for (const l of rows as any[]) {
    if (l.approvalStatus === "Approved" && l.status === "outstanding" && !l.accrualEntryId) {
      console.log("accruing", l.liabilityId, l.payee, l.amountCommitted);
      const [ev] = (await db.execute(sql`insert into evidence (owner_id, evidence_id, doc_type, description, status, storage_key, file_path, mime_type, file_size_bytes)
        values (${OWNER}, ${"EV-" + l.liabilityId}, 'invoice', ${"Commitment " + l.liabilityId}, 'verified', ${"seed/" + l.liabilityId}, ${"seed/" + l.liabilityId}, 'application/pdf', 1000)
        on conflict do nothing returning id`)).rows as any[];
      const evId = ev?.id ?? ((await db.execute(sql`select id from evidence where owner_id=${OWNER} and evidence_id=${"EV-" + l.liabilityId}`)).rows as any[])[0].id;
      const r = await api.liabilities.accrue({ id: l.id, entryDate: l.dateIncurred ?? "2026-10-01", evidenceIds: [evId] });
      console.log("  ->", (r as any).accrualEntryId ? "recognised" : "NOT recognised");
    }
  }
  const t = await db.execute(sql`select
    (select coalesce(sum(debit-credit),0) from journal_lines where owner_id=${OWNER}) tb,
    (select coalesce(sum(credit-debit),0) from journal_lines jl join accounts a on a.code=jl.account_code where jl.owner_id=${OWNER} and a.type='liability') liab`);
  console.log("AFTER:", JSON.stringify(t.rows));
  process.exit(0);
})().catch(e=>{console.error(e.message); process.exit(1);});
