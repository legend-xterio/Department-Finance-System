import "dotenv/config";
import { appRouter } from "../server/routers";
import { db } from "../server/_core/db";
import { sql } from "drizzle-orm";

const OWNER = "7783e909-bd24-4fb0-8184-fbc8050b8026";
const ctx = { user: { id: OWNER, email: "treasurer@urpsa.test", name: "URPSA Treasurer", role: "user" } } as any;
const api = appRouter.createCaller(ctx);

const ok: string[] = [];
const fail: string[] = [];
function check(name: string, cond: boolean, detail = "") {
  (cond ? ok : fail).push(`${name}${detail ? " — " + detail : ""}`);
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${detail ? " — " + detail : ""}`);
}

async function recon(tag: string) {
  const [r] = (await db.execute(sql`
    select
      (select coalesce(sum(debit-credit),0) from journal_lines where owner_id=${OWNER}) as tb,
      (select coalesce(sum(debit-credit),0) from journal_lines jl join accounts a on a.code=jl.account_code where jl.owner_id=${OWNER} and a.type='asset') as assets,
      (select coalesce(sum(credit-debit),0) from journal_lines jl join accounts a on a.code=jl.account_code where jl.owner_id=${OWNER} and a.type='liability') as liab,
      (select coalesce(sum(credit-debit),0) from journal_lines jl join accounts a on a.code=jl.account_code where jl.owner_id=${OWNER} and a.type in ('equity','income')) as fi,
      (select coalesce(sum(debit-credit),0) from journal_lines jl join accounts a on a.code=jl.account_code where jl.owner_id=${OWNER} and a.type='expense') as exp
  `)).rows as any[];
  const assets = Number(r.assets), liab = Number(r.liab), exp = Number(r.exp);
  const funds = Number(r.fi) - exp;
  const diff = Math.round((assets - liab - funds) * 100) / 100;
  console.log(`  [${tag}] TB=${Number(r.tb).toFixed(2)}  A=${assets.toFixed(2)}  L=${liab.toFixed(2)}  F=${funds.toFixed(2)}  BSdiff=${diff.toFixed(2)}`);
  return { tb: Number(r.tb), diff, assets, liab, funds };
}


async function makeEvidence(tag: string) {
  const [r] = (await db.execute(sql`select count(*)::int as n from evidence where owner_id=${OWNER}`)).rows as any[];
  const evidenceId = `EV-E2E-${tag}`;
  await db.execute(sql`
    insert into evidence (owner_id, evidence_id, doc_type, description, status, storage_key, file_path, mime_type, file_size_bytes)
    values (${OWNER}, ${evidenceId}, 'receipt', ${"E2E " + tag}, 'verified', ${"e2e/" + tag}, ${"e2e/" + tag}, 'application/pdf', 1000)
    on conflict do nothing
  `);
  const [e] = (await db.execute(sql`select id from evidence where owner_id=${OWNER} and evidence_id=${evidenceId} limit 1`)).rows as any[];
  return e.id as string;
}

(async () => {
  console.log("=== BEFORE ===");
  await recon("before");

  // ---- 1. BUDGET LINE CRUD ----
  const budgets = await api.budgets.list();
  const b = budgets[0];
  const newLine = await api.budgets.saveLine({ budgetId: b.id, accountCode: "5007", amount: 12345.67, periodNo: 0 });
  check("budget.saveLine create", !!newLine.id);
  const edited = await api.budgets.saveLine({ id: newLine.id, accountCode: "5007", amount: 9999.99, periodNo: 0 });
  check("budget.saveLine edit", Number((edited as any).amount) === 9999.99);
  const linesAfter = await api.budgets.lines({ budgetId: b.id });
  check("budget.lines sees new line", linesAfter.some((l: any) => l.id === newLine.id));
  await api.budgets.deleteLine({ id: newLine.id });
  const linesFinal = await api.budgets.lines({ budgetId: b.id });
  check("budget.deleteLine", !linesFinal.some((l: any) => l.id === newLine.id));

  // guard: heading account refused
  let headingRefused = false;
  try { await api.budgets.saveLine({ budgetId: b.id, accountCode: "5000", amount: 1, periodNo: 0 }); }
  catch { headingRefused = true; }
  check("budget refuses a heading account", headingRefused);

  // drill-down
  const v = await api.budgets.variance({ budgetId: b.id });
  const firstLine: any = (v as any).rows?.find((l: any) => l.actual > 0);
  if (firstLine) {
    const d = await api.budgets.lineDetail({ accountCode: firstLine.accountCode, activityCode: firstLine.activityCode ?? undefined });
    check("budget.lineDetail returns transactions", d.count > 0, `${d.count} receipts, total ${d.total.toFixed(2)}`);
    check("budget.lineDetail ties to ledger", Math.abs(d.difference) < 0.01, `difference ${d.difference}`);
  } else {
    check("budget.lineDetail ties to ledger", false, "no line with actual spend found");
  }
  const actD = await api.budgets.lineDetail({ activityCode: "FRESH-ORI-2026-27" });
  check("budget.lineDetail activity-level", actD.count >= 0, `${actD.count} receipts`);

  // ---- 2. SPONSORSHIP ----
  const sp = await api.sponsorship.upsert({ sponsor: "E2E Test Sponsor", amountPledged: 50000, stage: "pledged", restriction: "restricted" });
  check("sponsorship.upsert create", !!(sp as any).sponsorshipId, (sp as any).sponsorshipId);
  const spEdit = await api.sponsorship.upsert({ sponsorshipId: (sp as any).sponsorshipId, sponsor: "E2E Test Sponsor Ltd", amountPledged: 60000, stage: "negotiating", restriction: "designated", notes: "edited" });
  check("sponsorship.upsert edit", (spEdit as any).sponsor === "E2E Test Sponsor Ltd" && Number((spEdit as any).amountPledged) === 60000);

  const beforeReceipt = await recon("pre-receipt");
  const evId = await makeEvidence("receipt");
  const rec = await api.sponsorship.recordReceipt({ id: (spEdit as any).id, amount: 25000, receivedDate: "2026-10-20", cashAccountCode: "BANK-01", evidenceIds: [evId] });
  check("sponsorship.recordReceipt posted", !!rec);
  const afterReceipt = await recon("post-receipt");
  check("receipt keeps TB balanced", Math.abs(afterReceipt.tb) < 0.01, `TB ${afterReceipt.tb}`);
  check("receipt keeps BS identity", Math.abs(afterReceipt.diff) < 0.01, `diff ${afterReceipt.diff}`);
  const spList = await api.sponsorship.list();
  const mine: any = spList.find((s: any) => (s as any).sponsorshipId === (spEdit as any).sponsorshipId);
  check("receipt reflected on pledge", Number(mine.received) === 25000, `received ${mine.received}`);

  let spDelRefused = false;
  try { await api.sponsorship.remove({ id: (spEdit as any).id }); } catch (e: any) { spDelRefused = /receipt/i.test(e.message); }
  check("sponsorship.remove refuses when receipts exist", spDelRefused);

  // ---- 3. ASSETS ----
  const as = await api.assets.upsert({ description: "E2E Test Projector", category: "equipment", cost: 120000, condition: "good" });
  check("assets.upsert create", !!(as as any).assetId, (as as any).assetId);
  const asEdit = await api.assets.upsert({ assetId: (as as any).assetId, description: "E2E Test Projector (edited)", category: "equipment", cost: 125000, condition: "fair", custodian: "E2E Custodian" });
  check("assets.upsert edit", Number((asEdit as any).cost) === 125000);
  const preDisp = await recon("pre-disposal");
  const disp = await api.assets.dispose({ id: (asEdit as any).id, disposalDate: "2026-10-22", disposalReason: "Sold to another department", proceeds: 30000, cashAccountCode: "BANK-01", evidenceIds: [await makeEvidence("disposal")] });
  check("assets.dispose marks disposed", (disp as any).status === "disposed");
  const postDisp = await recon("post-disposal");
  check("disposal keeps TB balanced", Math.abs(postDisp.tb) < 0.01);
  check("disposal keeps BS identity", Math.abs(postDisp.diff) < 0.01);
  let dispDelRefused = false;
  try { await api.assets.remove({ id: (asEdit as any).id }); } catch (e: any) { dispDelRefused = /proceeds/i.test(e.message); }
  check("assets.remove refuses when proceeds posted", dispDelRefused);

  // ---- 4. LIABILITIES ----
  const li = await api.liabilities.upsert({ payee: "E2E Vendor", amountCommitted: 80000, approvalStatus: "Approved", dueDate: "2026-11-30", dateIncurred: "2026-10-15", evidenceIds: [await makeEvidence("liability")] });
  check("liabilities.upsert create", !!(li as any).liabilityId, (li as any).liabilityId);
  check("approved commitment is accrued on create", !!(li as any).accrualEntryId);
  const liEdit = await api.liabilities.upsert({ liabilityId: (li as any).liabilityId, payee: "E2E Vendor Ltd", amountCommitted: 85000, approvalStatus: "Approved" });
  check("liabilities.upsert edit", Number((liEdit as any).amountCommitted) === 85000);

  let overRefused = false;
  try { await api.liabilities.settle({ id: (liEdit as any).id, settledDate: "2026-10-23", amount: 999999, cashAccountCode: "BANK-01" }); }
  catch (e: any) { overRefused = /cannot settle/i.test(e.message); }
  check("liability refuses over-settlement", overRefused);

  const preSettle = await recon("pre-settle");
  const st = await api.liabilities.settle({ id: (liEdit as any).id, settledDate: "2026-10-23", amount: 85000, cashAccountCode: "BANK-01", settlementRef: "E2E-REF", evidenceIds: [await makeEvidence("settle")] });
  check("liabilities.settle marks settled", (st as any).status === "settled");
  const postSettle = await recon("post-settle");
  check("settlement keeps TB balanced", Math.abs(postSettle.tb) < 0.01);
  check("settlement keeps BS identity", Math.abs(postSettle.diff) < 0.01);
  check("settlement reduced liabilities", postSettle.liab < preSettle.liab, `${preSettle.liab} -> ${postSettle.liab}`);

  // ---- 5. MEMBERS ----
  const nid = await api.members.nextId({ admissionYear: "2026" });
  check("members.nextId follows URPSA/YY/XXX", /^URPSA\/26\/\d{3}$/.test((nid as any).memberId), (nid as any).memberId);
  const nm = await api.members.create({ fullName: "E2E Test Member", admissionYear: "2026", level: "300", phone: "08000000000" });
  check("members.create", /^URPSA\/26\/\d{3}$/.test((nm as any).memberId), (nm as any).memberId);
  const nmEdit = await api.members.update({ id: (nm as any).id, fullName: "E2E Test Member Edited", memberId: (nm as any).memberId, level: "400", status: "active" });
  check("members.update", (nmEdit as any).fullName === "E2E Test Member Edited");
  let idChangeRefused = false;
  try { await api.members.update({ id: (nm as any).id, fullName: "X", memberId: "URPSA/26/999", status: "active" }); }
  catch (e: any) { idChangeRefused = /cannot be changed/i.test(e.message); }
  check("members.update refuses ID change", idChangeRefused);
  let badIdRefused = false;
  try { await api.members.create({ fullName: "Bad", memberId: "URPSA/26/1" }); } catch { badIdRefused = true; }
  check("members.create refuses malformed ID", badIdRefused);
  const arch = await api.members.archive({ id: (nm as any).id, archived: true });
  check("members.archive", !!(arch as any).archivedAt);
  const activeList = await api.members.list({});
  check("archived member leaves active list", !activeList.some((m: any) => m.id === (nm as any).id));
  const withArch = await api.members.list({ includeArchived: true });
  check("archived member still reachable", withArch.some((m: any) => m.id === (nm as any).id));
  const unarch = await api.members.archive({ id: (nm as any).id, archived: false });
  check("members.restore", !(unarch as any).archivedAt);
  const del = await api.members.remove({ id: (nm as any).id });
  check("members.remove clean member", (del as any).ok === true);

  // member with references must refuse deletion
  const seeded = await api.members.list({});
  const withRef: any = seeded.find((m: any) => m.memberId && m.memberId.length > 0);
  // try to find one that has dues
  const duesList = await api.dues.list();
  const refMember = duesList.length ? seeded.find((m: any) => m.memberId === duesList[0].memberId) : null;
  if (refMember) {
    let refRefused = false;
    try { await api.members.remove({ id: refMember.id }); } catch (e: any) { refRefused = /Archive/.test(e.message); }
    check("members.remove refuses when dues exist", refRefused);
  }

  // dues edit
  if (duesList.length) {
    const d: any = duesList[0];
    const dEdit = await api.dues.update({ id: d.id, duesType: d.duesType, amountAssessed: 7500 });
    check("dues.update", Number((dEdit as any).amountAssessed) === 7500);
    await api.dues.update({ id: d.id, duesType: d.duesType, amountAssessed: Number(d.amountAssessed) });
  }

  // ---- 6. REPORTS + CSV ----
  const { incomeExpenditureCsv, financialPositionCsv, cashFlowCsv, trialBalanceCsv, controlChecksCsv } = await import("../shared/report-csv");
  const ie = await api.reports.incomeAndExpenditure({});
  const pos = await api.reports.financialPosition({});
  const cf = await api.reports.cashFlow({});
  const tbal = await api.reports.trialBalance({});
  const ctl = await api.reports.controlChecks({});

  const csv = [
    ["ie", incomeExpenditureCsv(ie as any, "2026-10-26")],
    ["pos", financialPositionCsv(pos as any, "2026-10-26")],
    ["cf", cashFlowCsv(cf as any, "2026-10-26")],
    ["tb", trialBalanceCsv(tbal as any, "2026-10-26")],
    ["ctl", controlChecksCsv(ctl as any, "2026-10-26")],
  ] as const;
  for (const [k, s] of csv) check(`csv ${k} non-trivial`, s.split("\n").length > 3, `${s.split("\n").length} lines`);

  console.log("\n=== TRIAL BALANCE ===");
  const tbRows = (tbal as any).rows ?? (tbal as any).accounts ?? [];
  console.log("  totalDebit:", (tbal as any).totalDebit, " totalCredit:", (tbal as any).totalCredit, " diff:", (tbal as any).difference);

  console.log("\n=== CONTROLS ===");
  const checks = (ctl as any).checks ?? [];
  for (const c of checks) console.log(`  ${c.name}: ${c.pass ? "PASS" : "FAIL"} (${c.actual} vs ${c.expected}, diff ${c.difference})`);

  console.log("\n=== FINAL ===");
  const final = await recon("final");
  check("final TB zero", Math.abs(final.tb) < 0.01, final.tb.toFixed(2));
  check("final BS identity zero", Math.abs(final.diff) < 0.01, final.diff.toFixed(2));

  console.log(`\n===== ${ok.length} passed, ${fail.length} failed =====`);
  if (fail.length) { console.log("FAILURES:"); fail.forEach((f) => console.log("  - " + f)); }
  process.exit(fail.length ? 1 : 0);
})().catch((e) => { console.error("FATAL", e); process.exit(1); });
