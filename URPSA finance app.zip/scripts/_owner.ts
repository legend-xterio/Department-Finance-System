import "dotenv/config";
import { sql } from "drizzle-orm";
import { db } from "../server/_core/db";
const r: any = await db.execute(sql`select id, email from users limit 1`);
console.log(r.rows[0].id);
process.exit(0);
