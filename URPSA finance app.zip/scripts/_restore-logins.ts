/**
 * Restore the two documented logins on the EXISTING URPSA book.
 *
 * The dev database was re-provisioned between runs, so the treasurer and auditor
 * accounts were gone while the book itself (24 accounts, 0 entries) survived
 * under the human owner's account. This puts the documented state back:
 *
 *   treasurer@urpsa.test  owns the URPSA book (full access)
 *   auditor@urpsa.test    member of the same book, role=auditor (read-only)
 *   the human owner       kept as an admin member, so nobody loses access
 *
 * Idempotent: re-running reports what already exists.
 */
import "dotenv/config";
import { eq } from "drizzle-orm";
import { db } from "../server/_core/db";
import { cashAccounts, orgMembers, orgs, users } from "../drizzle/schema";
import { hash as bcryptHash } from "bcryptjs";

const TREASURER_EMAIL = "treasurer@urpsa.test";
const TREASURER_PW = "urpsa2026";
const AUDITOR_EMAIL = "auditor@urpsa.test";
const AUDITOR_PW = "auditor2026";

async function ensureUser(email: string, name: string, password: string) {
  const [existing] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing) return existing;
  const passwordHash = await bcryptHash(password, 10);
  const [created] = await db.insert(users).values({ email, passwordHash, name }).returning();
  return created;
}

async function main() {
  const [org] = await db.select().from(orgs).limit(1);
  if (!org) throw new Error("no org row");
  const previousOwner = org.ownerId;

  const treasurer = await ensureUser(TREASURER_EMAIL, "URPSA Treasurer", TREASURER_PW);
  const auditor = await ensureUser(AUDITOR_EMAIL, "URPSA Auditor", AUDITOR_PW);

  // The treasurer owns the book.
  if (org.ownerId !== treasurer.id) {
    await db.update(orgs).set({ ownerId: treasurer.id }).where(eq(orgs.id, org.id));
  }

  // The human who was the owner keeps full access as an admin member.
  if (previousOwner && previousOwner !== treasurer.id) {
    const [m] = await db.select().from(orgMembers).where(eq(orgMembers.userId, previousOwner)).limit(1);
    if (!m) {
      await db.insert(orgMembers).values({
        ownerId: treasurer.id,
        userId: previousOwner,
        role: "admin",
        displayName: "Book owner",
        createdBy: treasurer.id,
      });
    }
  }

  // The auditor is a read-only member of the SAME book.
  const [am] = await db.select().from(orgMembers).where(eq(orgMembers.userId, auditor.id)).limit(1);
  if (!am) {
    await db.insert(orgMembers).values({
      ownerId: treasurer.id,
      userId: auditor.id,
      role: "auditor",
      displayName: "URPSA Auditor",
      createdBy: treasurer.id,
    });
  } else if (am.ownerId !== treasurer.id || am.role !== "auditor") {
    await db.update(orgMembers).set({ ownerId: treasurer.id, role: "auditor" }).where(eq(orgMembers.id, am.id));
  }

  // The cash accounts. Without these NOTHING can be posted — every transaction
  // names a cash account, and the posting engine refuses an unknown code. The
  // re-provisioned database had the 24-account chart but no cash accounts, so
  // the book looked healthy and refused every entry.
  const existingCash = await db.select().from(cashAccounts).where(eq(cashAccounts.ownerId, treasurer.id));
  if (existingCash.length === 0) {
    await db.insert(cashAccounts).values([
      {
        ownerId: treasurer.id,
        code: "BANK-01",
        name: "URPSA Main Bank Account",
        accountType: "bank",
        glAccountCode: "1012",
        details: "UNILAG Microfinance Bank — current account",
        openingBalance: "0.00",
        openingDate: String(org.periodStart).slice(0, 10),
      },
      {
        ownerId: treasurer.id,
        code: "CASH-01",
        name: "Petty Cash",
        accountType: "cash",
        glAccountCode: "1011",
        details: "Treasurer's cash box",
        openingBalance: "0.00",
        openingDate: String(org.periodStart).slice(0, 10),
      },
    ]);
    console.log("  cash accounts restored (BANK-01 → 1012, CASH-01 → 1011)");
  }

  // The fiscal periods. Without a period covering a date, the posting engine
  // refuses every entry ("No fiscal period covers …") — the second half of the
  // same re-provisioning gap as the missing cash accounts.
  const existingPeriods = await db
    .select({ n: fiscalPeriods.periodNo })
    .from(fiscalPeriods)
    .where(eq(fiscalPeriods.ownerId, treasurer.id));
  if (existingPeriods.length === 0) {
    const start = new Date(String(org.periodStart).slice(0, 10) + "T00:00:00Z");
    const rows = Array.from({ length: 12 }, (_, i) => {
      const s = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + i, 1));
      const e = new Date(Date.UTC(s.getUTCFullYear(), s.getUTCMonth() + 1, 0));
      return {
        ownerId: treasurer.id,
        fiscalYear: start.getUTCFullYear(),
        periodNo: i + 1,
        startDate: s.toISOString().slice(0, 10),
        endDate: e.toISOString().slice(0, 10),
        status: "open",
      };
    });
    await db.insert(fiscalPeriods).values(rows);
    console.log(`  fiscal periods restored (${rows.length} months from ${rows[0].startDate})`);
  }

  const members = await db.select().from(orgMembers);
  console.log(JSON.stringify({
    book: org.id,
    owner: treasurer.email,
    members: members.map((m: any) => ({ userId: m.userId, role: m.role })),
  }, null, 1));
  process.exit(0);
}
main().catch((e) => { console.error("FAILED:", e?.message ?? e); process.exit(1); });
