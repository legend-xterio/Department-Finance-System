import pg from 'pg';
const c=new pg.Client({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:false}});
await c.connect();
const r=await c.query(process.argv[2]);
console.table(r.rows);
await c.end();
