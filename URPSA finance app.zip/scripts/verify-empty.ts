/**
 * Verify the EMPTY book: every statement must open, reconcile to zero, and the
 * control checks must pass on a ledger with no postings at all.
 *
 * Then prove the app still WORKS on an empty book — post a transaction through
 * the real router, confirm the ledger balances, and reverse it — so "empty but
 * fully working" is demonstrated rather than assumed. The reversal leaves the
 * book empty again (a reversal is a second entry, so the test cleans up after
 * itself by deleting both).
 */
import "dotenv/config";
import { eq, sql } from "drizzle-orm";
import { appRouter } from "../server/routers";
import { db } from "../server/_core/db";
import { evidence, journalEntries, journalLines, transactions } from "../drizzle/schema";
import * as rep from "../server/reports";

const OWNER = process.env.VERIFY_OWNER ?? "";
const ctx = { user: { id: OWNER, email: "treasurer@urpsa.test", name: "URPSA Treasurer", role: "user" } } as any;
const api = appRouter.createCaller(ctx);

let pass = 0;
let fail = 0;
function check(name: string, cond: boolean, detail = "") {
  if (cond) pass++;
  else fail++;
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${detail ? " — " + detail : ""}`);
}

const f = (n: number) => n.toFixed(2);

async function counts() {
  const r: any = await db.execute(sql`
    select
      (select count(*)::int from transactions where owner_id=${OWNER}) as txn,
      (select count(*)::int from journal_entries where owner_id=${OWNER}) as je,
      (select count(*)::int from journal_lines where owner_id=${OWNER}) as jl,
      (select count(*)::int from members where owner_id=${OWNER}) as mem,
      (select count(*)::int from budgets where owner_id=${OWNER}) as bud,
      (select count(*)::int from activities where owner_id=${OWNER}) as act,
      (select count(*)::int from sponsorship where owner_id=${OWNER}) as spo,
      (select count(*)::int from assets where owner_id=${OWNER}) as ast,
      (select count(*)::int from liabilities where owner_id=${OWNER}) as lia,
      (select count(*)::int from evidence where owner_id=${OWNER}) as ev
  `);
  return r.rows[0];
}

console.log("── 1. The book is empty ──────────────────────────────────────────");
const c0 = await counts();
for (const [k, v] of Object.entries(c0)) check(`no ${k} rows`, Number(v) === 0, String(v));

console.log("\n── 2. Every statement opens and reconciles to zero ───────────────");
const ie = await rep.incomeAndExpenditure(OWNER);
check("income & expenditure opens", true, `income ${f(ie.totalIncome)} / expenditure ${f(ie.totalExpenditure)} / surplus ${f(ie.surplus)}`);
check("surplus is zero", ie.surplus === 0, f(ie.surplus));

const pos = await rep.financialPosition(OWNER);
check("financial position opens", true, `assets ${f(pos.totalAssets)} = L ${f(pos.totalLiabilities)} + F ${f(pos.totalFunds)} + result ${f(pos.currentSurplus)}`);
check("balance-sheet identity is zero", pos.difference === 0, f(pos.difference));

const cf = await rep.cashFlow(OWNER);
check("cash flow opens", true, `op ${f(cf.operating)} / inv ${f(cf.investing)} / fin ${f(cf.financing)} / closing ${f(cf.closingCash)}`);
check("cash flow reconciles to zero", cf.difference === 0, f(cf.difference));

const tb = await rep.trialBalance(OWNER);
check("trial balance opens", true, `Dr ${f(tb.totalDebit)} = Cr ${f(tb.totalCredit)}`);
check("trial balance difference is zero", tb.difference === 0, f(tb.difference));

const checks = await rep.controlChecks(OWNER);
for (const c of checks) check(`control: ${c.name}`, c.pass, c.detail);
check("all six controls pass", checks.every((c) => c.pass), `${checks.filter((c) => c.pass).length}/${checks.length}`);

console.log("\n── 3. The app still WORKS on an empty book ───────────────────────");
// A member can be created with the URPSA/YY/XXX rule.
const nextId = await api.members.nextId({ admissionYear: "2026" });
check("member ID follows URPSA/YY/XXX", /^URPSA\/\d{2}\/\d{3}$/.test(nextId.memberId), nextId.memberId);

const member = await api.members.create({
  fullName: "Verification Member",
  admissionYear: "2026",
  level: "300",
});
check("member created", !!member?.memberId, member?.memberId);

// A budget line can be created on an empty book (creates the header).
const line = await api.budgets.saveLine({
  accountCode: "5001",
  amount: 100000,
  periodNo: 0,
});
check("budget line created on an empty book", !!line, "5001 / 100,000");

// The evidence gate must REFUSE a payment above the threshold with no document.
let refused = false;
try {
  await api.transactions.create({
    txnType: "Expense",
    txnDate: "2026-10-15",
    categoryCode: "5001",
    cashAccountCode: "BANK-01",
    payee: "No document",
    amount: 25000,
  });
} catch (e: any) {
  refused = /evidence/i.test(String(e?.message ?? ""));
}
check("evidence gate refuses a payment with no document", refused);

// With a verified document attached, the same payment posts.
const [ev] = await db
  .insert(evidence)
  .values({
    ownerId: OWNER,
    evidenceId: "EV-VERIFY-0001",
    docType: "receipt",
    description: "Verification receipt",
    status: "verified",
    storageKey: "verify/receipt",
    filePath: "verify/receipt",
    mimeType: "application/pdf",
    fileSizeBytes: 1000,
  })
  .returning();

const txn = await api.transactions.create({
  txnType: "Expense",
  txnDate: "2026-10-15",
  categoryCode: "5001",
  cashAccountCode: "BANK-01",
  payee: "Verification payee",
  amount: 25000,
  evidenceIds: [ev.id],
});
check("transaction posted with evidence", !!txn?.txnId, txn?.txnId);

const after = await rep.trialBalance(OWNER);
check("trial balance still balances after a posting", after.difference === 0, f(after.difference));
const pos2 = await rep.financialPosition(OWNER);
check("balance sheet still balances after a posting", pos2.difference === 0, f(pos2.difference));
const cf2 = await rep.cashFlow(OWNER);
check("cash flow still reconciles after a posting", cf2.difference === 0, f(cf2.difference));
check("cash moved by the posting", cf2.closingCash === -25000, f(cf2.closingCash));

// ── Clean up: remove the test rows so the book ships empty ──────────────────
const [t] = await db.select().from(transactions).where(eq(transactions.ownerId, OWNER));
if (t?.entryId) {
  await db.delete(journalLines).where(eq(journalLines.entryId, t.entryId));
  await db.delete(journalEntries).where(eq(journalEntries.id, t.entryId));
}
await db.delete(transactions).where(eq(transactions.ownerId, OWNER));
await db.execute(sql`delete from budget_lines where owner_id=${OWNER}`);
await db.execute(sql`delete from budgets where owner_id=${OWNER}`);
await db.execute(sql`delete from members where owner_id=${OWNER}`);
await db.execute(sql`delete from evidence where owner_id=${OWNER}`);

console.log("\n── 4. Clean again ────────────────────────────────────────────────");
const c1 = await counts();
for (const [k, v] of Object.entries(c1)) check(`cleaned: no ${k} rows`, Number(v) === 0, String(v));
const tbEnd = await rep.trialBalance(OWNER);
check("final trial balance is zero", tbEnd.difference === 0, f(tbEnd.difference));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail === 0 ? 0 : 1);
