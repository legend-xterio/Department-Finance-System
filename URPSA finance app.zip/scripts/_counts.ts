import "dotenv/config";
import { sql } from "drizzle-orm";
import { db } from "../server/_core/db";
const tables = ["users","files","items","accounts","orgs","cash_accounts","fiscal_periods","activities","members","dues","sponsorship","transactions","journal_entries","journal_lines","evidence","liabilities","assets","reconciliations","budgets","budget_lines"];
for (const t of tables) {
  const r: any = await db.execute(sql.raw(`select count(*)::int as c from ${t}`));
  console.log(t.padEnd(20), r.rows?.[0]?.c ?? r[0]?.c);
}
process.exit(0);
