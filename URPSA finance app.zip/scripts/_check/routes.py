"""Load every route as treasurer and as auditor; report console errors and failed requests."""
import json
import sys
from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"

ROUTES = [
    "/", "/transactions", "/budget", "/budget/new", "/sponsorship",
    "/members", "/registers", "/reports", "/reports?r=trial",
    "/reports?r=position", "/reports?r=cashflow", "/reports?r=controls",
    "/settings", "/settings?tab=org", "/settings?tab=opening",
    "/settings?tab=accounts", "/settings?tab=periods",
    "/settings?tab=reconciliation", "/settings?tab=backup",
    "/settings?tab=security", "/settings?tab=changelog",
    "/security", "/reconciliation", "/change-log", "/backup",
]

USERS = [
    ("treasurer", "treasurer@urpsa.test", "urpsa2026"),
    ("auditor", "auditor@urpsa.test", "auditor2026"),
]


def run(pw, label, email, password):
    browser = pw.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1440, "height": 900})
    page = ctx.new_page()
    problems = []

    page.on("console", lambda m: problems.append(("console", m.type, m.text))
            if m.type == "error" else None)
    page.on("pageerror", lambda e: problems.append(("pageerror", "", str(e))))
    page.on("requestfailed", lambda r: problems.append(
        ("requestfailed", r.method, f"{r.url} :: {r.failure}")))
    page.on("response", lambda r: problems.append(
        ("http", str(r.status), r.url)) if r.status >= 400 else None)

    page.goto(f"{BASE}/login", wait_until="networkidle")
    page.fill('input[type="email"]', email)
    page.fill('input[type="password"]', password)
    page.click('button[type="submit"]')
    page.wait_for_url(lambda u: "/login" not in u, timeout=20000)
    page.wait_for_load_state("networkidle")

    results = []
    for route in ROUTES:
        before = len(problems)
        page.goto(f"{BASE}{route}", wait_until="networkidle")
        page.wait_for_timeout(700)
        new = problems[before:]
        # Ignore favicon noise
        new = [p for p in new if "favicon" not in str(p).lower()]
        results.append({"route": route, "problems": new, "url": page.url})

    browser.close()
    return results


with sync_playwright() as pw:
    all_out = {}
    for label, email, password in USERS:
        all_out[label] = run(pw, label, email, password)

bad = 0
for label, results in all_out.items():
    print(f"\n===== {label.upper()} =====")
    for r in results:
        if r["problems"]:
            bad += 1
            print(f"  FAIL {r['route']}  -> {r['url']}")
            for p in r["problems"][:6]:
                print(f"        {p[0]} {p[1]}: {str(p[2])[:180]}")
        else:
            print(f"  ok   {r['route']}")

print(f"\nTOTAL ROUTES WITH PROBLEMS: {bad}")
sys.exit(1 if bad else 0)
