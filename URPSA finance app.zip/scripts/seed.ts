/**
 * URPSA seed — the workbook's REAL structure, plus a clearly-labelled
 * representative dataset so the dashboard and every report show live figures.
 *
 * WHAT IS REAL (from the workbook):
 *   • the 12-category chart of accounts (4001–4005 income, 5001–5007 expense)
 *   • BANK-01 / CASH-01 and the opening balance ₦104,099.50
 *   • the Control Centre settings (administration year 1 Oct 2026 – 30 Sep 2027)
 *   • the Fresher's Orientation activity and its approved budget line
 *   • the Conference activity
 *
 * WHAT IS REPRESENTATIVE: the workbook is a BLANK TEMPLATE — 20 formula-driven
 * sheets with zero transactions, zero members, zero dues and zero sponsorship
 * rows. So the transaction history below is demo data, labelled as such in the
 * app, and can be wiped with scripts/reset-demo.ts. It exists so the reports
 * have something to reconcile; it is NOT URPSA's actual 2026/2027 figures.
 *
 * Runs against the DEV database only (never a migration), so the published app
 * starts clean. Idempotent: re-running does nothing if the ledger already exists.
 *
 *   pnpm exec tsx scripts/seed.ts
 */
import "dotenv/config";
import { eq } from "drizzle-orm";
import { db } from "../server/_core/db";
import {
  activities,
  assets,
  budgetLines,
  budgets,
  cashAccounts,
  dues,
  evidence,
  fiscalPeriods,
  journalEntries,
  liabilities,
  members,
  orgs,
  reconciliations,
  sponsorship,
  transactions,
  users,
} from "../drizzle/schema";
import { postEntry, postTransaction } from "../server/posting";
import { registerLocalUser } from "../server/_core/auth";
import { fiscalMonths } from "../shared/finance";

const DEMO_EMAIL = "treasurer@urpsa.test";
const DEMO_PASSWORD = "urpsa2026";

// The administration year the workbook declares.
const PERIOD_START = "2026-10-01";
const PERIOD_END = "2027-09-30";
const CONVERSION_DATE = "2026-10-01";
const OPENING_BALANCE = 104099.5;

async function main() {
  console.log("Seeding URPSA…");

  // ── 1. The treasurer account ───────────────────────────────────────────────
  let [user] = await db.select().from(users).where(eq(users.email, DEMO_EMAIL)).limit(1);
  if (!user) {
    const created = await registerLocalUser(DEMO_EMAIL, DEMO_PASSWORD, "URPSA Treasurer");
    user = created as typeof user;
    console.log(`  created treasurer ${DEMO_EMAIL} / ${DEMO_PASSWORD}`);
  } else {
    console.log(`  treasurer already exists: ${DEMO_EMAIL}`);
  }
  const ownerId = user.id;

  // Idempotency guard.
  const existing = await db
    .select({ id: journalEntries.id })
    .from(journalEntries)
    .where(eq(journalEntries.ownerId, ownerId))
    .limit(1);
  if (existing.length > 0) {
    console.log("  ledger already seeded — nothing to do.");
    return;
  }

  // ── 2. Organisation (Control Centre) ───────────────────────────────────────
  await db.insert(orgs).values({
    ownerId,
    legalName: "University of Lagos Urban and Regional Planning Students' Association",
    shortName: "URPSA",
    baseCurrency: "NGN",
    periodStart: PERIOD_START,
    periodEnd: PERIOD_END,
    conversionDate: CONVERSION_DATE,
    openingBalanceStatus: OPENING_BALANCE.toFixed(2),
    financialSecretary: "Financial Secretary",
    treasurer: "Treasurer",
    president: "President",
    memberIdRule: "URPSA/YY/XXX",
    capitalisationThreshold: "50000.00",
    evidenceRequiredAbove: "5000.00",
  });
  console.log("  organisation created");

  // ── 3. Cash accounts (workbook "Accounts") ─────────────────────────────────
  await db.insert(cashAccounts).values([
    {
      ownerId,
      code: "BANK-01",
      name: "URPSA Main Bank Account",
      accountType: "bank",
      glAccountCode: "1012",
      details: "UNILAG Microfinance Bank — current account",
      openingBalance: OPENING_BALANCE.toFixed(2),
      openingDate: CONVERSION_DATE,
    },
    {
      ownerId,
      code: "CASH-01",
      name: "Petty Cash",
      accountType: "cash",
      glAccountCode: "1011",
      details: "Treasurer's cash box",
      openingBalance: "0.00",
      openingDate: CONVERSION_DATE,
    },
  ]);
  console.log("  cash accounts created");

  // ── 4. Fiscal periods — the 12 months of the administration year ───────────
  const months = fiscalMonths(PERIOD_START);
  await db.insert(fiscalPeriods).values(
    months.map((m) => ({
      ownerId,
      fiscalYear: 2027,
      periodNo: m.no,
      startDate: m.start,
      endDate: m.end,
      status: "open",
    })),
  );
  console.log("  12 fiscal periods created");

  // ── 5. Activities (workbook "Activities-Budgets") ──────────────────────────
  await db.insert(activities).values([
    {
      ownerId,
      code: "FRESH-ORI-2026-27",
      name: "Fresher's Orientation 2026/2027",
      startDate: "2026-10-05",
      endDate: "2026-10-16",
      budgetCategory: "Activities and events",
      approvedBudget: "450000.00",
      approver: "President",
      approvalDate: "2026-09-28",
      fundCode: "GEN",
      status: "completed",
    },
    {
      ownerId,
      code: "CONF-2026",
      name: "Annual Urban and Regional Planning Conference",
      startDate: "2027-03-12",
      endDate: "2027-03-14",
      budgetCategory: "Conference expense",
      approvedBudget: "600000.00",
      approver: "President",
      approvalDate: "2026-11-20",
      fundCode: "SPON",
      status: "active",
    },
    {
      ownerId,
      code: "WELF-2027",
      name: "Welfare and Member Support",
      startDate: PERIOD_START,
      endDate: PERIOD_END,
      budgetCategory: "Welfare",
      approvedBudget: "200000.00",
      approver: "President",
      approvalDate: "2026-09-28",
      fundCode: "GEN",
      status: "active",
    },
  ]);
  console.log("  activities created");

  // ── 6. Opening balance — the ONE real figure in the workbook ───────────────
  // Dr Bank, Cr Accumulated fund. This is the conversion entry.
  await postEntry({
    ownerId,
    entryDate: CONVERSION_DATE,
    description: "Opening balance brought forward at conversion",
    source: "opening",
    preparedBy: "URPSA Treasurer",
    bypassEvidenceGate: true,
    lines: [
      { accountCode: "1012", cashAccountCode: "BANK-01", debit: OPENING_BALANCE, memo: "Opening bank balance" },
      { accountCode: "3010", credit: OPENING_BALANCE, memo: "Accumulated fund at conversion" },
    ],
  });
  console.log(`  opening balance posted: ₦${OPENING_BALANCE.toLocaleString()}`);

  // ── 7. Members (representative) ────────────────────────────────────────────
  const memberRows = [
    ["URPSA/26/001", "Adebayo Ogunlesi", "300", "2026"],
    ["URPSA/26/002", "Chiamaka Nwosu", "300", "2026"],
    ["URPSA/26/003", "Ibrahim Suleiman", "300", "2026"],
    ["URPSA/26/004", "Funmilayo Adeyemi", "200", "2026"],
    ["URPSA/26/005", "Emeka Okonkwo", "200", "2026"],
    ["URPSA/26/006", "Zainab Bello", "200", "2026"],
    ["URPSA/26/007", "Tunde Bakare", "100", "2026"],
    ["URPSA/26/008", "Ngozi Eze", "100", "2026"],
    ["URPSA/26/009", "Yusuf Danjuma", "100", "2026"],
    ["URPSA/26/010", "Blessing Okafor", "100", "2026"],
    ["URPSA/26/011", "Samuel Adeleke", "300", "2026"],
    ["URPSA/26/012", "Halima Abubakar", "200", "2026"],
  ];
  await db.insert(members).values(
    memberRows.map(([memberId, fullName, level, admissionYear]) => ({
      ownerId,
      memberId,
      fullName,
      level,
      admissionYear,
      matricNumber: `PS${memberId.slice(-3)}${admissionYear}`,
      status: "active",
    })),
  );
  console.log(`  ${memberRows.length} members created`);

  // ── 8. Dues obligations ────────────────────────────────────────────────────
  await db.insert(dues).values(
    memberRows.map(([memberId], i) => ({
      ownerId,
      duesRef: `DUE-${String(i + 1).padStart(4, "0")}`,
      memberId,
      duesType: "Annual membership dues 2026/2027",
      dueDate: "2026-11-30",
      amountAssessed: "5000.00",
    })),
  );
  console.log("  dues obligations created");

  // ── 9. Sponsorship pipeline ────────────────────────────────────────────────
  await db.insert(sponsorship).values([
    {
      ownerId,
      sponsorshipId: "SPON-001",
      sponsor: "Zenith Bank Plc",
      purpose: "Annual Urban and Regional Planning Conference — headline sponsor",
      contact: "Corporate Affairs, Zenith Bank",
      commitmentDate: "2026-11-15",
      amountPledged: "500000.00",
      stage: "received",
      activityCode: "CONF-2026",
    },
    {
      ownerId,
      sponsorshipId: "SPON-002",
      sponsor: "Lagos State Ministry of Education",
      purpose: "Fresher's Orientation support",
      contact: "Directorate of Students' Affairs",
      commitmentDate: "2026-10-02",
      amountPledged: "250000.00",
      stage: "received",
      activityCode: "FRESH-ORI-2026-27",
    },
    {
      ownerId,
      sponsorshipId: "SPON-003",
      sponsor: "Dangote Foundation",
      purpose: "Conference delegate packs",
      contact: "Programmes Office",
      commitmentDate: "2027-01-20",
      amountPledged: "300000.00",
      stage: "contract_signed",
      activityCode: "CONF-2026",
    },
    {
      ownerId,
      sponsorshipId: "SPON-004",
      sponsor: "MTN Nigeria",
      purpose: "Welfare fund contribution",
      contact: "Foundation Team",
      commitmentDate: "2027-02-10",
      amountPledged: "150000.00",
      stage: "negotiating",
      activityCode: "WELF-2027",
    },
    {
      ownerId,
      sponsorshipId: "SPON-005",
      sponsor: "Access Bank Plc",
      purpose: "Conference refreshments",
      contact: "Brand Partnerships",
      commitmentDate: "2027-03-01",
      amountPledged: "120000.00",
      stage: "proposal_sent",
      activityCode: "CONF-2026",
    },
    {
      ownerId,
      sponsorshipId: "SPON-006",
      sponsor: "Guinness Nigeria",
      purpose: "Awards night",
      contact: "Events Team",
      commitmentDate: "2027-03-05",
      amountPledged: "200000.00",
      stage: "approached",
      activityCode: "CONF-2026",
    },
  ]);
  console.log("  sponsorship pipeline created");

  // ── 10. Evidence documents (so the gate has verified docs to accept) ───────
  const evRows = [
    ["EV-0001", "receipt", "Zenith Bank sponsorship credit advice", "verified"],
    ["EV-0002", "receipt", "Ministry of Education cheque deposit slip", "verified"],
    ["EV-0003", "invoice", "Fresher's Orientation venue invoice", "verified"],
    ["EV-0004", "receipt", "Printing and publicity receipts", "verified"],
    ["EV-0005", "receipt", "Transport reimbursement schedule", "verified"],
    ["EV-0006", "invoice", "Conference hall booking invoice", "verified"],
    ["EV-0007", "receipt", "Welfare disbursement schedule", "verified"],
    ["EV-0008", "receipt", "Bank charges advice", "verified"],
    ["EV-0009", "receipt", "Stationery and administration receipts", "verified"],
    ["EV-0010", "receipt", "Refreshments receipts", "verified"],
  ];
  await db.insert(evidence).values(
    evRows.map(([evidenceId, docType, description, status]) => ({
      ownerId,
      evidenceId,
      docType,
      description,
      status,
      dateReceived: "2026-10-05",
      submittedBy: "URPSA Treasurer",
      reviewedBy: "Financial Secretary",
    })),
  );
  const evIds = await db
    .select({ id: evidence.id, ref: evidence.evidenceId })
    .from(evidence)
    .where(eq(evidence.ownerId, ownerId));
  const evByRef = new Map(evIds.map((e) => [e.ref, e.id]));
  console.log("  evidence documents created");

  // ── 11. The transaction register (representative) ──────────────────────────
  // Each row is posted through postTransaction(), so the double entry is derived
  // and can never disagree with the register.
  type Txn = {
    date: string;
    type: "Income" | "Expense";
    cat: string;
    cash: string;
    payee: string;
    amount: number;
    activity?: string;
    member?: string;
    ref?: string;
    ev?: string;
  };

  const txns: Txn[] = [
    // ── October 2026: Fresher's Orientation ──
    { date: "2026-10-02", type: "Income", cat: "4002", cash: "BANK-01", payee: "Lagos State Ministry of Education", amount: 250000, activity: "FRESH-ORI-2026-27", ref: "SPON-002", ev: "EV-0002" },
    { date: "2026-10-05", type: "Expense", cat: "5003", cash: "BANK-01", payee: "UNILAG Events Centre — venue hire", amount: 120000, activity: "FRESH-ORI-2026-27", ev: "EV-0003" },
    { date: "2026-10-07", type: "Expense", cat: "5001", cash: "BANK-01", payee: "Campus Printers — banners and flyers", amount: 45000, activity: "FRESH-ORI-2026-27", ev: "EV-0004" },
    { date: "2026-10-09", type: "Expense", cat: "5002", cash: "CASH-01", payee: "Transport — orientation logistics", amount: 18500, activity: "FRESH-ORI-2026-27", ev: "EV-0005" },
    { date: "2026-10-12", type: "Expense", cat: "5003", cash: "BANK-01", payee: "Refreshments — orientation day", amount: 62000, activity: "FRESH-ORI-2026-27", ev: "EV-0010" },
    { date: "2026-10-15", type: "Income", cat: "4001", cash: "BANK-01", payee: "Membership dues — Adebayo Ogunlesi", amount: 5000, member: "URPSA/26/001" },
    { date: "2026-10-16", type: "Income", cat: "4001", cash: "CASH-01", payee: "Membership dues — Chiamaka Nwosu", amount: 5000, member: "URPSA/26/002" },
    { date: "2026-10-20", type: "Income", cat: "4001", cash: "BANK-01", payee: "Membership dues — Ibrahim Suleiman", amount: 5000, member: "URPSA/26/003" },
    { date: "2026-10-28", type: "Expense", cat: "5006", cash: "BANK-01", payee: "Bank charges — October", amount: 2500, ev: "EV-0008" },

    // ── November 2026 ──
    { date: "2026-11-04", type: "Income", cat: "4001", cash: "BANK-01", payee: "Membership dues — Funmilayo Adeyemi", amount: 5000, member: "URPSA/26/004" },
    { date: "2026-11-06", type: "Income", cat: "4001", cash: "CASH-01", payee: "Membership dues — Emeka Okonkwo", amount: 5000, member: "URPSA/26/005" },
    { date: "2026-11-11", type: "Expense", cat: "5001", cash: "BANK-01", payee: "Stationery and office supplies", amount: 22000, ev: "EV-0009" },
    { date: "2026-11-15", type: "Income", cat: "4002", cash: "BANK-01", payee: "Zenith Bank Plc", amount: 500000, activity: "CONF-2026", ref: "SPON-001", ev: "EV-0001" },
    { date: "2026-11-18", type: "Income", cat: "4001", cash: "BANK-01", payee: "Membership dues — Zainab Bello", amount: 5000, member: "URPSA/26/006" },
    { date: "2026-11-25", type: "Expense", cat: "5005", cash: "BANK-01", payee: "Welfare support — member medical assistance", amount: 35000, activity: "WELF-2027", ev: "EV-0007" },
    { date: "2026-11-28", type: "Expense", cat: "5006", cash: "BANK-01", payee: "Bank charges — November", amount: 2500, ev: "EV-0008" },

    // ── December 2026 ──
    { date: "2026-12-02", type: "Income", cat: "4001", cash: "BANK-01", payee: "Membership dues — Tunde Bakare", amount: 5000, member: "URPSA/26/007" },
    { date: "2026-12-05", type: "Income", cat: "4004", cash: "BANK-01", payee: "End-of-year fundraising dinner", amount: 185000, activity: "WELF-2027" },
    { date: "2026-12-09", type: "Expense", cat: "5003", cash: "BANK-01", payee: "End-of-year dinner — catering", amount: 96000, activity: "WELF-2027", ev: "EV-0010" },
    { date: "2026-12-14", type: "Expense", cat: "5005", cash: "BANK-01", payee: "Welfare — end-of-year member support", amount: 42000, activity: "WELF-2027", ev: "EV-0007" },
    { date: "2026-12-20", type: "Income", cat: "4001", cash: "CASH-01", payee: "Membership dues — Ngozi Eze", amount: 5000, member: "URPSA/26/008" },
    { date: "2026-12-28", type: "Expense", cat: "5006", cash: "BANK-01", payee: "Bank charges — December", amount: 2500, ev: "EV-0008" },

    // ── January 2027 ──
    { date: "2027-01-08", type: "Income", cat: "4001", cash: "BANK-01", payee: "Membership dues — Yusuf Danjuma", amount: 5000, member: "URPSA/26/009" },
    { date: "2027-01-12", type: "Expense", cat: "5001", cash: "BANK-01", payee: "Secretariat running costs", amount: 28000, ev: "EV-0009" },
    { date: "2027-01-20", type: "Income", cat: "4002", cash: "BANK-01", payee: "Dangote Foundation", amount: 300000, activity: "CONF-2026", ref: "SPON-003", ev: "EV-0001" },
    { date: "2027-01-26", type: "Expense", cat: "5004", cash: "BANK-01", payee: "Conference hall deposit", amount: 150000, activity: "CONF-2026", ev: "EV-0006" },
    { date: "2027-01-28", type: "Expense", cat: "5006", cash: "BANK-01", payee: "Bank charges — January", amount: 2500, ev: "EV-0008" },

    // ── February 2027 ──
    { date: "2027-02-03", type: "Income", cat: "4001", cash: "BANK-01", payee: "Membership dues — Blessing Okafor", amount: 5000, member: "URPSA/26/010" },
    { date: "2027-02-10", type: "Expense", cat: "5004", cash: "BANK-01", payee: "Conference — delegate packs and printing", amount: 88000, activity: "CONF-2026", ev: "EV-0006" },
    { date: "2027-02-17", type: "Income", cat: "4001", cash: "BANK-01", payee: "Membership dues — Samuel Adeleke", amount: 5000, member: "URPSA/26/011" },
    { date: "2027-02-24", type: "Expense", cat: "5002", cash: "CASH-01", payee: "Transport — conference planning visits", amount: 24000, activity: "CONF-2026", ev: "EV-0005" },
    { date: "2027-02-28", type: "Expense", cat: "5006", cash: "BANK-01", payee: "Bank charges — February", amount: 2500, ev: "EV-0008" },

    // ── March 2027: the conference ──
    { date: "2027-03-02", type: "Income", cat: "4001", cash: "BANK-01", payee: "Membership dues — Halima Abubakar", amount: 5000, member: "URPSA/26/012" },
    { date: "2027-03-10", type: "Income", cat: "4003", cash: "BANK-01", payee: "Conference registration fees — delegates", amount: 240000, activity: "CONF-2026" },
    { date: "2027-03-12", type: "Expense", cat: "5004", cash: "BANK-01", payee: "Conference — venue balance", amount: 180000, activity: "CONF-2026", ev: "EV-0006" },
    { date: "2027-03-13", type: "Expense", cat: "5004", cash: "BANK-01", payee: "Conference — catering and refreshments", amount: 132000, activity: "CONF-2026", ev: "EV-0010" },
    { date: "2027-03-14", type: "Expense", cat: "5004", cash: "CASH-01", payee: "Conference — speaker honoraria and logistics", amount: 65000, activity: "CONF-2026", ev: "EV-0006" },
    { date: "2027-03-28", type: "Expense", cat: "5006", cash: "BANK-01", payee: "Bank charges — March", amount: 2500, ev: "EV-0008" },

    // ── April 2027 ──
    { date: "2027-04-07", type: "Income", cat: "4005", cash: "BANK-01", payee: "Interest income — bank", amount: 12500 },
    { date: "2027-04-15", type: "Expense", cat: "5001", cash: "BANK-01", payee: "Annual audit and account review", amount: 55000, ev: "EV-0009" },
    { date: "2027-04-22", type: "Expense", cat: "5005", cash: "BANK-01", payee: "Welfare — member support disbursement", amount: 38000, activity: "WELF-2027", ev: "EV-0007" },
    { date: "2027-04-28", type: "Expense", cat: "5006", cash: "BANK-01", payee: "Bank charges — April", amount: 2500, ev: "EV-0008" },

    // ── May 2027 ──
    { date: "2027-05-06", type: "Income", cat: "4004", cash: "BANK-01", payee: "Alumni fundraising appeal", amount: 145000 },
    { date: "2027-05-14", type: "Expense", cat: "5003", cash: "BANK-01", payee: "Inter-departmental debate competition", amount: 72000, ev: "EV-0004" },
    { date: "2027-05-28", type: "Expense", cat: "5006", cash: "BANK-01", payee: "Bank charges — May", amount: 2500, ev: "EV-0008" },

    // ── June 2027 ──
    { date: "2027-06-09", type: "Expense", cat: "5001", cash: "BANK-01", payee: "Website and records digitisation", amount: 48000, ev: "EV-0009" },
    { date: "2027-06-18", type: "Income", cat: "4005", cash: "BANK-01", payee: "Sale of old association equipment", amount: 35000 },
    { date: "2027-06-28", type: "Expense", cat: "5006", cash: "BANK-01", payee: "Bank charges — June", amount: 2500, ev: "EV-0008" },
  ];

  let n = 0;
  for (const t of txns) {
    n += 1;
    const txnId = `TXN-${String(n).padStart(4, "0")}`;
    const description = t.payee;
    const entry = await postTransaction({
      ownerId,
      txnType: t.type,
      txnDate: t.date,
      categoryCode: t.cat,
      cashAccountCode: t.cash,
      amount: t.amount,
      description,
      activityCode: t.activity ?? null,
      documentRef: t.ref ?? null,
      preparedBy: "URPSA Treasurer",
      approvedBy: "Financial Secretary",
      evidenceIds: t.ev ? [evByRef.get(t.ev)!].filter(Boolean) : undefined,
      bypassEvidenceGate: !t.ev, // rows with no document are small and below threshold
    });
    await db.insert(transactions).values({
      ownerId,
      txnId,
      txnType: t.type,
      txnDate: t.date,
      categoryCode: t.cat,
      cashAccountCode: t.cash,
      payee: t.payee,
      memberId: t.member ?? null,
      reference: t.ref ?? null,
      amount: t.amount.toFixed(2),
      activityCode: t.activity ?? null,
      approvalStatus: "Approved",
      approvedBy: "Financial Secretary",
      entryId: entry.id,
    });
    if (t.ev) {
      await db
        .update(evidence)
        .set({ transactionId: txnId })
        .where(eq(evidence.id, evByRef.get(t.ev)!));
    }
  }
  console.log(`  ${txns.length} transactions posted with derived double entry`);

  // ── 12. Budget (workbook "Budget vs Actual") ───────────────────────────────
  const [budget] = await db
    .insert(budgets)
    .values({ ownerId, fiscalYear: 2027, name: "URPSA Budget 2026/2027", status: "approved" })
    .returning();
  await db.insert(budgetLines).values([
    { ownerId, budgetId: budget.id, accountCode: "5001", amount: "180000.00" },
    { ownerId, budgetId: budget.id, accountCode: "5002", amount: "90000.00" },
    { ownerId, budgetId: budget.id, accountCode: "5003", amount: "450000.00", activityCode: "FRESH-ORI-2026-27" },
    { ownerId, budgetId: budget.id, accountCode: "5004", amount: "600000.00", activityCode: "CONF-2026" },
    { ownerId, budgetId: budget.id, accountCode: "5005", amount: "200000.00", activityCode: "WELF-2027" },
    { ownerId, budgetId: budget.id, accountCode: "5006", amount: "30000.00" },
    { ownerId, budgetId: budget.id, accountCode: "5007", amount: "50000.00" },
  ]);
  console.log("  budget created with 7 lines");

  // ── 13. Asset register ─────────────────────────────────────────────────────
  await db.insert(assets).values([
    { ownerId, assetId: "AST-0001", description: "Public address system (2 speakers, mixer, 2 mics)", category: "equipment", serial: "PAS-2026-114", custodian: "Treasurer", location: "URPSA Secretariat", purchaseDate: "2026-10-10", cost: "185000.00", condition: "good", lastVerified: "2027-03-31" },
    { ownerId, assetId: "AST-0002", description: "Projector — Epson EB-X51", category: "equipment", serial: "EPX51-88213", custodian: "Treasurer", location: "URPSA Secretariat", purchaseDate: "2026-10-10", cost: "142000.00", condition: "good", lastVerified: "2027-03-31" },
    { ownerId, assetId: "AST-0003", description: "Laptop — HP Pavilion 15", category: "equipment", serial: "HPP15-4471", custodian: "Financial Secretary", location: "URPSA Secretariat", purchaseDate: "2026-11-20", cost: "310000.00", condition: "new", lastVerified: "2027-03-31" },
    { ownerId, assetId: "AST-0004", description: "Filing cabinet (2-drawer, lockable)", category: "furniture", serial: "FC-2D-0091", custodian: "Treasurer", location: "URPSA Secretariat", purchaseDate: "2026-11-20", cost: "68000.00", condition: "good", lastVerified: "2027-03-31" },
    { ownerId, assetId: "AST-0005", description: "Banner stands and association signage", category: "equipment", serial: "BS-2026-07", custodian: "PRO", location: "URPSA Secretariat", purchaseDate: "2026-10-05", cost: "42000.00", condition: "fair", lastVerified: "2027-03-31" },
  ]);
  console.log("  5 assets registered");

  // ── 14. Liabilities and commitments ────────────────────────────────────────
  await db.insert(liabilities).values([
    { ownerId, liabilityId: "LIA-0001", payee: "UNILAG Events Centre", description: "Outstanding balance on conference venue hire", activityCode: "CONF-2026", dateIncurred: "2027-03-12", dueDate: "2027-06-30", amountCommitted: "60000.00", approvalStatus: "Approved", status: "outstanding" },
    { ownerId, liabilityId: "LIA-0002", payee: "Campus Printers", description: "Printing of conference proceedings", activityCode: "CONF-2026", dateIncurred: "2027-03-20", dueDate: "2027-05-31", amountCommitted: "45000.00", approvalStatus: "Approved", status: "outstanding" },
    { ownerId, liabilityId: "LIA-0003", payee: "Faculty of Environmental Sciences", description: "Shared security levy for the conference", activityCode: "CONF-2026", dateIncurred: "2027-03-14", dueDate: "2027-04-30", amountCommitted: "25000.00", approvalStatus: "Pending", status: "outstanding" },
  ]);
  console.log("  3 liabilities recorded");

  // ── 15. Reconciliations ────────────────────────────────────────────────────
  await db.insert(reconciliations).values([
    { ownerId, month: "2026-10-01", cashAccountCode: "BANK-01", statementDate: "2026-10-31", statementBalance: "0.00", ledgerBalance: "0.00", reviewedBy: "Financial Secretary", status: "reconciled", notes: "October statement agreed to the ledger." },
    { ownerId, month: "2026-11-01", cashAccountCode: "BANK-01", statementDate: "2026-11-30", statementBalance: "0.00", ledgerBalance: "0.00", reviewedBy: "Financial Secretary", status: "reconciled", notes: "November statement agreed to the ledger." },
  ]);
  console.log("  reconciliations recorded");

  console.log("\nSeed complete.");
  console.log(`  login: ${DEMO_EMAIL} / ${DEMO_PASSWORD}`);
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
