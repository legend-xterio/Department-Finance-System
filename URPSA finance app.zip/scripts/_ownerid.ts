import "dotenv/config";
import { sql } from "drizzle-orm";
import { db } from "../server/_core/db";

const r: any = await db.execute(sql`select id from users where email='treasurer@urpsa.test'`);
console.log(r.rows[0]?.id ?? "");
process.exit(0);
