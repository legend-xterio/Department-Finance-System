import "dotenv/config";
import { db } from "../server/_core/db";
import { sql } from "drizzle-orm";
async function main(){
  const r = await db.execute(sql`select table_name from information_schema.tables where table_schema='public' order by table_name`);
  console.log("DB TABLES:", (r.rows as any[]).map(x=>x.table_name).join(", "));
  const d = await db.execute(sql`select tablename, indexname from pg_indexes where schemaname='public' order by tablename`);
  console.log("\nINDEXES:", (d.rows as any[]).map(x=>x.indexname).join(", "));
}
main().then(()=>process.exit(0));
