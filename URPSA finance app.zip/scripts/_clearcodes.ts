import "dotenv/config";
import { db } from "../server/_core/db";
import { recoveryCodes } from "../drizzle/schema";
const before = await db.select().from(recoveryCodes);
await db.delete(recoveryCodes);
const after = await db.select().from(recoveryCodes);
console.log(JSON.stringify({ before: before.length, after: after.length }));
process.exit(0);
