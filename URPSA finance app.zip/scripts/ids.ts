/** Print concrete detail-route ids so the parameterised pages can be screenshotted. */
import "dotenv/config";
import { eq } from "drizzle-orm";
import { db } from "../server/_core/db";
import { users, journalEntries, sponsorship, orgs } from "../drizzle/schema";

const [u] = await db.select().from(users).where(eq(users.email, "treasurer@urpsa.test")).limit(1);
if (!u) { console.log("no user"); process.exit(0); }

const [org] = await db.select().from(orgs).where(eq(orgs.ownerId, u.id)).limit(1);
const entries = await db.select({ id: journalEntries.id, no: journalEntries.entryNo }).from(journalEntries).limit(3);
const spons = await db.select({ id: sponsorship.id, ref: sponsorship.sponsorshipId }).from(sponsorship).limit(3);

console.log("ORG legalName :", org?.legalName);
console.log("ORG shortName :", org?.shortName);
console.log("ENTRY ids     :", entries.map(e => e.id).join(", "), "|", entries.map(e => e.no).join(", "));
console.log("SPONSORSHIP   :", spons.map(s => `${s.id} (${s.ref})`).join(" | "));
process.exit(0);
