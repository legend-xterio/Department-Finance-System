/**
 * Verify the OPENING BALANCE flow end to end, through the real router.
 *
 * Proves the four things the feature promises:
 *   1. Saving posts a REAL balanced journal entry dated at the session start.
 *   2. The trial balance, balance sheet and cash flow all reconcile to zero
 *      difference afterwards, and all six control checks pass.
 *   3. Re-saving REPLACES the previous opening entry — the book never carries
 *      two competing openings, and the gross debits do not double.
 *   4. An unbalanced opening is REFUSED with a message that says what to fix.
 *
 * The test figures are deliberately arbitrary and are removed at the end, so
 * the app ships with the treasurer's own numbers (or none at all).
 */
import "dotenv/config";
import { eq, sql } from "drizzle-orm";
import { appRouter } from "../server/routers";
import { db } from "../server/_core/db";
import { journalEntries, journalLines, openingBalances } from "../drizzle/schema";
import * as rep from "../server/reports";

const OWNER = process.env.VERIFY_OWNER ?? "";
const ctx = {
  user: { id: OWNER, email: "treasurer@urpsa.test", name: "URPSA Treasurer", role: "user" },
} as any;
const api = appRouter.createCaller(ctx);

let pass = 0;
let fail = 0;
function check(name: string, cond: boolean, detail = "") {
  if (cond) pass++;
  else fail++;
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${detail ? " — " + detail : ""}`);
}

const f = (n: number) => n.toFixed(2);

async function openingEntries() {
  const rows = await db
    .select()
    .from(journalEntries)
    .where(eq(journalEntries.ownerId, OWNER));
  return rows.filter((r) => r.source === "opening");
}

async function reconcile(label: string) {
  const tb = await rep.trialBalance(OWNER);
  const pos = await rep.financialPosition(OWNER);
  const cf = await rep.cashFlow(OWNER);
  const checks = await rep.controlChecks(OWNER);

  check(`${label}: trial balance balances`, tb.difference === 0, `diff ${f(tb.difference)}`);
  check(`${label}: balance sheet identity`, pos.difference === 0, `diff ${f(pos.difference)}`);
  check(`${label}: cash flow reconciles`, cf.difference === 0, `diff ${f(cf.difference)}`);
  check(
    `${label}: all six control checks pass`,
    checks.every((c) => c.pass),
    checks.filter((c) => !c.pass).map((c) => c.name).join(", ") || "6/6",
  );
  return { tb, pos, cf };
}

async function main() {
  if (!OWNER) throw new Error("VERIFY_OWNER is not set");

  const org = await api.org.get();
  if (!org) throw new Error("No org row — save Settings first");
  const sessionStart = String(org.periodStart).slice(0, 10);

  // Start from a clean slate: remove any opening entry left by a previous run.
  const before = await openingEntries();
  for (const e of before) {
    await db.delete(journalEntries).where(eq(journalEntries.id, e.id));
  }
  await db.delete(openingBalances).where(eq(openingBalances.ownerId, OWNER));

  // ── 1. An unbalanced opening is refused ────────────────────────────────────
  let refused = false;
  let refusalMsg = "";
  try {
    await api.opening.save({
      bankAmount: 100000,
      cashAmount: 0,
      receivableAmount: 0,
      payableAmount: 0,
      fundAmount: 50000,
    });
  } catch (e: any) {
    refused = true;
    refusalMsg = String(e?.message ?? "");
  }
  check("unbalanced opening is refused", refused, refusalMsg.slice(0, 90));
  check(
    "refusal names the balancing figure",
    /accumulated fund to 100000\.00/i.test(refusalMsg),
    refusalMsg.slice(0, 120),
  );
  check("nothing was posted by the refused save", (await openingEntries()).length === 0);

  // ── 2. A balanced opening posts a real entry ───────────────────────────────
  const first = await api.opening.save({
    bankAmount: 250000,
    cashAmount: 15000,
    receivableAmount: 40000,
    payableAmount: 25000,
    fundAmount: 280000,
  });
  const entries1 = await openingEntries();
  check("opening entry posted", entries1.length === 1, first.entryNo);
  check("entry is dated at the session start", String(entries1[0]?.entryDate).slice(0, 10) === sessionStart, sessionStart);
  check("entry is balanced", f(Number(entries1[0]?.totalDebit)) === f(Number(entries1[0]?.totalCredit)), f(Number(entries1[0]?.totalDebit)));

  const lines1 = await db.select().from(journalLines).where(eq(journalLines.entryId, entries1[0].id));
  const byCode = new Map(lines1.map((l) => [l.accountCode, l]));
  check("Dr 1012 Bank 250,000", f(Number(byCode.get("1012")?.debit)) === "250000.00");
  check("Dr 1011 Cash 15,000", f(Number(byCode.get("1011")?.debit)) === "15000.00");
  check("Dr 1013 Receivable 40,000", f(Number(byCode.get("1013")?.debit)) === "40000.00");
  check("Cr 2011 Liabilities 25,000", f(Number(byCode.get("2011")?.credit)) === "25000.00");
  check("Cr 3010 Accumulated fund 280,000", f(Number(byCode.get("3010")?.credit)) === "280000.00");

  const r1 = await reconcile("after first opening");
  check("cash equals bank + cash", f(r1.cf.closingCash) === "265000.00", f(r1.cf.closingCash));
  check("assets equal 305,000", f(r1.pos.totalAssets) === "305000.00", f(r1.pos.totalAssets));
  check("liabilities equal 25,000", f(r1.pos.totalLiabilities) === "25000.00", f(r1.pos.totalLiabilities));

  // ── 3. Re-saving REPLACES rather than duplicates ───────────────────────────
  const second = await api.opening.save({
    bankAmount: 300000,
    cashAmount: 20000,
    receivableAmount: 0,
    payableAmount: 0,
    fundAmount: 320000,
  });
  const entries2 = await openingEntries();
  check("re-save leaves exactly one opening entry", entries2.length === 1, `${entries2.length} found`);
  check("the surviving entry is the new one", entries2[0]?.id === second.entryId, second.entryNo);
  // Compare IDs, not entry numbers: numbers are allocated max+1, so removing the
  // old opening legitimately frees its number for the replacement. What must
  // never survive is the old ROW.
  check("the old entry row is gone", entries2.every((e) => e.id !== entries1[0].id));

  const r2 = await reconcile("after replacing the opening");
  check("cash reflects the replacement only", f(r2.cf.closingCash) === "320000.00", f(r2.cf.closingCash));
  check("assets reflect the replacement only", f(r2.pos.totalAssets) === "320000.00", f(r2.pos.totalAssets));
  check("no receivable remains", r2.pos.assets.every((a) => a.code !== "1013"));
  check("no liability remains", r2.pos.liabilities.length === 0);

  // ── 4. The stored row reports what is actually posted ──────────────────────
  const stored = await api.opening.get();
  check("stored row points at the live entry", stored?.entry?.entryNo === second.entryNo, stored?.entry?.entryNo ?? "none");
  check("stored row reports the posted total", f(Number(stored?.entry?.totalDebit)) === "320000.00", f(Number(stored?.entry?.totalDebit)));

  // ── Clean up: leave the book as we found it ────────────────────────────────
  for (const e of await openingEntries()) {
    await db.delete(journalEntries).where(eq(journalEntries.id, e.id));
  }
  await db.delete(openingBalances).where(eq(openingBalances.ownerId, OWNER));

  const after = await reconcile("after cleanup");
  check("book is empty again", after.tb.rows.length === 0, `${after.tb.rows.length} rows`);
  check("cash is zero again", f(after.cf.closingCash) === "0.00", f(after.cf.closingCash));

  console.log(`\n${pass} passed, ${fail} failed`);
  if (fail > 0) process.exit(1);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
