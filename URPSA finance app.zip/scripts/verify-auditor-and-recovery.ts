/**
 * Verify the auditor account and the recovery-code flow, through the REAL router.
 *
 * Proves, in order:
 *   1. The auditor signs in and is scoped to the URPSA book (not an empty one).
 *   2. The auditor can READ every page's data: dashboard, transactions, reports,
 *      reconciliation history, change log.
 *   3. The auditor is REFUSED on every mutation — posting, editing, deleting,
 *      settings, period close, access changes. Server-side, not by hiding a button.
 *   4. Recovery codes: generated once, stored only as hashes, a code resets the
 *      password, and the same code cannot be used twice.
 *
 * Nothing is left behind: the auditor's test edits are refused (so nothing is
 * written), and the recovery codes are regenerated at the end so the treasurer
 * starts from a clean, unused set.
 */
import "dotenv/config";
import { eq } from "drizzle-orm";
import { appRouter } from "../server/routers";
import { db } from "../server/_core/db";
import { orgMembers, recoveryCodes, users } from "../drizzle/schema";

const OWNER = process.env.VERIFY_OWNER ?? "";
if (!OWNER) throw new Error("VERIFY_OWNER is not set");

const AUDITOR_EMAIL = "auditor@urpsa.test";
const AUDITOR_PW = "auditor2026";

function fakeCtx() {
  const headers: Record<string, string> = { host: "localhost:3000" };
  return {
    req: { url: "http://localhost:3000/trpc", header: (k: string) => headers[k.toLowerCase()] },
    header: (k: string, v: string) => {
      headers[k.toLowerCase()] = v;
    },
    setCookie: () => {},
    getCookie: () => undefined,
  } as any;
}

let pass = 0;
let fail = 0;
function check(name: string, cond: boolean, detail = "") {
  if (cond) pass++;
  else fail++;
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${detail ? " — " + detail : ""}`);
}

async function expectRefused(fn: () => Promise<unknown>, label: string) {
  try {
    await fn();
    check(label, false, "the call SUCCEEDED — it should have been refused");
  } catch (e: any) {
    const msg = String(e?.message ?? e);
    const code = String(e?.code ?? "");
    const ok = code === "FORBIDDEN" || /read-only/i.test(msg);
    check(label, ok, ok ? msg.slice(0, 80) : `wrong error: ${code} ${msg.slice(0, 70)}`);
  }
}

async function main() {
  const [owner] = await db.select().from(users).where(eq(users.id, OWNER)).limit(1);
  if (!owner) throw new Error(`No owner ${OWNER}`);

  const ownerApi = appRouter.createCaller({
    user: { id: owner.id, email: owner.email, name: owner.name, role: "user" },
    c: fakeCtx(),
  } as any);

  console.log("\n=== 1. THE AUDITOR SIGNS IN, SCOPED TO THE URPSA BOOK ===");
  const [auditor] = await db.select().from(users).where(eq(users.email, AUDITOR_EMAIL)).limit(1);
  check("the auditor account exists", !!auditor, auditor?.email ?? "missing");
  if (!auditor) throw new Error("run scripts/create-auditor.ts first");

  const [membership] = await db
    .select()
    .from(orgMembers)
    .where(eq(orgMembers.userId, auditor.id))
    .limit(1);
  check("the auditor is a member of the URPSA book", membership?.ownerId === OWNER, membership?.ownerId ?? "none");
  check("the role is `auditor`", membership?.role === "auditor", membership?.role ?? "none");

  const login = await ownerApi.auth.login({ email: AUDITOR_EMAIL, password: AUDITOR_PW });
  check("the auditor can sign in with the temporary password", login.email === AUDITOR_EMAIL);

  const auditorApi = appRouter.createCaller({
    user: { id: auditor.id, email: auditor.email, name: auditor.name, role: "user" },
    c: fakeCtx(),
  } as any);

  const access = await auditorApi.access.list();
  check("the auditor resolves to the URPSA book, not an empty one", access.myRole === "auditor", `myRole=${access.myRole}`);
  check("the auditor sees the treasurer as the book owner", access.owner?.email === owner.email, access.owner?.email ?? "none");

  console.log("\n=== 2. THE AUDITOR CAN READ EVERYTHING ===");
  const dash = await auditorApi.dashboard.summary();
  check("dashboard reads", typeof dash === "object" && dash !== null);
  const txns = await auditorApi.transactions.list({ page: 1, pageSize: 10 } as any);
  check("transactions read", Array.isArray(txns.rows), `${txns.rows?.length ?? 0} rows, total ${txns.total}`);
  const tb = await auditorApi.reports.trialBalance({ to: "2027-09-30" } as any);
  check("trial balance reads", Array.isArray(tb.rows), `${tb.rows?.length ?? 0} lines`);
  const bs = await auditorApi.reports.financialPosition({ to: "2027-09-30" } as any);
  check("balance sheet reads", typeof bs === "object" && bs !== null);
  const recs = await auditorApi.reconciliation.list();
  check("reconciliation history reads", Array.isArray(recs), `${recs?.length ?? 0} reconciliations`);
  const log = await auditorApi.changeLog.list({ limit: 20 } as any);
  check("change log reads", Array.isArray(log.rows), `${log.rows?.length ?? 0} entries`);
  const org = await auditorApi.org.get();
  check("organisation settings read", !!org?.legalName, org?.legalName ?? "none");

  console.log("\n=== 3. THE AUDITOR IS REFUSED ON EVERY MUTATION ===");
  await expectRefused(
    () => auditorApi.transactions.create({} as any),
    "posting a transaction is refused",
  );
  await expectRefused(
    () => auditorApi.members.create({ fullName: "Auditor Test", memberType: "student" } as any),
    "creating a member is refused",
  );
  await expectRefused(
    () => auditorApi.members.remove({ id: "00000000-0000-0000-0000-000000000000" } as any),
    "deleting a member is refused",
  );
  await expectRefused(
    () =>
      auditorApi.org.upsert({
        legalName: "Hijacked Association",
        periodStart: "2026-10-01",
        periodEnd: "2027-09-30",
        conversionDate: "2026-10-01",
      } as any),
    "changing organisation settings is refused",
  );
  await expectRefused(
    () => auditorApi.periods.setStatus({ id: "00000000-0000-0000-0000-000000000000", status: "closed" } as any),
    "closing a period is refused",
  );
  await expectRefused(
    () => auditorApi.access.invite({ email: "x@y.test", name: "X", role: "admin", password: "password123" } as any),
    "creating another user is refused",
  );
  await expectRefused(
    () => auditorApi.access.setRole({ id: "00000000-0000-0000-0000-000000000000", role: "admin" } as any),
    "changing a role is refused",
  );
  await expectRefused(
    () => auditorApi.access.setPublicSignup({ allow: true } as any),
    "opening public signup is refused",
  );
  await expectRefused(
    () => auditorApi.budgets.saveLine({} as any),
    "editing a budget line is refused",
  );
  await expectRefused(
    () => auditorApi.reconciliation.save({} as any),
    "saving a reconciliation is refused",
  );
  await expectRefused(
    () => auditorApi.assets.upsert({} as any),
    "creating an asset is refused",
  );

  // The book must be untouched by all of that.
  const orgAfter = await ownerApi.org.get();
  check("the book's settings are unchanged after the refused attempts", orgAfter?.legalName === org?.legalName, orgAfter?.legalName ?? "none");

  console.log("\n=== 4. RECOVERY CODES ===");
  const gen = await ownerApi.auth.generateRecoveryCodes();
  check("8 codes are generated", gen.codes.length === 8);
  check(
    "codes are readable groups of 4",
    /^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(gen.codes[0]),
    gen.codes[0],
  );
  check("all 8 codes are distinct", new Set(gen.codes).size === 8);

  const stored = await db.select().from(recoveryCodes).where(eq(recoveryCodes.userId, OWNER));
  check("8 rows are stored", stored.length === 8, `${stored.length} rows`);
  check(
    "no plaintext code is stored anywhere",
    stored.every((r) => !gen.codes.includes(r.codeHash) && r.codeHash.startsWith("$2")),
  );
  check(
    "the stored values are bcrypt hashes, not the codes",
    stored.every((r) => r.codeHash.length === 60),
  );
  check(
    "only the last 4 characters are kept as a hint",
    stored.every((r) => (r.hint ?? "").length === 4),
  );

  const status = await ownerApi.auth.recoveryStatus();
  check("status reports 8 unused", status.unused === 8 && status.total === 8, `${status.unused}/${status.total}`);

  // A wrong code must not work.
  try {
    await ownerApi.auth.startReset({ email: owner.email, recoveryCode: "AAAA-BBBB-CCCC-DDDD" });
    check("a wrong code is refused", false, "it was accepted");
  } catch (e: any) {
    check("a wrong code is refused", /do not match/i.test(String(e.message)), String(e.message).slice(0, 60));
  }

  // A real code resets the password.
  const reset = await ownerApi.auth.startReset({ email: owner.email, recoveryCode: gen.codes[0] });
  check("a valid code returns a reset token", reset.token.length === 64);

  const afterUse = await ownerApi.auth.recoveryStatus();
  check("the used code is burned", afterUse.unused === 7, `${afterUse.unused} unused`);

  try {
    await ownerApi.auth.startReset({ email: owner.email, recoveryCode: gen.codes[0] });
    check("the same code cannot be reused", false, "it was accepted twice");
  } catch (e: any) {
    check("the same code cannot be reused", /do not match/i.test(String(e.message)));
  }

  const TEMP = "urpsa2026";
  await ownerApi.auth.completeReset({ token: reset.token, newPassword: TEMP });
  const relogin = await ownerApi.auth.login({ email: owner.email, password: TEMP });
  check("the new password works after a reset", relogin.email === owner.email);

  try {
    await ownerApi.auth.completeReset({ token: reset.token, newPassword: "another-one-9" });
    check("the reset token is single-use", false, "it was accepted twice");
  } catch (e: any) {
    check("the reset token is single-use", /expired or already been used/i.test(String(e.message)));
  }

  // Leave the treasurer with a clean, unused set and the delivered password.
  const fresh = await ownerApi.auth.generateRecoveryCodes();
  check("a fresh unused set is issued for the treasurer", fresh.codes.length === 8);
  const finalStatus = await ownerApi.auth.recoveryStatus();
  check("the treasurer starts with 8 unused codes", finalStatus.unused === 8, `${finalStatus.unused}/8`);

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail === 0 ? 0 : 1);
}

main().catch((e) => {
  console.error("HARNESS ERROR:", e?.message ?? e);
  process.exit(1);
});
