/** Remove the demo treasurer and everything it owns (cascade), so seed.ts can re-run cleanly. */
import "dotenv/config";
import { eq } from "drizzle-orm";
import { db } from "../server/_core/db";
import { users } from "../drizzle/schema";

const EMAIL = "treasurer@society.test";
const rows = await db.select({ id: users.id }).from(users).where(eq(users.email, EMAIL));
for (const r of rows) {
  await db.delete(users).where(eq(users.id, r.id));
  console.log("deleted demo user", r.id);
}
if (rows.length === 0) console.log("no demo user found");
process.exit(0);
