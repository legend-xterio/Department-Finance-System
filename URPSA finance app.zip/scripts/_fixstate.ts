import "dotenv/config";
import { db } from "../server/_core/db";
import { sql } from "drizzle-orm";
const OWNER = "7783e909-bd24-4fb0-8184-fbc8050b8026";
(async () => {
  const l = await db.execute(sql`select id, liability_id, payee, amount_committed, approval_status, status, accrual_entry_id, settlement_entry_id from liabilities order by liability_id`);
  console.log("BEFORE:", JSON.stringify(l.rows, null, 1));
  // Remove e2e test artifacts that were never part of the dataset
  await db.execute(sql`delete from journal_entries where owner_id=${OWNER} and description like 'Settlement of LIA-0004%'`);
  await db.execute(sql`delete from journal_entries where owner_id=${OWNER} and description like 'Disposal proceeds%'`);
  await db.execute(sql`delete from journal_entries where owner_id=${OWNER} and description like 'E2E Test Sponsor%'`);
  await db.execute(sql`delete from transactions where owner_id=${OWNER} and payee like 'E2E Test%'`);
  await db.execute(sql`delete from liabilities where owner_id=${OWNER} and liability_id='LIA-0004'`);
  await db.execute(sql`delete from assets where owner_id=${OWNER} and asset_id='AST-0006'`);
  await db.execute(sql`delete from sponsorship where owner_id=${OWNER} and sponsorship_id in ('SPT-0007','SPT-0008')`);
  await db.execute(sql`delete from evidence where owner_id=${OWNER} and evidence_id like 'EV-E2E-%'`);
  const a = await db.execute(sql`select coalesce(sum(debit-credit),0) net from journal_lines where owner_id=${OWNER}`);
  console.log("TB after cleanup:", JSON.stringify(a.rows));
  process.exit(0);
})();
