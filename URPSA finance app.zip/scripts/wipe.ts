/**
 * Empty the URPSA ledger back to a clean slate.
 *
 * KEEPS: the login account, the chart of accounts (23 accounts), the org
 * settings (Urban and Regional Planning Students' Association), the cash
 * accounts and the 12 fiscal periods — the configuration the app needs to run.
 *
 * REMOVES: every business record — journal lines and entries, transactions,
 * evidence, budgets and lines, activities, members and dues, sponsors and
 * pledges, assets, liabilities and reconciliations.
 *
 * The opening balance is a journal entry, so it goes too: "from scratch" means
 * the ledger starts at zero. The org's opening-balance status and the cash
 * accounts' opening figures are zeroed to match, so nothing claims a balance
 * the journal does not hold. `scripts/seed.ts` can restore the demo dataset.
 *
 * Deletion order follows the foreign keys: children before parents.
 */
import "dotenv/config";
import { eq, sql } from "drizzle-orm";
import { db } from "../server/_core/db";
import {
  activities,
  assets,
  budgetLines,
  budgets,
  cashAccounts,
  dues,
  evidence,
  journalEntries,
  journalLines,
  liabilities,
  members,
  orgs,
  reconciliations,
  sponsorship,
  transactions,
} from "../drizzle/schema";

async function count(table: string) {
  const r: any = await db.execute(sql.raw(`select count(*)::int as c from ${table}`));
  return (r.rows?.[0]?.c ?? r[0]?.c ?? 0) as number;
}

const TABLES = [
  "journal_lines",
  "journal_entries",
  "evidence",
  "transactions",
  "budget_lines",
  "budgets",
  "dues",
  "members",
  "sponsorship",
  "assets",
  "liabilities",
  "reconciliations",
  "activities",
];

console.log("Before:");
for (const t of TABLES) console.log(`  ${t.padEnd(18)} ${await count(t)}`);

// ── Delete, children first ───────────────────────────────────────────────────
// journal_lines cascade from journal_entries, but deleting explicitly keeps the
// order obvious and works even if a cascade is ever removed.
await db.delete(journalLines);
await db.delete(journalEntries);
await db.delete(evidence);
await db.delete(transactions);
await db.delete(budgetLines);
await db.delete(budgets);
await db.delete(dues);
await db.delete(members);
await db.delete(sponsorship);
await db.delete(assets);
await db.delete(liabilities);
await db.delete(reconciliations);
await db.delete(activities);

// ── Zero the configuration figures that described the old ledger ─────────────
await db.update(orgs).set({ openingBalanceStatus: "0.00" });
await db.update(cashAccounts).set({ openingBalance: "0.00" });

console.log("\nAfter:");
for (const t of TABLES) console.log(`  ${t.padEnd(18)} ${await count(t)}`);

// ── What must survive ────────────────────────────────────────────────────────
const kept = {
  users: await count("users"),
  accounts: await count("accounts"),
  orgs: await count("orgs"),
  cash_accounts: await count("cash_accounts"),
  fiscal_periods: await count("fiscal_periods"),
};
console.log("\nKept:", kept);

const [org] = await db.select().from(orgs).limit(1);
console.log("Org:", org?.legalName, "| opening status:", org?.openingBalanceStatus);

process.exit(0);
