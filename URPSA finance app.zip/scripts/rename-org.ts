/**
 * One-off: correct the organisation identity in the DEV database.
 *
 * The app was seeded while the identity read "Political Science Students'
 * Association". The source has since been corrected; this updates the rows
 * already in the database, in place, so the verified figures survive
 * unchanged (a full reseed would be riskier and unnecessary).
 *
 * Idempotent: safe to run repeatedly.
 */
import "dotenv/config";
import { eq, like } from "drizzle-orm";
import { db } from "../server/_core/db";
import { orgs, activities, sponsorship, liabilities } from "../drizzle/schema";

const LEGAL = "University of Lagos Urban and Regional Planning Students' Association";

const [org] = await db.select().from(orgs).limit(1);
if (!org) {
  console.log("no organisation row found");
  process.exit(0);
}

if (org.legalName === LEGAL) {
  console.log("organisation already correct:", org.legalName);
} else {
  await db.update(orgs).set({ legalName: LEGAL }).where(eq(orgs.id, org.id));
  console.log("organisation legalName updated:");
  console.log("  was:", org.legalName);
  console.log("  now:", LEGAL);
}

// Activity + sponsorship + liability rows that carried the old field name.
const renamed = await db
  .update(activities)
  .set({ name: "Annual Urban and Regional Planning Conference" })
  .where(like(activities.name, "%Political Science%"))
  .returning({ code: activities.code, name: activities.name });
for (const r of renamed) console.log("activity renamed:", r.code, "->", r.name);

const spons = await db
  .update(sponsorship)
  .set({ purpose: "Annual Urban and Regional Planning Conference — headline sponsor" })
  .where(like(sponsorship.purpose, "%Political Science%"))
  .returning({ id: sponsorship.sponsorshipId });
for (const r of spons) console.log("sponsorship purpose updated:", r.id);

const liab = await db
  .update(liabilities)
  .set({ payee: "Faculty of Environmental Sciences" })
  .where(like(liabilities.description, "%security levy%"))
  .returning({ id: liabilities.liabilityId });
for (const r of liab) console.log("liability payee updated:", r.id);

console.log("done");
process.exit(0);
