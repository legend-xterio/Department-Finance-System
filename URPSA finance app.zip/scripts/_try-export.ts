import { appRouter } from "../server/routers";
import { db } from "../server/_core/db";
import { users, orgMembers } from "../drizzle/schema";
import { eq } from "drizzle-orm";
(async () => {
  const [u] = await db.select().from(users).where(eq(users.email, "treasurer@urpsa.test")).limit(1);
  const [m] = await db.select().from(orgMembers).where(eq(orgMembers.userId, u.id)).limit(1);
  const caller = appRouter.createCaller({ user: { id: u.id, email: u.email, name: u.name }, ownerId: m.ownerId, role: m.role } as any);
  const res = await caller.export.book();
  console.log("filename", res.filename, "bytes", res.bytes, "checksum", res.checksum.slice(0,16));
  console.log("counts", JSON.stringify(res.counts));
  const v = await caller.export.validate({ json: res.json });
  console.log("validate ok:", v.ok, "problems:", v.problems, "Dr", v.totalDebit, "Cr", v.totalCredit, "diff", v.difference);
  process.exit(0);
})().catch(e => { console.error("ERR", e.message); process.exit(1); });
