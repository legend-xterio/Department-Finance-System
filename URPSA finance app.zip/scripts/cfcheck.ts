import "dotenv/config";
import { inArray } from "drizzle-orm";
import { db } from "../server/_core/db";
import { accounts } from "../drizzle/schema";
const rows = await db.select().from(accounts).where(inArray(accounts.code,["1012","1112","1113","2110","3010","5011","6063","4011"]));
for (const r of rows) console.log(r.code, r.name.slice(0,32), "| cash:", r.isCash, "| class:", r.cashFlowClass, "| type:", r.type);
process.exit(0);
