import "dotenv/config";
import { db } from "../server/_core/db";
import { users, orgMembers, orgs, recoveryCodes } from "../drizzle/schema";
async function main(){
  const u = await db.select({id:users.id,email:users.email,name:users.name}).from(users);
  console.log("USERS", JSON.stringify(u,null,1));
  const m = await db.select().from(orgMembers);
  console.log("MEMBERS", JSON.stringify(m.map(x=>({id:x.id,userId:x.userId,role:x.role,name:x.displayName})),null,1));
  const o = await db.select().from(orgs);
  console.log("ORGS", JSON.stringify(o.map(x=>({ownerId:x.ownerId,name:x.name,short:x.shortName,allow:x.allowPublicSignup})),null,1));
  const rc = await db.select().from(recoveryCodes);
  console.log("RECOVERY", rc.length);
  process.exit(0);
}
main();
