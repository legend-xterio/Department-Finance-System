import React, { useState } from "react";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { trpc, makeTrpcClient } from "./_core/trpc";
import { AuthProvider } from "./_core/useAuth";
import { ErrorBoundary } from "./_core/ErrorBoundary";
import App from "./App";
import "./index.css";

function Root() {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            /**
             * Do not retry a request the server has already answered with a
             * verdict. React Query's default is 3 retries with backoff, so a
             * deleted record (NOT_FOUND) or an expired session (UNAUTHORIZED)
             * left the page on "Loading…" for ~10 seconds before showing the
             * error — which reads as a hang, not a missing record.
             */
            retry: (failureCount, error: any) => {
              const code = error?.data?.code;
              if (code === "NOT_FOUND" || code === "UNAUTHORIZED" || code === "FORBIDDEN" || code === "BAD_REQUEST") {
                return false;
              }
              return failureCount < 2;
            },
          },
        },
      }),
  );
  const [trpcClient] = useState(() => makeTrpcClient());
  return (
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <App />
        </AuthProvider>
      </QueryClientProvider>
    </trpc.Provider>
  );
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ErrorBoundary>
      <Root />
    </ErrorBoundary>
  </React.StrictMode>,
);
