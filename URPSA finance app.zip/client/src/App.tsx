import { useEffect, type ReactNode } from "react";
import { Route, Switch, Redirect, useLocation } from "wouter";
import { useAuth } from "./_core/useAuth";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import Transactions from "./pages/Transactions";
import TransactionDetail from "./pages/TransactionDetail";
import Budget from "./pages/Budget";
import NewBudget from "./pages/NewBudget";
import Sponsorship from "./pages/Sponsorship";
import PledgeDetail from "./pages/PledgeDetail";
import Members from "./pages/Members";
import Registers from "./pages/Registers";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
import ResetPassword from "./pages/ResetPassword";

// Route guard: redirect anonymous users to /login. Depends only on useAuth —
// never on the session mechanism.
function Protected({ children }: { children: ReactNode }) {
  const { user, isLoading } = useAuth();
  if (isLoading)
    return (
      <div className="flex min-h-screen items-center justify-center text-sm text-muted-foreground">
        Loading…
      </div>
    );
  if (!user) return <Redirect to="/login" />;
  return <>{children}</>;
}

// Administrative pages moved into Settings as tabs. Their old standalone URLs
// still work: they redirect to the matching tab, so a bookmark or a link in an
// email never lands on a 404.
function ToSettingsTab({ tab }: { tab: string }) {
  const [, navigate] = useLocation();
  useEffect(() => {
    navigate(`/settings?tab=${tab}`, { replace: true });
  }, [tab, navigate]);
  return (
    <div className="flex min-h-screen items-center justify-center text-sm text-muted-foreground">
      Opening Settings…
    </div>
  );
}

// The dashboard IS the home page for a signed-in treasurer; anonymous visitors
// are sent to the login form rather than a marketing page — this is an
// internal finance tool, not a public site.
export default function App() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/signup" component={Signup} />
      <Route path="/reset-password" component={ResetPassword} />

      <Route path="/">
        <Protected>
          <Dashboard />
        </Protected>
      </Route>

      <Route path="/transactions">
        <Protected>
          <Transactions />
        </Protected>
      </Route>

      <Route path="/transactions/:id">
        <Protected>
          <TransactionDetail />
        </Protected>
      </Route>

      <Route path="/budget">
        <Protected>
          <Budget />
        </Protected>
      </Route>

      <Route path="/budget/new">
        <Protected>
          <NewBudget />
        </Protected>
      </Route>

      <Route path="/sponsorship">
        <Protected>
          <Sponsorship />
        </Protected>
      </Route>

      <Route path="/sponsorship/:id">
        <Protected>
          <PledgeDetail />
        </Protected>
      </Route>

      <Route path="/members">
        <Protected>
          <Members />
        </Protected>
      </Route>

      <Route path="/registers">
        <Protected>
          <Registers />
        </Protected>
      </Route>

      <Route path="/reports">
        <Protected>
          <Reports />
        </Protected>
      </Route>

      <Route path="/settings">
        <Protected>
          <Settings />
        </Protected>
      </Route>

      {/* Old standalone routes — kept alive as redirects into Settings. */}
      <Route path="/security">
        <Protected>
          <ToSettingsTab tab="security" />
        </Protected>
      </Route>

      <Route path="/reconciliation">
        <Protected>
          <ToSettingsTab tab="reconciliation" />
        </Protected>
      </Route>

      <Route path="/change-log">
        <Protected>
          <ToSettingsTab tab="change-log" />
        </Protected>
      </Route>

      <Route path="/backup">
        <Protected>
          <ToSettingsTab tab="backup" />
        </Protected>
      </Route>

      <Route>
        <div className="flex min-h-screen flex-col items-center justify-center gap-2">
          <div className="text-sm font-semibold">Page not found</div>
          <a href="/" className="text-sm text-primary underline">
            Back to the dashboard
          </a>
        </div>
      </Route>
    </Switch>
  );
}
