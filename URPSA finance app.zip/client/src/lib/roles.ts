/**
 * What a role may do, in one place.
 *
 * The server is the guard — `writeProcedure` and `registerWriteProcedure` in
 * server/routers.ts. These flags exist so the UI does not offer a button whose
 * request the server will refuse, which is a worse experience than not showing
 * it. They must never be the only check.
 *
 * Two tiers, mirroring the server:
 *   canEnterRegisters — post a transaction, record a sponsorship receipt, add or
 *                       edit an asset / commitment, add a budget line.
 *   canManageBook     — settings, periods, access, chart of accounts, opening
 *                       balances, reconciliations, deletions, backups.
 *
 * The auditor is in the first tier and not the second: they enter the records
 * they will later audit, but cannot change the book's structure or who may sign
 * in. The president is in neither — that login exists to look.
 */
export type BookRole = "treasurer" | "admin" | "auditor" | "president";

export function roleFlags(role: string | undefined) {
  const r = (role ?? "treasurer") as BookRole;
  return {
    role: r,
    canEnterRegisters: r === "treasurer" || r === "admin" || r === "auditor",
    canManageBook: r === "treasurer" || r === "admin",
    /** True only for the president: the one role that may not enter anything. */
    isReadOnly: r === "president",
  };
}
