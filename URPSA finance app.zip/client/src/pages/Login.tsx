import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/_core/useAuth";
import { trpc } from "@/_core/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ErrorBox } from "@/components/finance-ui";
import { BrandMark } from "@/components/BrandMark";
import { orgTitle } from "@shared/org-display";

export default function Login() {
  const { login } = useAuth();
  const [, navigate] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  // Public signup is closed by default; only offer the link when it is open.
  const signupOpen = trpc.auth.signupOpen.useQuery();
  // The identity panel reads the organisation row, so a renamed association is
  // reflected on the sign-in screen too — not a hardcoded "URPSA".
  const org = trpc.org.get.useQuery(undefined, { staleTime: 60_000 });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await login(email, password);
      navigate("/");
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen">
      {/* Left: the ledger's identity panel. The crest goes on the deep-teal
          panel, so it needs its white plate — dropped bare, its white interior
          disc would blend into nothing and the teal ring would vanish. */}
      <div className="hidden w-1/2 flex-col justify-between bg-primary p-10 text-primary-foreground lg:flex">
        <div className="flex items-center gap-3">
          <BrandMark org={org.data} size="lg" plate="always" />
          <div className="leading-tight">
            <div className="text-sm font-semibold">
              {org.data?.shortName?.trim() || "URPSA"} Finance
            </div>
            <div className="text-[11px] opacity-70">Treasurer's ledger</div>
          </div>
        </div>
        <div>
          <h1 className="max-w-md text-3xl font-semibold leading-tight tracking-tight">
            Every naira accounted for, from dues to the annual conference.
          </h1>
          <p className="mt-4 max-w-md text-sm opacity-80">
            A double-entry ledger for {orgTitle(org.data)}, {org.data?.institution ?? ""}
            {org.data?.periodStart && org.data?.periodEnd
              ? ` — ${String(org.data.periodStart).slice(0, 4)}/${String(
                  org.data.periodEnd,
                ).slice(0, 4)} administration.`
              : "."}{" "}
            Posting rules are enforced on the server, and every report derives from the journal.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-4 border-t border-primary-foreground/20 pt-6 text-xs">
            <div>
              <div className="font-semibold">Double entry</div>
              <div className="opacity-70">Debits = credits, always</div>
            </div>
            <div>
              <div className="font-semibold">Evidence gate</div>
              <div className="opacity-70">Documents before posting</div>
            </div>
            <div>
              <div className="font-semibold">Six controls</div>
              <div className="opacity-70">Reconciled to zero</div>
            </div>
          </div>
        </div>
        <div className="text-[11px] opacity-60">
          {orgTitle(org.data)}
          {org.data?.institution ? ` · ${org.data.institution}` : ""}
        </div>
      </div>

      {/* Right: the form */}
      <div className="flex w-full items-center justify-center px-6 lg:w-1/2">
        <div className="w-full max-w-sm">
          <div className="mb-8 lg:hidden">
            <BrandMark org={org.data} size="lg" plate="always" />
          </div>
          <h2 className="text-xl font-semibold tracking-tight">Sign in</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Treasurer access to the {org.data?.shortName?.trim() || "URPSA"} ledger.
          </p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                autoComplete="username"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="treasurer@urpsa.test"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            {error ? <ErrorBox error={error} /> : null}
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? "Signing in…" : "Sign in"}
            </Button>
          </form>

          <p className="mt-6 text-sm text-muted-foreground">
            <Link href="/reset-password" className="font-medium text-primary underline">
              Forgot your password?
            </Link>{" "}
            Use a recovery code to get back in.
          </p>

          {signupOpen.data?.open && (
            <p className="mt-3 text-sm text-muted-foreground">
              No account yet?{" "}
              <Link href="/signup" className="font-medium text-primary underline">
                Create the treasurer account
              </Link>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
