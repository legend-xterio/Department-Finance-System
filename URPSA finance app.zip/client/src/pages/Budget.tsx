import { Fragment, useMemo, useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { EmptyState, Loading, ErrorBox, SectionHead, Panel, VariancePill } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import {
  Modal,
  Field,
  Select,
  MoneyInput,
  parseMoney,
  SubmitBtn,
  RowAction,
  ConfirmDialog,
  FormError,
  useToast,
} from "@/components/form-ui";
import { ngn, pct, today, fmtDate } from "@shared/finance";
import { roleFlags } from "@/lib/roles";
import { Target, ChevronRight, Plus, Pencil, Trash2, Receipt } from "lucide-react";

type LineRow = {
  id: string;
  accountCode: string;
  name: string;
  activityCode: string | null;
  budget: number;
  actual: number;
  variance: number;
  usedPct: number;
};

export default function Budget() {
  const budgets = trpc.budgets.list.useQuery();
  const [selected, setSelected] = useState<string | null>(null);
  const activeId = selected ?? budgets.data?.[0]?.id ?? null;
  const { toast, toastNode } = useToast();

  const variance = trpc.budgets.variance.useQuery(
    { budgetId: activeId!, to: today() },
    { enabled: !!activeId },
  );
  const accounts = trpc.accounts.postable.useQuery();
  const activities = trpc.activities.list.useQuery();
  // A budget LINE is a register write (auditor may); creating or deleting a
  // whole budget is book management (treasurer only).
  const access = trpc.access.list.useQuery(undefined, { staleTime: 60_000 });
  const { canEnterRegisters, canManageBook } = roleFlags(access.data?.myRole);

  const utils = trpc.useUtils();
  const saveLine = trpc.budgets.saveLine.useMutation({
    onSuccess: () => {
      // Invalidate the LIST too, not just the variance: saving the very first
      // line creates the budget header, and without this the page would keep
      // showing "No budget set" over a line that now exists.
      utils.budgets.list.invalidate();
      utils.budgets.variance.invalidate();
      setEditing(null);
      toast("Budget line saved");
    },
  });
  const deleteLine = trpc.budgets.deleteLine.useMutation({
    onSuccess: () => {
      utils.budgets.list.invalidate();
      utils.budgets.variance.invalidate();
      setDeleting(null);
      toast("Budget line deleted");
    },
  });

  const [editing, setEditing] = useState<Partial<LineRow> | null>(null);
  const [deleting, setDeleting] = useState<LineRow | null>(null);
  const [openActivity, setOpenActivity] = useState<string | null>(null);
  const [openLine, setOpenLine] = useState<string | null>(null);

  const rows: LineRow[] = (variance.data?.rows ?? []) as LineRow[];

  // Group by activity so each event can be opened and read as its own budget.
  const grouped = useMemo(() => {
    const m = new Map<string, LineRow[]>();
    for (const r of rows) {
      const k = r.activityCode ?? "";
      if (!m.has(k)) m.set(k, []);
      m.get(k)!.push(r);
    }
    return [...m.entries()].sort((a, b) =>
      a[0] === "" ? -1 : b[0] === "" ? 1 : a[0].localeCompare(b[0]),
    );
  }, [rows]);

  const budgetOptions = (accounts.data ?? [])
    .filter((a) => a.type === "expense" || a.type === "income")
    .map((a) => ({ value: a.code, label: `${a.code} · ${a.name}`, group: a.type }));
  const activityOptions = (activities.data ?? []).map((a) => ({
    value: a.code,
    label: `${a.code} · ${a.name}`,
  }));

  return (
    <AppShell
      title="Budget vs actual"
      subtitle="Approved budget against what the ledger has actually spent, pro-rated to today. Every line opens to its own receipts."
      actions={
        canEnterRegisters ? (
          <div className="flex flex-wrap gap-2">
            {canManageBook && (
              <Button variant="outline" size="sm" asChild>
                <Link to="/budget/new">
                  <Plus className="mr-1.5 h-3.5 w-3.5" /> New budget
                </Link>
              </Button>
            )}
            <Button size="sm" onClick={() => setEditing({ activityCode: openActivity ?? undefined })}>
              <Plus className="mr-1.5 h-3.5 w-3.5" /> Add budget line
            </Button>
          </div>
        ) : undefined
      }
    >
      {toastNode}
      {budgets.isLoading ? (
        <Loading />
      ) : budgets.error ? (
        <ErrorBox error={budgets.error} />
      ) : (budgets.data ?? []).length === 0 ? (
        <EmptyState
          icon={<Target className="h-8 w-8" />}
          title="No budget set"
          body="Add a budget line and this page tracks every category against what the ledger has actually spent."
          action={
            <div className="flex flex-wrap justify-center gap-2">
              {canEnterRegisters && (
                <Button size="sm" onClick={() => setEditing({})}>
                  <Plus className="mr-1.5 h-3.5 w-3.5" /> Add the first line
                </Button>
              )}
              {canManageBook && (
                <Button variant="outline" size="sm" asChild>
                  <Link to="/budget/new">
                    <Target className="mr-1.5 h-3.5 w-3.5" /> Build a full budget
                  </Link>
                </Button>
              )}
            </div>
          }
        />
      ) : (
        <div className="space-y-5">
          {(budgets.data ?? []).length > 1 && (
            <div className="flex flex-wrap gap-1 rounded-md border border-border p-0.5">
              {(budgets.data ?? []).map((b) => (
                <button
                  key={b.id}
                  onClick={() => setSelected(b.id)}
                  className={`rounded px-3 py-1.5 text-xs font-medium transition-colors ${
                    activeId === b.id
                      ? "bg-secondary text-secondary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {b.name}
                </button>
              ))}
            </div>
          )}

          {variance.isLoading ? (
            <Loading />
          ) : variance.error ? (
            <ErrorBox error={variance.error} />
          ) : variance.data ? (
            <>
              <div className="grid gap-3 sm:grid-cols-3">
                <Panel>
                  <div className="label-cap">Total budget</div>
                  <div className="tnum mt-1.5 text-xl font-semibold">{ngn(variance.data.totalBudget)}</div>
                </Panel>
                <Panel>
                  <div className="label-cap">Actual to date</div>
                  <div className="tnum mt-1.5 text-xl font-semibold">{ngn(variance.data.totalActual)}</div>
                </Panel>
                <Panel>
                  <div className="label-cap">Remaining</div>
                  <div
                    className={`tnum mt-1.5 text-xl font-semibold ${
                      variance.data.totalVariance >= 0 ? "text-favourable" : "text-adverse"
                    }`}
                  >
                    {ngn(variance.data.totalVariance)}
                  </div>
                </Panel>
              </div>

              <Panel>
                <SectionHead
                  right={
                    <span className="label-cap">Pro-rated to today · click a row to open its receipts</span>
                  }
                >
                  By activity and category
                </SectionHead>
                <div className="overflow-x-auto">
                  <table className="ledger">
                    <thead>
                      <tr>
                        <th className="w-6" />
                        <th>Code</th>
                        <th>Category</th>
                        <th className="num">Budget</th>
                        <th className="num">Actual</th>
                        <th className="num">Variance</th>
                        <th className="num">Used</th>
                        <th className="no-print w-16" />
                      </tr>
                    </thead>
                    <tbody>
                      {grouped.map(([actCode, actRows]) => {
                        const actBudget = actRows.reduce((s, r) => s + r.budget, 0);
                        const actActual = actRows.reduce((s, r) => s + r.actual, 0);
                        const isOpen = openActivity === (actCode || "__none");
                        return (
                          <Fragment key={`act-${actCode || "none"}`}>
                            <tr className="section-row">
                              <td>
                                <button
                                  onClick={() => setOpenActivity(isOpen ? null : actCode || "__none")}
                                  className="no-print"
                                  aria-label="Toggle activity"
                                >
                                  <ChevronRight
                                    className={`h-3.5 w-3.5 transition-transform ${isOpen ? "rotate-90" : ""}`}
                                  />
                                </button>
                              </td>
                              <td className="tnum text-xs">
                                {actCode || <span className="text-muted-foreground">—</span>}
                              </td>
                              <td className="text-sm font-semibold">
                                {actCode
                                  ? (activities.data?.find((a) => a.code === actCode)?.name ?? actCode)
                                  : "General (no activity)"}
                              </td>
                              <td className="num">{ngn(actBudget)}</td>
                              <td className="num">{ngn(actActual)}</td>
                              <td className="num">
                                <VariancePill amount={actBudget - actActual} />
                              </td>
                              <td className="num text-xs">{pct(actActual, actBudget)}%</td>
                              <td className="no-print">
                                <RowAction
                                  onClick={() => setEditing({ activityCode: actCode || undefined })}
                                  title="Add a line to this activity"
                                >
                                  <Plus className="h-3 w-3" />
                                </RowAction>
                              </td>
                            </tr>

                            {isOpen &&
                              actRows.map((r) => {
                                const lineKey = `${r.accountCode}|${r.activityCode ?? ""}`;
                                return (
                                  <Fragment key={lineKey}>
                                    <tr className="bg-muted/30">
                                      <td>
                                        <button
                                          onClick={() =>
                                            setOpenLine(openLine === lineKey ? null : lineKey)
                                          }
                                          className="no-print pl-3"
                                          aria-label="Show transactions"
                                        >
                                          <ChevronRight
                                            className={`h-3.5 w-3.5 transition-transform ${
                                              openLine === lineKey ? "rotate-90" : ""
                                            }`}
                                          />
                                        </button>
                                      </td>
                                      <td className="tnum text-xs text-muted-foreground">{r.accountCode}</td>
                                      <td className="pl-2 text-sm">{r.name}</td>
                                      <td className="num text-sm">{ngn(r.budget)}</td>
                                      <td className="num text-sm">{ngn(r.actual)}</td>
                                      <td className="num">
                                        <VariancePill amount={r.variance} />
                                      </td>
                                      <td className="num text-xs text-muted-foreground">
                                        {pct(r.actual, r.budget)}%
                                      </td>
                                      <td className="no-print whitespace-nowrap">
                                        <RowAction onClick={() => setEditing(r)} title="Edit line">
                                          <Pencil className="h-3 w-3" />
                                        </RowAction>
                                        <RowAction
                                          onClick={() => setDeleting(r)}
                                          tone="danger"
                                          title="Delete line"
                                        >
                                          <Trash2 className="h-3 w-3" />
                                        </RowAction>
                                      </td>
                                    </tr>
                                    {openLine === lineKey && (
                                      <tr>
                                        <td colSpan={8} className="p-0">
                                          <LineDrilldown
                                            accountCode={r.accountCode}
                                            activityCode={r.activityCode ?? undefined}
                                          />
                                        </td>
                                      </tr>
                                    )}
                                  </Fragment>
                                );
                              })}
                          </Fragment>
                        );
                      })}
                      <tr className="total-row">
                        <td colSpan={3}>Total</td>
                        <td className="num">{ngn(variance.data.totalBudget)}</td>
                        <td className="num">{ngn(variance.data.totalActual)}</td>
                        <td className="num">{ngn(variance.data.totalVariance)}</td>
                        <td className="num">
                          {pct(variance.data.totalActual, variance.data.totalBudget)}%
                        </td>
                        <td />
                      </tr>
                    </tbody>
                  </table>
                </div>
              </Panel>
            </>
          ) : null}
        </div>
      )}

      {/* ── Budget line editor ─────────────────────────────────────────────── */}
      <Modal
        open={!!editing}
        onClose={() => setEditing(null)}
        title={editing?.id ? "Edit budget line" : "Add budget line"}
        description="A line is a category within an activity. The ledger supplies the actual."
        footer={
          <>
            <Button variant="outline" size="sm" onClick={() => setEditing(null)}>
              Cancel
            </Button>
            <SubmitBtn
              label={editing?.id ? "Save changes" : "Add line"}
              busy={saveLine.isPending}
              disabled={!editing?.accountCode}
              onClick={() =>
                editing &&
                saveLine.mutate({
                  id: editing.id,
                  budgetId: activeId ?? undefined,
                  accountCode: editing.accountCode!,
                  activityCode: editing.activityCode || undefined,
                  amount: Number(editing.budget ?? 0),
                  periodNo: 0,
                })
              }
            />
          </>
        }
      >
        {editing && (
          <div className="space-y-3">
            <FormError error={saveLine.error} />
            <Field label="Activity" hint="Leave blank for organisation-wide spend.">
              <Select
                value={editing.activityCode ?? ""}
                onChange={(v) => setEditing({ ...editing, activityCode: v || null })}
                options={activityOptions}
                placeholder="General (no activity)"
              />
            </Field>
            <Field label="Category" required>
              <Select
                value={editing.accountCode ?? ""}
                onChange={(v) => setEditing({ ...editing, accountCode: v })}
                options={budgetOptions}
                placeholder="Choose an account…"
              />
            </Field>
            <Field label="Budget amount" required>
              <MoneyInput
                value={String(editing.budget ?? "")}
                onChange={(v) => setEditing({ ...editing, budget: parseMoney(v) })}
              />
            </Field>
            <p className="text-[11px] text-muted-foreground">
              Only income and expenditure accounts can be budgeted — a balance-sheet account is
              not spend.
            </p>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={!!deleting}
        title="Delete this budget line?"
        body={`${deleting?.name ?? ""} will be removed from the budget. Transactions already posted against it are untouched — only the plan goes.`}
        busy={deleteLine.isPending}
        onClose={() => setDeleting(null)}
        onConfirm={() => deleting && deleteLine.mutate({ id: deleting.id })}
      />
    </AppShell>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   The drill-down: the individual transactions behind one budget line.
   ───────────────────────────────────────────────────────────────────────────── */
function LineDrilldown({
  accountCode,
  activityCode,
}: {
  accountCode: string;
  activityCode?: string;
}) {
  const q = trpc.budgets.lineDetail.useQuery({ accountCode, activityCode, to: today() });

  return (
    <div className="border-l-2 border-primary/30 bg-muted/20 px-4 py-3">
      <div className="mb-2 flex items-center gap-2">
        <Receipt className="h-3.5 w-3.5 text-muted-foreground" />
        <span className="text-xs font-semibold">
          Transactions posted to {accountCode}
          {activityCode ? ` under ${activityCode}` : ""}
        </span>
        {q.data && (
          <span className="text-[11px] text-muted-foreground">
            {q.data.count} receipt{q.data.count === 1 ? "" : "s"}
          </span>
        )}
      </div>

      {q.isLoading ? (
        <div className="py-2 text-xs text-muted-foreground">Loading transactions…</div>
      ) : q.error ? (
        <ErrorBox error={q.error} />
      ) : !q.data || q.data.items.length === 0 ? (
        <p className="py-2 text-xs text-muted-foreground">
          Nothing posted against this line yet. Any expense entered with this category
          {activityCode ? ` and activity ${activityCode}` : ""} appears here automatically.
        </p>
      ) : (
        <div className="overflow-x-auto rounded border border-border bg-card">
          <table className="ledger">
            <thead>
              <tr>
                <th>Txn</th>
                <th>Date</th>
                <th>Payee</th>
                <th>Reference</th>
                <th>From</th>
                <th className="num">Amount</th>
              </tr>
            </thead>
            <tbody>
              {q.data.items.map((t) => (
                <tr key={t.id}>
                  <td className="tnum text-xs">{t.txnId}</td>
                  <td className="tnum text-xs">{fmtDate(t.txnDate)}</td>
                  <td className="text-sm">{t.payee ?? "—"}</td>
                  <td className="text-xs text-muted-foreground">{t.reference ?? "—"}</td>
                  <td className="tnum text-xs text-muted-foreground">{t.cashAccountCode}</td>
                  <td className="num text-sm">{ngn(t.amount)}</td>
                </tr>
              ))}
              <tr className="total-row">
                <td colSpan={5}>Total posted</td>
                <td className="num">{ngn(q.data.total)}</td>
              </tr>
              {q.data.difference !== 0 && (
                <tr>
                  <td colSpan={5} className="text-[11px] text-adverse">
                    Receipts listed do not equal the journal for this line — investigate before
                    relying on this figure.
                  </td>
                  <td className="num text-[11px] text-adverse">{ngn(q.data.difference)}</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
