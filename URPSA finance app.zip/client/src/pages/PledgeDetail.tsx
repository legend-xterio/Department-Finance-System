import { Link, useParams } from "wouter";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { Loading, ErrorBox, SectionHead, Panel } from "@/components/finance-ui";
import { ngn, fmtDate } from "@shared/finance";
import { ArrowLeft } from "lucide-react";

export default function PledgeDetail() {
  const { id } = useParams<{ id: string }>();
  const q = trpc.sponsorship.get.useQuery({ id: id! });

  if (q.isLoading) {
    return (
      <AppShell title="Sponsor">
        <Loading />
      </AppShell>
    );
  }
  if (q.error || !q.data) {
    return (
      <AppShell title="Sponsor">
        <ErrorBox error={q.error ?? new Error("Not found")} />
      </AppShell>
    );
  }

  const { pledge, receipts } = q.data;
  const received = receipts.reduce((s, r) => s + Number(r.amount), 0);

  return (
    <AppShell
      title={pledge.sponsor}
      subtitle={`${pledge.sponsorshipId} · ${pledge.stage.replace(/_/g, " ")}`}
      actions={
        <Link
          href="/sponsorship"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to the pipeline
        </Link>
      }
    >
      <div className="space-y-5">
        <div className="grid gap-4 lg:grid-cols-3">
          <Panel className="lg:col-span-2">
            <SectionHead>Commitment</SectionHead>
            <dl className="grid gap-3 sm:grid-cols-2">
              <Field label="Sponsor" value={pledge.sponsor} />
              <Field label="Purpose" value={pledge.purpose ?? "—"} />
              <Field label="Contact" value={pledge.contact ?? "—"} />
              <Field label="Activity" value={pledge.activityCode ?? "—"} />
              <Field label="Commitment date" value={fmtDate(pledge.commitmentDate)} />
              <Field label="Stage" value={pledge.stage.replace(/_/g, " ")} />
            </dl>
          </Panel>
          <Panel>
            <SectionHead>Money</SectionHead>
            <dl className="space-y-3 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Pledged</dt>
                <dd className="tnum font-medium">{ngn(pledge.amountPledged)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Received</dt>
                <dd className="tnum font-medium text-favourable">{ngn(received)}</dd>
              </div>
              <div className="flex justify-between border-t border-border pt-3">
                <dt className="font-medium">Outstanding</dt>
                <dd className="tnum font-semibold">{ngn(Number(pledge.amountPledged) - received)}</dd>
              </div>
            </dl>
          </Panel>
        </div>

        <Panel>
          <SectionHead>Receipts posted to the ledger</SectionHead>
          {receipts.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No receipts recorded against this sponsor yet. Post an income transaction with the
              reference {pledge.sponsorshipId} and it will appear here.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>Ref</th>
                    <th>Date</th>
                    <th>Payee</th>
                    <th>Account</th>
                    <th className="num">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {receipts.map((r) => (
                    <tr key={r.id}>
                      <td className="tnum text-xs">
                        <Link
                          href={`/transactions/${r.id}`}
                          className="font-medium text-primary underline"
                        >
                          {r.txnId}
                        </Link>
                      </td>
                      <td className="tnum text-xs">{fmtDate(r.txnDate)}</td>
                      <td className="text-sm">{r.payee ?? "—"}</td>
                      <td className="tnum text-xs text-muted-foreground">{r.cashAccountCode}</td>
                      <td className="num text-sm font-medium text-favourable">+{ngn(r.amount)}</td>
                    </tr>
                  ))}
                  <tr className="total-row">
                    <td colSpan={4}>Total received</td>
                    <td className="num">{ngn(received)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>
    </AppShell>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="label-cap">{label}</dt>
      <dd className="mt-0.5 text-sm">{value}</dd>
    </div>
  );
}
