import { useState } from "react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/_core/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BrandMark } from "@/components/BrandMark";
import { ErrorBox } from "@/components/finance-ui";
import { CheckCircle2, ArrowLeft } from "lucide-react";

/**
 * Account recovery without an email service.
 *
 * Two steps, because a recovery code alone should not be able to set a password
 * in one shot: the code buys a short-lived token, and the token sets the
 * password. That way a code read over someone's shoulder is not immediately a
 * takeover, and a used code is dead.
 */
export default function ResetPassword() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState<"code" | "password" | "done">("code");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [token, setToken] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<unknown>(null);

  const start = trpc.auth.startReset.useMutation();
  const complete = trpc.auth.completeReset.useMutation();

  async function submitCode(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      const res = await start.mutateAsync({ email, recoveryCode: code });
      setToken(res.token);
      setStep("password");
    } catch (err) {
      setError(err);
    }
  }

  async function submitPassword(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (password !== confirm) {
      setError(new Error("The two passwords do not match."));
      return;
    }
    try {
      await complete.mutateAsync({ token, newPassword: password });
      setStep("done");
    } catch (err) {
      setError(err);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-6">
      <div className="w-full max-w-md">
        <div className="mb-6 flex items-center gap-2.5">
          <BrandMark size="md" plate="always" />
          <div className="leading-tight">
            <div className="text-sm font-semibold">Recover access</div>
            <div className="text-[11px] text-muted-foreground">URPSA Finance</div>
          </div>
        </div>

        {step === "code" && (
          <>
            <h1 className="text-xl font-semibold tracking-tight">Use a recovery code</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Enter the email on the account and one of the recovery codes printed when the account
              was set up. Each code works once.
            </p>
            <form onSubmit={submitCode} className="mt-6 space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="treasurer@urpsa.test"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="code">Recovery code</Label>
                <Input
                  id="code"
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="XXXX-XXXX-XXXX-XXXX"
                  className="tnum tracking-wider"
                  required
                />
                <p className="text-[11px] text-muted-foreground">
                  No codes? Someone with access can generate a new set from Settings → Security.
                </p>
              </div>
              {error ? <ErrorBox error={error} /> : null}
              <Button type="submit" className="w-full" disabled={start.isPending}>
                {start.isPending ? "Checking…" : "Continue"}
              </Button>
            </form>
          </>
        )}

        {step === "password" && (
          <>
            <h1 className="text-xl font-semibold tracking-tight">Choose a new password</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              The code was accepted. Set a new password — every other signed-in device will be
              signed out.
            </p>
            <form onSubmit={submitPassword} className="mt-6 space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="pw">New password</Label>
                <Input
                  id="pw"
                  type="password"
                  autoComplete="new-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  minLength={8}
                  required
                />
                <p className="text-[11px] text-muted-foreground">At least 8 characters.</p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="pw2">Confirm new password</Label>
                <Input
                  id="pw2"
                  type="password"
                  autoComplete="new-password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  minLength={8}
                  required
                />
              </div>
              {error ? <ErrorBox error={error} /> : null}
              <Button type="submit" className="w-full" disabled={complete.isPending}>
                {complete.isPending ? "Saving…" : "Set the new password"}
              </Button>
            </form>
          </>
        )}

        {step === "done" && (
          <div className="rounded-lg border border-border bg-card p-6 text-center">
            <CheckCircle2 className="mx-auto h-8 w-8 text-favourable" />
            <h1 className="mt-3 text-lg font-semibold">Password changed</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Sign in with the new password. That recovery code has now been used.
            </p>
            <Button className="mt-5 w-full" onClick={() => navigate("/login")}>
              Go to sign in
            </Button>
          </div>
        )}

        <Link
          href="/login"
          className="mt-6 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to sign in
        </Link>
      </div>
    </div>
  );
}
