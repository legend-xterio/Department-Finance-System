import { useMemo, useState } from "react";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { Loading, ErrorBox, SectionHead, Panel, EmptyState } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ngn, fmtDate, today } from "@shared/finance";
import { Landmark, CheckCircle2, AlertTriangle, Trash2 } from "lucide-react";

/**
 * Bank reconciliation.
 *
 * The treasurer picks a cash account and a statement date, types the closing
 * balance from the bank statement, and ticks off the transactions that appear on
 * it. The page shows the arithmetic the server computed — book balance, cleared,
 * uncleared, difference — and only a zero difference is "reconciled".
 */
export default function Reconciliation() {
  const utils = trpc.useUtils();
  const cash = trpc.cash.list.useQuery();
  const history = trpc.reconciliation.list.useQuery();

  const [account, setAccount] = useState("");
  const [statementDate, setStatementDate] = useState(today());
  const [statementBalance, setStatementBalance] = useState("");
  const [cleared, setCleared] = useState<Set<string>>(new Set());
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [saved, setSaved] = useState<string | null>(null);

  const activeAccount = account || cash.data?.[0]?.code || "";

  const candidates = trpc.reconciliation.candidates.useQuery(
    { cashAccountCode: activeAccount, to: statementDate },
    { enabled: !!activeAccount },
  );
  const save = trpc.reconciliation.save.useMutation();
  const remove = trpc.reconciliation.remove.useMutation();

  const rows = candidates.data?.rows ?? [];
  const bookBalance = candidates.data?.bookBalance ?? 0;

  // The same arithmetic the server will store, shown live so the treasurer can
  // see the difference before committing.
  const clearedTotal = useMemo(() => {
    return rows
      .filter((t) => cleared.has(t.id))
      .reduce((s, t) => s + (t.txnType === "Income" ? Number(t.amount) : -Number(t.amount)), 0);
  }, [rows, cleared]);
  const unclearedTotal = bookBalance - clearedTotal;
  const statementNum = Number(statementBalance) || 0;
  const difference = statementNum - bookBalance;
  const balanced = Math.abs(difference) < 0.005;

  function toggle(id: string) {
    setCleared((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaved(null);
    try {
      const rec = await save.mutateAsync({
        cashAccountCode: activeAccount,
        statementDate,
        statementBalance: statementNum,
        clearedTransactionIds: [...cleared],
        notes: notes || undefined,
      });
      setSaved(
        rec.status === "reconciled"
          ? `Reconciled — the statement and the cash book agree at ${ngn(Number(rec.ledgerBalance))}.`
          : `Saved with a difference of ${ngn(Number(rec.difference))}. Investigate before closing the month.`,
      );
      await utils.reconciliation.list.invalidate();
    } catch (err) {
      setError(err);
    }
  }

  return (
    <AppShell
      title="Bank reconciliation"
      subtitle="Prove the cash book against a bank statement, month by month."
    >
      <div className="space-y-5">
        <Panel>
          <SectionHead right={<span className="label-cap">Book balance {ngn(bookBalance)}</span>}>
            New reconciliation
          </SectionHead>

          <form onSubmit={submit} className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="acct">Cash / bank account</Label>
                <select
                  id="acct"
                  value={activeAccount}
                  onChange={(e) => {
                    setAccount(e.target.value);
                    setCleared(new Set());
                  }}
                  className="h-9 w-full rounded-md border border-border bg-card px-2 text-sm"
                >
                  {(cash.data ?? []).map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.code} — {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sdate">Statement date</Label>
                <Input
                  id="sdate"
                  type="date"
                  value={statementDate}
                  onChange={(e) => setStatementDate(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sbal">Statement closing balance</Label>
                <Input
                  id="sbal"
                  type="number"
                  step="0.01"
                  value={statementBalance}
                  onChange={(e) => setStatementBalance(e.target.value)}
                  placeholder="0.00"
                  required
                />
                <p className="text-[11px] text-muted-foreground">
                  Copy this from the bank statement, not from the app.
                </p>
              </div>
            </div>

            {/* The arithmetic, live */}
            <div className="grid gap-2 rounded-lg border border-border bg-muted/30 p-3 sm:grid-cols-4">
              <Figure label="Book balance" value={ngn(bookBalance)} />
              <Figure label={`Cleared (${cleared.size})`} value={ngn(clearedTotal)} />
              <Figure label={`Uncleared (${rows.length - cleared.size})`} value={ngn(unclearedTotal)} />
              <Figure
                label="Difference"
                value={ngn(difference)}
                tone={balanced ? "good" : "bad"}
              />
            </div>

            {rows.length === 0 ? (
              <EmptyState
                icon={<Landmark className="h-8 w-8" />}
                title="Nothing to reconcile yet"
                body="There are no transactions on this account up to that date. Record some, or pick another account or date."
              />
            ) : (
              <div className="max-h-80 overflow-y-auto rounded-lg border border-border">
                <table className="ledger">
                  <thead className="sticky top-0 bg-card">
                    <tr>
                      <th className="w-8" />
                      <th>Ref</th>
                      <th>Date</th>
                      <th>Payee</th>
                      <th className="num">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((t) => (
                      <tr key={t.id} className={cleared.has(t.id) ? "bg-favourable-bg/40" : ""}>
                        <td>
                          <input
                            type="checkbox"
                            checked={cleared.has(t.id)}
                            onChange={() => toggle(t.id)}
                            aria-label={`Clear ${t.txnId}`}
                          />
                        </td>
                        <td className="tnum text-xs">{t.txnId}</td>
                        <td className="tnum text-xs">{fmtDate(t.txnDate)}</td>
                        <td className="text-sm">{t.payee ?? "—"}</td>
                        <td
                          className={`num text-sm ${t.txnType === "Income" ? "text-favourable" : "text-adverse"}`}
                        >
                          {t.txnType === "Income" ? "+" : "−"}
                          {ngn(t.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="notes">Notes (optional)</Label>
              <Input
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. two cheques not yet presented"
              />
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <Button type="submit" size="sm" disabled={save.isPending || !activeAccount}>
                {save.isPending ? "Saving…" : "Save reconciliation"}
              </Button>
              {saved && (
                <span
                  className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                    balanced ? "text-favourable" : "text-warn"
                  }`}
                >
                  {balanced ? (
                    <CheckCircle2 className="h-3.5 w-3.5" />
                  ) : (
                    <AlertTriangle className="h-3.5 w-3.5" />
                  )}
                  {saved}
                </span>
              )}
            </div>
            {error ? <ErrorBox error={error} /> : null}
          </form>
        </Panel>

        <Panel>
          <SectionHead right={<span className="label-cap">{history.data?.length ?? 0} saved</span>}>
            Reconciliation history
          </SectionHead>
          {history.isLoading ? (
            <Loading />
          ) : (history.data ?? []).length === 0 ? (
            <EmptyState
              icon={<Landmark className="h-8 w-8" />}
              title="No reconciliations yet"
              body="Save one above and it appears here, so the cash book can be proved for any month."
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>Account</th>
                    <th>Statement date</th>
                    <th className="num">Statement</th>
                    <th className="num">Book</th>
                    <th className="num">Cleared</th>
                    <th className="num">Uncleared</th>
                    <th className="num">Difference</th>
                    <th>Status</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {(history.data ?? []).map((r) => (
                    <tr key={r.id}>
                      <td className="tnum text-xs">{r.cashAccountCode}</td>
                      <td className="tnum text-xs">{r.statementDate ? fmtDate(r.statementDate) : "—"}</td>
                      <td className="num text-sm">{ngn(r.statementBalance)}</td>
                      <td className="num text-sm">{ngn(r.ledgerBalance)}</td>
                      <td className="num text-xs text-muted-foreground">{ngn(r.clearedTotal)}</td>
                      <td className="num text-xs text-muted-foreground">{ngn(r.unclearedTotal)}</td>
                      <td
                        className={`num text-sm font-medium ${
                          Number(r.difference) === 0 ? "text-favourable" : "text-adverse"
                        }`}
                      >
                        {ngn(r.difference)}
                      </td>
                      <td>
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${
                            r.status === "reconciled"
                              ? "bg-favourable-bg text-favourable"
                              : "bg-warn-bg text-warn"
                          }`}
                        >
                          {r.status}
                        </span>
                      </td>
                      <td className="text-right">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-destructive"
                          onClick={async () => {
                            if (!confirm("Delete this reconciliation?")) return;
                            await remove.mutateAsync({ id: r.id });
                            await utils.reconciliation.list.invalidate();
                          }}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>
    </AppShell>
  );
}

function Figure({
  label,
  value,
  tone = "default",
}: {
  label: string;
  value: string;
  tone?: "default" | "good" | "bad";
}) {
  return (
    <div>
      <div className="label-cap">{label}</div>
      <div
        className={`tnum mt-0.5 text-sm font-semibold ${
          tone === "good" ? "text-favourable" : tone === "bad" ? "text-adverse" : ""
        }`}
      >
        {value}
      </div>
    </div>
  );
}
