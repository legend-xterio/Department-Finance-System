import { Link } from "wouter";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { Kpi, ControlStrip, EmptyState, Loading, ErrorBox, SectionHead, Panel } from "@/components/finance-ui";
import { ngn, ngnCompact, fmtDate, pct } from "@shared/finance";
import { ArrowLeftRight, TrendingUp, TrendingDown, Wallet, Landmark, Scale } from "lucide-react";

export default function Dashboard() {
  const q = trpc.dashboard.summary.useQuery();

  if (q.isLoading) {
    return (
      <AppShell title="Dashboard">
        <Loading label="Reading the ledger…" />
      </AppShell>
    );
  }
  if (q.error) {
    return (
      <AppShell title="Dashboard">
        <ErrorBox error={q.error} />
      </AppShell>
    );
  }

  const d = q.data!;
  const org = d.org;
  const hasLedger = d.txnCount > 0;

  const checks = d.checks.map((c) => ({
    key: c.name,
    label: c.name,
    ok: c.pass,
    detail: c.detail,
  }));

  const income = d.byCategory.filter((c) => c.type === "income");
  const expense = d.byCategory.filter((c) => c.type === "expense");
  const maxIncome = Math.max(1, ...income.map((c) => Math.abs(c.net)));
  const maxExpense = Math.max(1, ...expense.map((c) => Math.abs(c.net)));

  return (
    <AppShell
      title="Dashboard"
      subtitle={
        org
          ? `${org.legalName} · ${fmtDate(org.periodStart)} – ${fmtDate(org.periodEnd)}`
          : "Set up your organisation in Settings to begin."
      }
      actions={
        <Link
          href="/transactions"
          className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          <ArrowLeftRight className="h-3.5 w-3.5" />
          Record a transaction
        </Link>
      }
    >
      {!hasLedger ? (
        <EmptyState
          icon={<Wallet className="h-8 w-8" />}
          title="The ledger is empty"
          body="No transactions have been posted yet. Record your first receipt or payment and the dashboard, budget and every report will fill in from the journal."
          action={
            <Link
              href="/transactions"
              className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground"
            >
              Record the first transaction
            </Link>
          }
        />
      ) : (
        <div className="space-y-6">
          {/* KPI row */}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Kpi label="Total income" value={d.income} caption="For the administration year" tone="positive" />
            <Kpi label="Total expenditure" value={d.expenditure} caption="For the administration year" tone="negative" />
            <Kpi
              label="Net surplus"
              value={d.surplus}
              caption={d.income > 0 ? `${pct(d.surplus, d.income)}% of income` : undefined}
              tone={d.surplus >= 0 ? "positive" : "negative"}
            />
            <Kpi label="Cash at bank & hand" value={d.cash} caption="From the cash accounts" />
          </div>

          {/* Control strip */}
          <ControlStrip checks={checks} />

          {/* Position + trend */}
          <div className="grid gap-4 lg:grid-cols-3">
            <Panel className="lg:col-span-2">
              <SectionHead right={<span className="label-cap">{d.txnCount} transactions</span>}>
                Monthly movement
              </SectionHead>
              {d.monthly.length === 0 ? (
                <p className="py-6 text-sm text-muted-foreground">No monthly movement yet.</p>
              ) : (
                <div className="space-y-2.5">
                  {d.monthly.map((m) => {
                    const max = Math.max(1, ...d.monthly.map((x) => Math.max(x.income, x.expense)));
                    return (
                      <div key={m.ym} className="grid grid-cols-[64px_1fr] items-center gap-3">
                        <div className="tnum text-[11px] text-muted-foreground">{m.ym}</div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <div className="h-2 rounded-sm bg-favourable/70" style={{ width: `${(m.income / max) * 100}%`, minWidth: m.income > 0 ? 4 : 0 }} />
                            <span className="tnum text-[11px] text-muted-foreground">{ngnCompact(m.income)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="h-2 rounded-sm bg-adverse/60" style={{ width: `${(m.expense / max) * 100}%`, minWidth: m.expense > 0 ? 4 : 0 }} />
                            <span className="tnum text-[11px] text-muted-foreground">{ngnCompact(m.expense)}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  <div className="flex gap-4 border-t border-border pt-2 text-[11px] text-muted-foreground">
                    <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-favourable/70" /> Income</span>
                    <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-adverse/60" /> Expenditure</span>
                  </div>
                </div>
              )}
            </Panel>

            <Panel>
              <SectionHead>Financial position</SectionHead>
              <dl className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <dt className="flex items-center gap-1.5 text-muted-foreground"><Landmark className="h-3.5 w-3.5" /> Total assets</dt>
                  <dd className="tnum font-medium">{ngn(d.totalAssets)}</dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="flex items-center gap-1.5 text-muted-foreground"><Scale className="h-3.5 w-3.5" /> Liabilities</dt>
                  <dd className="tnum font-medium">{ngn(d.totalLiabilities)}</dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-muted-foreground">Accumulated fund</dt>
                  <dd className="tnum font-medium">{ngn(d.totalFunds)}</dd>
                </div>
                <div className="flex items-center justify-between border-t border-border pt-3">
                  <dt className="font-medium">Net assets</dt>
                  <dd className="tnum font-semibold">{ngn(d.totalAssets - d.totalLiabilities)}</dd>
                </div>
              </dl>
              <Link
                href="/reports"
                className="mt-4 inline-block text-xs font-medium text-primary underline"
              >
                Open the full statements →
              </Link>
            </Panel>
          </div>

          {/* Category breakdown */}
          <div className="grid gap-4 lg:grid-cols-2">
            <Panel>
              <SectionHead right={<TrendingUp className="h-4 w-4 text-favourable" />}>Income by category</SectionHead>
              {income.length === 0 ? (
                <p className="py-4 text-sm text-muted-foreground">No income recorded yet.</p>
              ) : (
                <div className="space-y-2">
                  {income.map((c) => (
                    <div key={c.code} className="grid grid-cols-[1fr_auto] items-center gap-3">
                      <div>
                        <div className="flex items-baseline justify-between">
                          <span className="text-sm">{c.name}</span>
                          <span className="tnum text-xs text-muted-foreground">{c.code}</span>
                        </div>
                        <div className="mt-1 h-1.5 rounded-sm bg-muted">
                          <div className="h-1.5 rounded-sm bg-favourable/70" style={{ width: `${(Math.abs(c.net) / maxIncome) * 100}%` }} />
                        </div>
                      </div>
                      <span className="tnum text-sm font-medium">{ngn(c.net)}</span>
                    </div>
                  ))}
                </div>
              )}
            </Panel>

            <Panel>
              <SectionHead right={<TrendingDown className="h-4 w-4 text-adverse" />}>Expenditure by category</SectionHead>
              {expense.length === 0 ? (
                <p className="py-4 text-sm text-muted-foreground">No expenditure recorded yet.</p>
              ) : (
                <div className="space-y-2">
                  {expense.map((c) => (
                    <div key={c.code} className="grid grid-cols-[1fr_auto] items-center gap-3">
                      <div>
                        <div className="flex items-baseline justify-between">
                          <span className="text-sm">{c.name}</span>
                          <span className="tnum text-xs text-muted-foreground">{c.code}</span>
                        </div>
                        <div className="mt-1 h-1.5 rounded-sm bg-muted">
                          <div className="h-1.5 rounded-sm bg-adverse/60" style={{ width: `${(Math.abs(c.net) / maxExpense) * 100}%` }} />
                        </div>
                      </div>
                      <span className="tnum text-sm font-medium">{ngn(c.net)}</span>
                    </div>
                  ))}
                </div>
              )}
            </Panel>
          </div>

          {/* Recent postings */}
          <Panel>
            <SectionHead
              right={
                <Link href="/transactions" className="text-xs font-medium text-primary underline">
                  View all
                </Link>
              }
            >
              Recent postings
            </SectionHead>
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>Ref</th>
                    <th>Date</th>
                    <th>Payee / description</th>
                    <th>Category</th>
                    <th className="num">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {d.recent.map((t) => (
                    <tr key={t.id}>
                      <td className="tnum text-xs text-muted-foreground">{t.txnId}</td>
                      <td className="tnum text-xs">{fmtDate(t.txnDate)}</td>
                      <td className="text-sm">{t.payee ?? "—"}</td>
                      <td className="tnum text-xs text-muted-foreground">{t.categoryCode}</td>
                      <td className={`num text-sm font-medium ${t.txnType === "Income" ? "text-favourable" : "text-adverse"}`}>
                        {t.txnType === "Income" ? "+" : "−"}
                        {ngn(t.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>
      )}
    </AppShell>
  );
}
