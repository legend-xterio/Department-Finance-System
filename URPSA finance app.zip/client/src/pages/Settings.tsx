import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { cn } from "@/lib/utils";
import { roleFlags } from "@/lib/roles";
import {
  Building2,
  Landmark,
  ListTree,
  CalendarClock,
  Scale,
  ShieldCheck,
  DatabaseBackup,
  History,
} from "lucide-react";
import OrganisationTab from "./settings/OrganisationTab";
import OpeningBalancesTab from "./settings/OpeningBalancesTab";
import ChartOfAccountsTab from "./settings/ChartOfAccountsTab";
import FiscalPeriodsTab from "./settings/FiscalPeriodsTab";
import Reconciliation from "./Reconciliation";
import Security from "./Security";
import Backup from "./Backup";
import ChangeLog from "./ChangeLog";

/**
 * Settings is the home for everything administrative. The sidebar stays short
 * because these pages live here as tabs, grouped by what the treasurer is
 * actually trying to do rather than listed flat.
 */
type TabKey =
  | "organisation"
  | "opening"
  | "accounts"
  | "periods"
  | "reconciliation"
  | "security"
  | "backup"
  | "change-log";

type Tab = {
  key: TabKey;
  label: string;
  icon: typeof Building2;
  blurb: string;
  /** Read-only roles may open every tab; this marks the ones that are pure
   *  action, so the tab can say so instead of showing a form that will fail. */
  writeOnly?: boolean;
};

const GROUPS: { title: string; tabs: Tab[] }[] = [
  {
    title: "Book setup",
    tabs: [
      {
        key: "organisation",
        label: "Organisation details",
        icon: Building2,
        blurb: "Name, institution, session, currency and officers.",
      },
      {
        key: "opening",
        label: "Opening balances",
        icon: Landmark,
        blurb: "The figures the ledger starts from.",
        writeOnly: true,
      },
      {
        key: "accounts",
        label: "Chart of accounts",
        icon: ListTree,
        blurb: "Every account a posting may use.",
      },
      {
        key: "periods",
        label: "Fiscal periods",
        icon: CalendarClock,
        blurb: "Close a month once it is final.",
      },
    ],
  },
  {
    title: "Controls",
    tabs: [
      {
        key: "reconciliation",
        label: "Bank reconciliation",
        icon: Scale,
        blurb: "Prove the cash book against a statement.",
      },
      {
        key: "backup",
        label: "Backup",
        icon: DatabaseBackup,
        blurb: "A restorable archive of the whole book.",
      },
    ],
  },
  {
    title: "Access & audit",
    tabs: [
      {
        key: "security",
        label: "Security & access",
        icon: ShieldCheck,
        blurb: "Your password, recovery codes and who else can see this book.",
      },
      {
        key: "change-log",
        label: "Change log",
        icon: History,
        blurb: "Who changed what, and when.",
      },
    ],
  },
];

const ALL_TABS = GROUPS.flatMap((g) => g.tabs);

function tabFromUrl(): TabKey {
  const t = new URLSearchParams(window.location.search).get("tab");
  return (ALL_TABS.find((x) => x.key === t)?.key ?? "organisation") as TabKey;
}

export default function Settings() {
  const [path, navigate] = useLocation();
  const access = trpc.access.list.useQuery(undefined, { staleTime: 60_000 });
  const [tab, setTab] = useState<TabKey>(tabFromUrl);

  const role: string = access.data?.myRole ?? "treasurer";
  // Every tab in Settings is book management, so the gate here is the narrower
  // one: an auditor may enter records but may not change the book's setup.
  const readOnly = !roleFlags(role).canManageBook;

  // The address bar is the source of truth, so a tab is linkable and the back
  // button works. `useLocation` yields the PATHNAME only, so a query-only change
  // (the old /security redirect, a pasted ?tab= link, back/forward) does not
  // re-render on its own — hence the popstate listener as well.
  useEffect(() => {
    const sync = () => setTab(tabFromUrl());
    window.addEventListener("popstate", sync);
    sync();
    return () => window.removeEventListener("popstate", sync);
  }, [path]);

  function pick(key: TabKey) {
    setTab(key);
    // navigate() rather than replaceState: it notifies wouter, so the tab and
    // the address bar cannot drift apart.
    navigate(`/settings?tab=${key}`, { replace: true });
  }

  const active = ALL_TABS.find((t) => t.key === tab) ?? ALL_TABS[0];

  return (
    <AppShell
      title="Settings"
      subtitle="Book setup, controls, and access — everything administrative in one place."
    >
      <div className="space-y-5">
        {/* Tab rail — grouped, wraps on a phone */}
        <div className="no-print space-y-3">
          {GROUPS.map((group) => (
            <div key={group.title}>
              <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
                {group.title}
              </div>
              <div className="flex flex-wrap gap-1.5">
                {group.tabs.map((t) => {
                  const Icon = t.icon;
                  const on = t.key === tab;
                  return (
                    <button
                      key={t.key}
                      type="button"
                      onClick={() => pick(t.key)}
                      aria-current={on ? "page" : undefined}
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-[13px] transition-colors",
                        on
                          ? "border-primary bg-secondary font-medium text-secondary-foreground"
                          : "border-border bg-card text-muted-foreground hover:bg-muted hover:text-foreground",
                      )}
                    >
                      <Icon className="h-3.5 w-3.5 shrink-0" />
                      {t.label}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {readOnly && active.writeOnly ? (
          <div className="rounded-lg border border-warn/40 bg-warn-bg p-3 text-sm">
            <div className="font-medium">This tab is for the treasurer</div>
            <div className="mt-0.5 text-xs text-muted-foreground">
              Signed in as {role === "auditor" ? "Auditor" : "President"} — you can read the posted
              opening entry on the dashboard and in the reports, but only the treasurer can post or
              replace it.
            </div>
          </div>
        ) : null}

        {/* The tab body. Each page renders its own heading through the nested
            AppShell, so there is exactly one sidebar and one page title.
            A write-only tab is not rendered for a read-only role: showing a form
            whose save the server will refuse is worse than not showing it. */}
        <div>
          {readOnly && active.writeOnly ? null : (
            <>
              {tab === "organisation" && <OrganisationTab />}
              {tab === "opening" && <OpeningBalancesTab />}
              {tab === "accounts" && <ChartOfAccountsTab />}
              {tab === "periods" && <FiscalPeriodsTab />}
              {tab === "reconciliation" && <Reconciliation />}
              {tab === "security" && <Security />}
              {tab === "backup" && <Backup />}
              {tab === "change-log" && <ChangeLog />}
            </>
          )}
        </div>
      </div>
    </AppShell>
  );
}
