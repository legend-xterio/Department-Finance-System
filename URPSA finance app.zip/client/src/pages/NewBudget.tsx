import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { Loading, ErrorBox, Panel, SectionHead, EmptyState } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import {
  Field,
  Select,
  MoneyInput,
  parseMoney,
  TextInput,
  RowAction,
  FormError,
  useToast,
} from "@/components/form-ui";
import { ngn, ngnSigned, fiscalMonths } from "@shared/finance";
import {
  type PlanLine,
  type PlanActivity,
  type PlanKind,
  planTotals,
  planByAccount,
  planByActivity,
  applyUplift,
  spreadOverMonths,
  collapseToAnnual,
  validatePlan,
  nextLineKey,
  fiscalYearLabel,
  fiscalYearRange,
  clonePlan,
} from "@shared/budget-plan";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Plus,
  Trash2,
  Calendar,
  Target,
  Layers,
  ListChecks,
  Copy,
  Wand2,
  AlertTriangle,
  Info,
  X,
  Pencil,
  Save,
} from "lucide-react";

/* ─────────────────────────────────────────────────────────────────────────────
   THE BUDGET WIZARD

   Four steps, because building a budget from nothing is four decisions and
   pretending otherwise is how a treasurer loses their work halfway through:

     1. Which year, and what do we start from?  (blank, or last year scaled)
     2. Which activities will we run?
     3. What does each activity cost, and what income does it raise?
     4. Does it add up? Then save.

   The plan lives entirely in this component until the last step, where it is
   committed in ONE transaction. Nothing is written to the database while the
   treasurer is still thinking — a half-built budget that appears in the picker
   would be indistinguishable from a real one.

   All the arithmetic (totals, uplift, monthly spread, validation) is in
   shared/budget-plan.ts so it can be tested without a browser. This file only
   decides what the treasurer sees.
   ───────────────────────────────────────────────────────────────────────────── */

type Step = 0 | 1 | 2 | 3;

const STEPS: { title: string; blurb: string; icon: typeof Calendar }[] = [
  { title: "Year & approach", blurb: "Which year, and where we start", icon: Calendar },
  { title: "Activities", blurb: "The events this budget covers", icon: Layers },
  { title: "Budget lines", blurb: "Income and spend, per activity", icon: Target },
  { title: "Review & save", blurb: "Check, then commit", icon: ListChecks },
];

let keySeq = 0;
const uid = () => `n${++keySeq}`;

export default function NewBudget() {
  const [, navigate] = useLocation();
  const { toast, toastNode } = useToast();
  const utils = trpc.useUtils();

  const [step, setStep] = useState<Step>(0);
  const [fiscalYear, setFiscalYear] = useState<number | null>(null);
  const [name, setName] = useState("");
  const [nameTouched, setNameTouched] = useState(false);
  const [status, setStatus] = useState<"draft" | "approved">("draft");
  const [activities, setActivities] = useState<PlanActivity[]>([]);
  const [lines, setLines] = useState<PlanLine[]>([]);
  /** Raw text per line while it is being typed, so "12." does not become 12. */
  const [texts, setTexts] = useState<Record<string, string>>({});
  const [uplift, setUplift] = useState("10");
  const [copySource, setCopySource] = useState<string | null>(null);
  const [copyApplied, setCopyApplied] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);


  // Edit mode: ?edit=<budgetId> loads that budget's own lines instead of copying.
  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    const id = p.get("edit");
    if (id) setEditId(id);
  }, []);

  // Fetch immediately, before a year has been chosen: the response carries the
  // organisation's calendar AND the year to preselect. Gating this on a year we
  // have not learned yet deadlocks the wizard on its own first step.
  const ctx = trpc.budgets.wizardContext.useQuery(fiscalYear === null ? {} : { fiscalYear });

  const existingLines = trpc.budgets.lines.useQuery(
    { budgetId: editId! },
    { enabled: !!editId },
  );
  const allBudgets = trpc.budgets.list.useQuery();

  /* ── Adopt the organisation's calendar on first load ────────────────────── */
  const seeded = useRef(false);
  useEffect(() => {
    if (seeded.current || !ctx.data) return;
    seeded.current = true;
    const y = ctx.data.fiscalYear;
    setFiscalYear(y);
    if (!nameTouched) setName(`URPSA Budget ${fiscalYearLabel(y)}`);
  }, [ctx.data, nameTouched]);

  /* ── Edit mode: load the budget being revised ───────────────────────────── */
  const loadedEdit = useRef(false);
  useEffect(() => {
    if (!editId || loadedEdit.current) return;
    if (!existingLines.data || !allBudgets.data) return;
    loadedEdit.current = true;
    const b = allBudgets.data.find((x: any) => x.id === editId);
    if (b) {
      setFiscalYear(b.fiscalYear);
      setName(b.name);
      setNameTouched(true);
      setStatus(b.status === "approved" ? "approved" : "draft");
    }
    setLines(
      existingLines.data
        .filter((l: any) => l.accountType === "income" || l.accountType === "expense")
        .map((l: any) => ({
          key: uid(),
          accountCode: l.accountCode,
          kind: (l.accountType === "income" ? "income" : "expense") as PlanKind,
          activityCode: l.activityCode,
          periodNo: l.periodNo ?? 0,
          amount: l.amount,
        })),
    );
    setTexts({});
  }, [editId, existingLines.data, allBudgets.data]);

  /* ── Derived ────────────────────────────────────────────────────────────── */
  const totals = useMemo(() => planTotals(lines), [lines]);
  const byActivity = useMemo(() => planByActivity(lines), [lines]);
  const byAccount = useMemo(() => planByAccount(lines), [lines]);

  const accountKinds = useMemo(() => {
    const m: Record<string, PlanKind> = {};
    for (const a of ctx.data?.accounts ?? []) {
      if (a.type === "income" || a.type === "expense") m[a.code] = a.type as PlanKind;
    }
    return m;
  }, [ctx.data]);

  /** code → human name, so the review reads "Association dues", not "4001". */
  const accountNames = useMemo(() => {
    const m: Record<string, string> = {};
    for (const a of ctx.data?.accounts ?? []) m[a.code] = a.name;
    return m;
  }, [ctx.data]);

  const knownActivities = useMemo(
    () => new Set([...(ctx.data?.activities ?? []).map((a) => a.code), ...activities.map((a) => a.code)]),
    [ctx.data, activities],
  );

  const issues = useMemo(
    () => (lines.length === 0 ? [] : validatePlan(lines, { accountKinds, knownActivities })),
    [lines, accountKinds, knownActivities],
  );
  const errors = issues.filter((i) => i.level === "error");
  const warnings = issues.filter((i) => i.level === "warning");

  const months = useMemo(() => {
    const y = fiscalYear ?? ctx.data?.fiscalYear ?? 2027;
    return fiscalMonths(`${y - 1}-10-01`);
  }, [fiscalYear, ctx.data]);

  const accountOptions = useMemo(
    () =>
      (ctx.data?.accounts ?? [])
        .filter((a) => a.type === "income" || a.type === "expense")
        .map((a) => ({
          value: a.code,
          label: `${a.code} · ${a.name}`,
          group: a.type === "income" ? "Income" : "Expenditure",
        })),
    [ctx.data],
  );

  const periodOptions = useMemo(
    () => [
      { value: "0", label: "Annual" },
      ...months.map((m) => ({ value: String(m.no), label: m.label })),
    ],
    [months],
  );

  /* ── Plan mutation helpers ──────────────────────────────────────────────── */
  function setLineAmount(key: string, raw: string) {
    setTexts((t) => ({ ...t, [key]: raw }));
    const n = parseMoney(raw);
    setLines((ls) => ls.map((l) => (l.key === key ? { ...l, amount: n } : l)));
  }

  function amountText(l: PlanLine) {
    return texts[l.key] ?? (l.amount === 0 ? "" : String(l.amount));
  }

  function addLine(activityCode: string | null, kind: PlanKind) {
    const defaultAccount =
      (ctx.data?.accounts ?? []).find((a) => a.type === kind)?.code ?? "";
    const key = nextLineKey(lines);
    setLines((ls) => [
      ...ls,
      { key, accountCode: defaultAccount, kind, activityCode, periodNo: 0, amount: 0 },
    ]);
    setTexts((t) => ({ ...t, [key]: "" }));
  }

  function updateLine(key: string, patch: Partial<PlanLine>) {
    setLines((ls) => ls.map((l) => (l.key === key ? { ...l, ...patch } : l)));
  }

  function removeLine(key: string) {
    setLines((ls) => ls.filter((l) => l.key !== key));
    setTexts((t) => {
      const c = { ...t };
      delete c[key];
      return c;
    });
  }

  function doUplift() {
    const p = Number(uplift);
    if (!Number.isFinite(p)) return;
    setLines((ls) => applyUplift(ls, p));
    setTexts({});
    toast(`Scaled every line by ${p > 0 ? "+" : ""}${p}%`);
  }

  function doSpread() {
    setLines((ls) => spreadOverMonths(ls, 12));
    setTexts({});
    toast("Annual lines split into 12 months");
  }

  function doCollapse() {
    setLines((ls) => clonePlan(collapseToAnnual(ls)));
    setTexts({});
    toast("Monthly lines combined into annual lines");
  }

  function applyCopyFromSource() {
    const src = ctx.data?.copyLines ?? [];
    if (src.length === 0) return;
    setLines(
      src.map((l: any) => ({
        key: uid(),
        accountCode: l.accountCode,
        kind: l.kind as PlanKind,
        activityCode: l.activityCode,
        periodNo: l.periodNo ?? 0,
        amount: l.amount,
      })),
    );
    setTexts({});
    setCopyApplied(true);
    const p = Number(uplift);
    if (Number.isFinite(p) && p !== 0) {
      setLines((ls) => applyUplift(ls, p));
    }
    toast(`Copied ${src.length} lines from ${ctx.data?.copySource?.name ?? "the prior budget"}`);
  }

  /* ── Commit ─────────────────────────────────────────────────────────────── */
  const commit = trpc.budgets.commit.useMutation({
    onSuccess: () => {
      utils.budgets.list.invalidate();
      utils.budgets.variance.invalidate();
      toast("Budget saved");
      setTimeout(() => navigate("/budget"), 400);
    },
  });

  function save() {
    if (!fiscalYear || errors.length > 0) return;
    commit.mutate({
      id: editId ?? undefined,
      fiscalYear,
      name,
      status,
      replaceExisting: !!editId,
      activities: activities.map((a) => ({
        code: a.code,
        name: a.name,
        startDate: a.startDate || undefined,
        endDate: a.endDate || undefined,
        budgetCategory: a.budgetCategory || undefined,
        fundCode: a.fundCode || "GEN",
        status: (a.status as any) || "planned",
      })),
      lines: lines.map((l) => ({
        accountCode: l.accountCode,
        activityCode: l.activityCode || undefined,
        periodNo: l.periodNo,
        amount: l.amount,
      })),
    });
  }

  /* ── Step gating ────────────────────────────────────────────────────────── */
  function canAdvance(): boolean {
    if (step === 0) return !!fiscalYear && name.trim().length > 0;
    if (step === 1) return true; // an organisation-wide budget may have no activities
    if (step === 2) return lines.length > 0 && errors.length === 0;
    return false;
  }

  const loading = ctx.isLoading || (!!editId && (existingLines.isLoading || allBudgets.isLoading));
  const loadError = ctx.error ?? existingLines.error ?? allBudgets.error;

  return (
    <AppShell
      title={editId ? "Revise budget" : "New budget"}
      subtitle={
        editId
          ? "Rebuild this plan. Saving replaces its lines; the ledger is untouched."
          : "Build a year's budget from scratch — activities first, then what each one costs and raises."
      }
    >
      {toastNode}
      {loading ? (
        <Loading label="Preparing the wizard…" />
      ) : loadError ? (
        <ErrorBox error={loadError} />
      ) : (
        <div className="grid gap-5 lg:grid-cols-[1fr_18rem]">
          <div className="space-y-4">
            <Stepper step={step} onJump={(s) => setStep(s)} />

            {step === 0 && (
              <StepYear
                fiscalYear={fiscalYear}
                onYear={(y) => {
                  setFiscalYear(y);
                  if (!nameTouched) setName(`URPSA Budget ${fiscalYearLabel(y)}`);
                }}
                choices={ctx.data?.fiscalYearChoices ?? []}
                name={name}
                onName={(v) => {
                  setName(v);
                  setNameTouched(true);
                }}
                budgets={ctx.data?.budgets ?? []}
                copySource={copySource}
                onCopySource={setCopySource}
                copyLines={(ctx.data?.copyLines?.length ?? 0) > 0}
                uplift={uplift}
                onUplift={setUplift}
                onApplyCopy={applyCopyFromSource}
                copyApplied={copyApplied}
                org={ctx.data?.org ?? null}
                editId={editId}
              />
            )}

            {step === 1 && (
              <StepActivities
                activities={activities}
                setActivities={setActivities}
                existing={(ctx.data?.activities ?? []).map((a) => a.code)}
                fiscalYear={fiscalYear!}
                onUseExisting={(code) => {
                  const a = ctx.data?.activities.find((x) => x.code === code);
                  if (!a) return;
                  setActivities((as) =>
                    as.some((x) => x.code === code) ? as : [...as, { ...a, persisted: true }],
                  );
                }}
                usedCodes={new Set(activities.map((a) => a.code))}
              />
            )}

            {step === 2 && (
              <StepLines
                lines={lines}
                activities={activities}
                existingActivities={ctx.data?.activities ?? []}
                accountOptions={accountOptions}
                periodOptions={periodOptions}
                amountText={amountText}
                onAmount={setLineAmount}
                onUpdate={updateLine}
                onRemove={removeLine}
                onAdd={addLine}
                issues={issues}
                uplift={uplift}
                onUplift={setUplift}
                onApplyUplift={doUplift}
                onSpread={doSpread}
                onCollapse={doCollapse}
              />
            )}

            {step === 3 && (
              <StepReview
                status={status}
                onStatus={setStatus}
                totals={totals}
                byActivity={byActivity}
                byAccount={byAccount}
                accountNames={accountNames}
                issues={issues}
                activities={activities}
                existingActivities={ctx.data?.activities ?? []}
                lineCount={lines.length}
                onJump={(s) => setStep(s)}
              />
            )}

            {/* Nav */}
            <div className="flex items-center justify-between gap-3 border-t border-border pt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => (step === 0 ? navigate("/budget") : setStep((step - 1) as Step))}
              >
                <ArrowLeft className="mr-1.5 h-3.5 w-3.5" />
                {step === 0 ? "Cancel" : "Back"}
              </Button>

              {step < 3 ? (
                <Button size="sm" disabled={!canAdvance()} onClick={() => setStep((step + 1) as Step)}>
                  Continue
                  <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
                </Button>
              ) : (
                <Button
                  size="sm"
                  disabled={commit.isPending || errors.length > 0 || lines.length === 0}
                  onClick={save}
                >
                  {commit.isPending ? (
                    "Saving…"
                  ) : (
                    <>
                      <Save className="mr-1.5 h-3.5 w-3.5" />
                      {editId ? "Save revision" : "Create budget"}
                    </>
                  )}
                </Button>
              )}
            </div>
            <FormError error={commit.error} />
          </div>

          {/* Live summary — visible on every step so the figure never surprises */}
          <SummaryRail
            totals={totals}
            lineCount={lines.length}
            activityCount={activities.length}
            fiscalYear={fiscalYear}
            errors={errors.length}
            warnings={warnings.length}
            onJump={(s) => setStep(s)}
            step={step}
          />
        </div>
      )}
    </AppShell>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   Stepper
   ───────────────────────────────────────────────────────────────────────────── */
function Stepper({ step, onJump }: { step: Step; onJump: (s: Step) => void }) {
  return (
    <ol className="grid gap-1.5 sm:grid-cols-4">
      {STEPS.map((s, i) => {
        const done = i < step;
        const active = i === step;
        const Icon = s.icon;
        return (
          <li key={s.title}>
            <button
              onClick={() => onJump(i as Step)}
              disabled={i > step}
              className={`flex w-full items-start gap-2 rounded-md border px-2.5 py-2 text-left transition-colors disabled:cursor-not-allowed ${
                active
                  ? "border-primary bg-secondary"
                  : done
                    ? "border-border bg-card hover:bg-muted/50"
                    : "border-border bg-card opacity-60"
              }`}
            >
              <span
                className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold ${
                  done
                    ? "bg-primary text-primary-foreground"
                    : active
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground"
                }`}
              >
                {done ? <Check className="h-2.5 w-2.5" /> : i + 1}
              </span>
              <span className="min-w-0">
                <span className="block text-xs font-semibold leading-tight">{s.title}</span>
                <span className="mt-0.5 line-clamp-2 block text-[10px] leading-tight text-muted-foreground">
                  {s.blurb}
                </span>
              </span>
              <Icon className="ml-auto mt-0.5 hidden h-3.5 w-3.5 shrink-0 text-muted-foreground xl:block" />
            </button>
          </li>
        );
      })}
    </ol>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   Step 1 — year, name, starting point
   ───────────────────────────────────────────────────────────────────────────── */
function StepYear({
  fiscalYear,
  onYear,
  choices,
  name,
  onName,
  budgets,
  copySource,
  onCopySource,
  copyLines,
  uplift,
  onUplift,
  onApplyCopy,
  copyApplied,
  org,
  editId,
}: {
  fiscalYear: number | null;
  onYear: (y: number) => void;
  choices: number[];
  name: string;
  onName: (v: string) => void;
  budgets: { id: string; fiscalYear: number; name: string; version: number; status: string }[];
  copySource: string | null;
  onCopySource: (v: string | null) => void;
  copyLines: boolean;
  uplift: string;
  onUplift: (v: string) => void;
  onApplyCopy: () => void;
  copyApplied: boolean;
  org: { legalName: string; periodStart: string; periodEnd: string } | null;
  editId: string | null;
}) {
  const range = fiscalYear ? fiscalYearRange(fiscalYear) : null;
  const prior = budgets.filter((b) => fiscalYear && b.fiscalYear < fiscalYear);

  return (
    <div className="space-y-4">
      <Panel>
        <SectionHead right={<span className="label-cap">1 October – 30 September</span>}>
          Which year is this budget for?
        </SectionHead>
        <div className="grid gap-2 sm:grid-cols-2">
          {(choices.length ? choices : [2028, 2027, 2026, 2025]).map((y) => {
            const active = fiscalYear === y;
            const existing = budgets.filter((b) => b.fiscalYear === y);
            return (
              <button
                key={y}
                onClick={() => onYear(y)}
                className={`rounded-md border p-3 text-left transition-colors ${
                  active ? "border-primary bg-secondary" : "border-border bg-card hover:bg-muted/50"
                }`}
              >
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-sm font-semibold">{fiscalYearLabel(y)}</span>
                  {active && <Check className="h-3.5 w-3.5 text-primary" />}
                </div>
                <div className="mt-0.5 text-[11px] text-muted-foreground">
                  {fiscalYearRange(y).start} → {fiscalYearRange(y).end}
                </div>
                {existing.length > 0 && (
                  <div className="mt-1 text-[10px] text-warn">
                    {existing.length} budget{existing.length === 1 ? "" : "s"} already on file
                  </div>
                )}
              </button>
            );
          })}
        </div>
        {range && org && (
          <p className="mt-2 text-[11px] text-muted-foreground">
            The association's administration year runs {org.periodStart} to {org.periodEnd}. A budget
            filed under {fiscalYearLabel(fiscalYear!)} covers {range.start} to {range.end}.
          </p>
        )}
      </Panel>

      <Panel>
        <SectionHead>Name this budget</SectionHead>
        <Field label="Budget name" required hint="How it appears in the budget picker and on exports.">
          <TextInput value={name} onChange={onName} placeholder="URPSA Budget 2027/2028" />
        </Field>
        {!editId && (
          <p className="mt-2 text-[11px] text-muted-foreground">
            Saved as a <strong className="font-semibold">draft</strong> first. You can mark it approved
            on the review step once the numbers are agreed.
          </p>
        )}
      </Panel>

      {!editId && (
        <Panel>
          <SectionHead right={<span className="label-cap">Optional</span>}>
            Start from an existing budget
          </SectionHead>
          {prior.length === 0 ? (
            <p className="text-xs text-muted-foreground">
              There is no earlier budget to copy from, so this plan starts empty. That is normal for a
              first year.
            </p>
          ) : (
            <div className="space-y-2">
              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  onClick={() => onCopySource(null)}
                  className={`rounded-md border p-2.5 text-left transition-colors ${
                    copySource === null
                      ? "border-primary bg-secondary"
                      : "border-border bg-card hover:bg-muted/50"
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-xs font-semibold">
                    <Plus className="h-3 w-3" /> Start from scratch
                  </div>
                  <div className="mt-0.5 text-[11px] text-muted-foreground">
                    An empty plan. Every line entered by hand.
                  </div>
                </button>
                {prior.slice(0, 3).map((b) => (
                  <button
                    key={b.id}
                    onClick={() => onCopySource(b.id)}
                    className={`rounded-md border p-2.5 text-left transition-colors ${
                      copySource === b.id
                        ? "border-primary bg-secondary"
                        : "border-border bg-card hover:bg-muted/50"
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs font-semibold">
                      <Copy className="h-3 w-3" /> {b.name}
                    </div>
                    <div className="mt-0.5 text-[11px] text-muted-foreground">
                      {fiscalYearLabel(b.fiscalYear)} · {b.status}
                    </div>
                  </button>
                ))}
              </div>

              {copySource && (
                <div className="flex flex-wrap items-end gap-2 rounded-md border border-border bg-muted/30 p-2.5">
                  <Field label="Scale every line by" hint="Blank or 0 copies the figures exactly.">
                    <div className="flex items-center gap-1">
                      <TextInput
                        value={uplift}
                        onChange={onUplift}
                        type="number"
                        step="0.1"
                        className="w-20"
                      />
                      <span className="text-xs text-muted-foreground">%</span>
                    </div>
                  </Field>
                  <Button size="sm" onClick={onApplyCopy} disabled={!copyLines}>
                    <Copy className="mr-1.5 h-3.5 w-3.5" />
                    Copy {copyLines ? "into this plan" : "(no lines)"}
                  </Button>
                  {copyApplied && (
                    <span className="flex items-center gap-1 text-[11px] font-medium text-favourable">
                      <Check className="h-3 w-3" /> copied — edit them on step 3
                    </span>
                  )}
                </div>
              )}
              <p className="text-[11px] text-muted-foreground">
                Copying takes the <em>lines</em> only. The source budget is left exactly as it is, and
                past transactions are never touched — they keep belonging to the year they were
                spent in.
              </p>
            </div>
          )}
        </Panel>
      )}
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   Step 2 — activities
   ───────────────────────────────────────────────────────────────────────────── */
function StepActivities({
  activities,
  setActivities,
  existing,
  fiscalYear,
  onUseExisting,
  usedCodes,
}: {
  activities: PlanActivity[];
  setActivities: (f: (a: PlanActivity[]) => PlanActivity[]) => void;
  existing: string[];
  fiscalYear: number;
  onUseExisting: (code: string) => void;
  usedCodes: Set<string>;
}) {
  const [draft, setDraft] = useState<PlanActivity>({
    code: "",
    name: "",
    startDate: "",
    endDate: "",
    budgetCategory: "",
    fundCode: "GEN",
    status: "planned",
  });
  const [editingCode, setEditingCode] = useState<string | null>(null);

  const unusedExisting = existing.filter((c) => !usedCodes.has(c));

  function add() {
    if (!draft.code.trim() || !draft.name.trim()) return;
    if (activities.some((a) => a.code === draft.code.trim())) return;
    setActivities((as) => [
      ...as,
      {
        ...draft,
        code: draft.code.trim().toUpperCase(),
        name: draft.name.trim(),
        persisted: existing.includes(draft.code.trim().toUpperCase()),
      },
    ]);
    setDraft({
      code: "",
      name: "",
      startDate: "",
      endDate: "",
      budgetCategory: "",
      fundCode: "GEN",
      status: "planned",
    });
    setEditingCode(null);
  }

  function suggestCode() {
    const n = activities.length + 1;
    const yy = String(fiscalYear).slice(2);
    const base = draft.name
      ? draft.name
          .toUpperCase()
          .replace(/[^A-Z0-9 ]/g, "")
          .trim()
          .split(/\s+/)
          .slice(0, 2)
          .map((w) => w.slice(0, 4))
          .join("-")
      : `ACT-${n}`;
    return `${base}-${yy}`;
  }

  return (
    <div className="space-y-4">
      <Panel>
        <SectionHead right={<span className="label-cap">Optional — skip for org-wide only</span>}>
          Activities this budget covers
        </SectionHead>
        <p className="mb-3 text-[11px] leading-relaxed text-muted-foreground">
          An activity is an event or project whose income and spend you want to track as a unit — a
          fresher's orientation, a conference, a welfare programme. Tagging transactions to an activity
          later is what lets the Budget page show a variance for that event on its own.
        </p>

        {activities.length > 0 && (
          <div className="mb-3 overflow-x-auto rounded border border-border">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Activity</th>
                  <th>Dates</th>
                  <th>Category</th>
                  <th>Status</th>
                  <th className="w-16" />
                </tr>
              </thead>
              <tbody>
                {activities.map((a) => (
                  <tr key={a.code}>
                    <td className="tnum text-xs">{a.code}</td>
                    <td className="text-sm">{a.name}</td>
                    <td className="tnum text-[11px] text-muted-foreground">
                      {a.startDate || "—"} → {a.endDate || "—"}
                    </td>
                    <td className="text-xs text-muted-foreground">{a.budgetCategory || "—"}</td>
                    <td className="text-xs">
                      <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide">
                        {a.status ?? "planned"}
                      </span>
                    </td>
                    <td className="whitespace-nowrap">
                      <RowAction
                        onClick={() => {
                          setEditingCode(a.code);
                          setDraft({ ...a });
                        }}
                        title="Edit activity"
                      >
                        <Pencil className="h-3 w-3" />
                      </RowAction>
                      <RowAction
                        onClick={() => setActivities((as) => as.filter((x) => x.code !== a.code))}
                        tone="danger"
                        title="Remove from plan"
                      >
                        <Trash2 className="h-3 w-3" />
                      </RowAction>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="rounded-md border border-dashed border-border bg-muted/20 p-3">
          <div className="mb-2 text-xs font-semibold">
            {editingCode ? `Editing ${editingCode}` : "Add an activity"}
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <Field label="Activity name" required>
              <TextInput
                value={draft.name}
                onChange={(v) => setDraft({ ...draft, name: v })}
                placeholder="Fresher's Orientation"
              />
            </Field>
            <Field
              label="Activity code"
              required
              hint="Used to tag transactions. Uppercase, no spaces."
            >
              <div className="flex gap-1">
                <TextInput
                  value={draft.code}
                  onChange={(v) => setDraft({ ...draft, code: v.toUpperCase() })}
                  placeholder="FRESH-ORI-27"
                  disabled={!!editingCode}
                />
                {!editingCode && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDraft({ ...draft, code: suggestCode() })}
                    title="Suggest a code from the name"
                  >
                    <Wand2 className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </Field>
            <Field label="Start date">
              <TextInput
                type="date"
                value={draft.startDate ?? ""}
                onChange={(v) => setDraft({ ...draft, startDate: v })}
              />
            </Field>
            <Field label="End date">
              <TextInput
                type="date"
                value={draft.endDate ?? ""}
                onChange={(v) => setDraft({ ...draft, endDate: v })}
              />
            </Field>
            <Field label="Budget category" hint="Free text — how the workbook groups activities.">
              <TextInput
                value={draft.budgetCategory ?? ""}
                onChange={(v) => setDraft({ ...draft, budgetCategory: v })}
                placeholder="Programme"
              />
            </Field>
            <Field label="Fund">
              <Select
                value={draft.fundCode ?? "GEN"}
                onChange={(v) => setDraft({ ...draft, fundCode: v })}
                options={[
                  { value: "GEN", label: "GEN · General (unrestricted)" },
                  { value: "PROG", label: "PROG · Programme (designated)" },
                  { value: "SPON", label: "SPON · Sponsorship (restricted)" },
                  { value: "WELF", label: "WELF · Welfare (designated)" },
                ]}
              />
            </Field>
          </div>
          <div className="mt-2 flex items-center gap-2">
            <Button
              size="sm"
              onClick={add}
              disabled={
                !draft.code.trim() ||
                !draft.name.trim() ||
                (!editingCode && activities.some((a) => a.code === draft.code.trim().toUpperCase()))
              }
            >
              {editingCode ? (
                <>
                  <Check className="mr-1.5 h-3.5 w-3.5" /> Save activity
                </>
              ) : (
                <>
                  <Plus className="mr-1.5 h-3.5 w-3.5" /> Add activity
                </>
              )}
            </Button>
            {editingCode && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setEditingCode(null);
                    setDraft({
                      code: "",
                      name: "",
                      startDate: "",
                      endDate: "",
                      budgetCategory: "",
                      fundCode: "GEN",
                      status: "planned",
                    });
                  }}
                >
                  <X className="mr-1.5 h-3.5 w-3.5" /> Cancel
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setActivities((as) => as.map((x) => (x.code === editingCode ? { ...draft } : x)));
                    setEditingCode(null);
                    setDraft({
                      code: "",
                      name: "",
                      startDate: "",
                      endDate: "",
                      budgetCategory: "",
                      fundCode: "GEN",
                      status: "planned",
                    });
                  }}
                >
                  <Check className="mr-1.5 h-3.5 w-3.5" /> Apply change
                </Button>
              </>
            )}
          </div>
        </div>

        {unusedExisting.length > 0 && (
          <div className="mt-3">
            <div className="label-cap mb-1.5">Already in the register</div>
            <div className="flex flex-wrap gap-1.5">
              {unusedExisting.map((c) => (
                <button
                  key={c}
                  onClick={() => onUseExisting(c)}
                  className="flex items-center gap-1 rounded border border-border bg-card px-2 py-1 text-[11px] hover:bg-muted/60"
                >
                  <Plus className="h-2.5 w-2.5" /> {c}
                </button>
              ))}
            </div>
          </div>
        )}
      </Panel>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   Step 3 — the lines
   ───────────────────────────────────────────────────────────────────────────── */
function StepLines({
  lines,
  activities,
  existingActivities,
  accountOptions,
  periodOptions,
  amountText,
  onAmount,
  onUpdate,
  onRemove,
  onAdd,
  issues,
  uplift,
  onUplift,
  onApplyUplift,
  onSpread,
  onCollapse,
}: {
  lines: PlanLine[];
  activities: PlanActivity[];
  existingActivities: { code: string; name: string }[];
  accountOptions: { value: string; label: string; group?: string }[];
  periodOptions: { value: string; label: string }[];
  amountText: (l: PlanLine) => string;
  onAmount: (key: string, raw: string) => void;
  onUpdate: (key: string, patch: Partial<PlanLine>) => void;
  onRemove: (key: string) => void;
  onAdd: (activityCode: string | null, kind: PlanKind) => void;
  issues: { level: "error" | "warning"; message: string; keys: string[] }[];
  uplift: string;
  onUplift: (v: string) => void;
  onApplyUplift: () => void;
  onSpread: () => void;
  onCollapse: () => void;
}) {
  // Every activity in the plan, plus any activity a line already names, plus the
  // organisation-wide bucket. Grouping by activity is what makes the plan read
  // like the workbook's Activities-Budgets sheet.
  const groups = useMemo(() => {
    const seen = new Map<string, { code: string | null; name: string; lines: PlanLine[] }>();
    seen.set("", { code: null, name: "General (organisation-wide)", lines: [] });
    for (const a of activities) {
      seen.set(a.code, { code: a.code, name: a.name, lines: [] });
    }
    for (const l of lines) {
      if (l.activityCode && !seen.has(l.activityCode)) {
        const known =
          existingActivities.find((x) => x.code === l.activityCode)?.name ?? l.activityCode;
        seen.set(l.activityCode, { code: l.activityCode, name: known, lines: [] });
      }
    }
    for (const l of lines) {
      seen.get(l.activityCode ?? "")!.lines.push(l);
    }
    return [...seen.values()];
  }, [activities, existingActivities, lines]);

  const errorKeys = new Set(issues.filter((i) => i.level === "error").flatMap((i) => i.keys));

  return (
    <div className="space-y-4">
      {/* Tools */}
      <Panel>
        <SectionHead right={<span className="label-cap">Applies to every line</span>}>
          Build tools
        </SectionHead>
        <div className="flex flex-wrap items-end gap-2">
          <Field label="Scale all amounts" hint="Annual uplift on the whole plan.">
            <div className="flex items-center gap-1">
              <TextInput value={uplift} onChange={onUplift} type="number" step="0.1" className="w-20" />
              <span className="text-xs text-muted-foreground">%</span>
            </div>
          </Field>
          <Button variant="outline" size="sm" onClick={onApplyUplift} disabled={lines.length === 0}>
            <Wand2 className="mr-1.5 h-3.5 w-3.5" /> Apply
          </Button>
          <div className="mx-1 h-8 w-px bg-border" />
          <Button variant="outline" size="sm" onClick={onSpread} disabled={lines.length === 0}>
            <Calendar className="mr-1.5 h-3.5 w-3.5" /> Spread over 12 months
          </Button>
          <Button variant="outline" size="sm" onClick={onCollapse} disabled={lines.length === 0}>
            <Layers className="mr-1.5 h-3.5 w-3.5" /> Combine to annual
          </Button>
        </div>
        <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
          Most budgets are annual figures, and the variance report pro-rates them for you. Spreading a
          line into months is only for a figure you genuinely expect to move month to month — a
          subscription, or a term-time allowance. The parts always add back to the original to the kobo.
        </p>
      </Panel>

      {activities.length === 0 && lines.length === 0 && (
        <EmptyState
          icon={<Target className="h-8 w-8" />}
          title="No activities, so this is an organisation-wide budget"
          body="Add a line below and it will sit under General. If you want per-event variance later, go back a step and add the activities first."
          action={
            <Button size="sm" onClick={() => onAdd(null, "expense")}>
              <Plus className="mr-1.5 h-3.5 w-3.5" /> Add the first expense line
            </Button>
          }
        />
      )}

      {groups.map((g) => {
        const sub = g.lines;
        const inc = sub.filter((l) => l.kind === "income").reduce((s, l) => s + l.amount, 0);
        const exp = sub.filter((l) => l.kind === "expense").reduce((s, l) => s + l.amount, 0);
        if (!g.code && sub.length === 0 && activities.length > 0) {
          // Still show the general bucket, but compactly.
        }
        return (
          <Panel key={g.code ?? "__general"}>
            <SectionHead
              right={
                <span className="tnum text-[11px] text-muted-foreground">
                  {ngn(inc)} in · {ngn(exp)} out ·{" "}
                  <span className={inc - exp >= 0 ? "text-favourable" : "text-adverse"}>
                    {ngnSigned(inc - exp)}
                  </span>
                </span>
              }
            >
              <span className="flex items-center gap-1.5">
                {g.code ? (
                  <span className="tnum rounded bg-muted px-1.5 py-0.5 text-[10px]">{g.code}</span>
                ) : (
                  <span className="rounded bg-muted px-1.5 py-0.5 text-[10px]">GENERAL</span>
                )}
                {g.name}
                {sub.length > 0 && (
                  <span className="text-[11px] font-normal text-muted-foreground">
                    ({sub.length} line{sub.length === 1 ? "" : "s"})
                  </span>
                )}
              </span>
            </SectionHead>

            {sub.length === 0 ? (
              <p className="py-1 text-xs text-muted-foreground">
                Nothing budgeted here yet.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="ledger">
                  <thead>
                    <tr>
                      <th className="w-20">Type</th>
                      <th>Category</th>
                      <th className="w-28">Period</th>
                      <th className="num w-32">Amount</th>
                      <th className="no-print w-10" />
                    </tr>
                  </thead>
                  <tbody>
                    {sub.map((l) => (
                      <tr key={l.key} className={errorKeys.has(l.key) ? "bg-destructive/5" : undefined}>
                        <td>
                          <span
                            className={`rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
                              l.kind === "income"
                                ? "bg-favourable-bg text-favourable"
                                : "bg-adverse-bg text-adverse"
                            }`}
                          >
                            {l.kind === "income" ? "In" : "Out"}
                          </span>
                        </td>
                        <td>
                          <Select
                            value={l.accountCode}
                            onChange={(v) => {
                              const kind = (v.startsWith("4") ? "income" : "expense") as PlanKind;
                              onUpdate(l.key, { accountCode: v, kind });
                            }}
                            options={accountOptions}
                            placeholder="Choose an account…"
                          />
                        </td>
                        <td>
                          <Select
                            value={String(l.periodNo)}
                            onChange={(v) => onUpdate(l.key, { periodNo: Number(v) })}
                            options={periodOptions}
                          />
                        </td>
                        <td>
                          <MoneyInput value={amountText(l)} onChange={(v) => onAmount(l.key, v)} />
                        </td>
                        <td className="no-print">
                          <RowAction onClick={() => onRemove(l.key)} tone="danger" title="Remove line">
                            <Trash2 className="h-3 w-3" />
                          </RowAction>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className="mt-2 flex gap-1.5">
              <Button variant="outline" size="sm" onClick={() => onAdd(g.code, "expense")}>
                <Plus className="mr-1 h-3 w-3" /> Expense
              </Button>
              <Button variant="outline" size="sm" onClick={() => onAdd(g.code, "income")}>
                <Plus className="mr-1 h-3 w-3" /> Income
              </Button>
            </div>
          </Panel>
        );
      })}

      {issues.length > 0 && (
        <Panel>
          <SectionHead right={<span className="label-cap">{issues.length} to look at</span>}>
            Before you continue
          </SectionHead>
          <ul className="space-y-1.5">
            {issues.map((i, n) => (
              <li
                key={n}
                className={`flex items-start gap-2 rounded border px-2.5 py-1.5 text-xs ${
                  i.level === "error"
                    ? "border-destructive/30 bg-destructive/5 text-destructive"
                    : "border-warn/40 bg-warn-bg text-foreground"
                }`}
              >
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span>
                  <span className="font-semibold capitalize">{i.level}:</span> {i.message}
                </span>
              </li>
            ))}
          </ul>
        </Panel>
      )}
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   Step 4 — review
   ───────────────────────────────────────────────────────────────────────────── */
function StepReview({
  status,
  onStatus,
  totals,
  byActivity,
  byAccount,
  accountNames,
  issues,
  activities,
  existingActivities,
  lineCount,
  onJump,
}: {
  status: "draft" | "approved";
  onStatus: (v: "draft" | "approved") => void;
  totals: { income: number; expenditure: number; net: number; lineCount: number };
  byActivity: { activityCode: string | null; income: number; expenditure: number; net: number; lineCount: number }[];
  byAccount: { accountCode: string; kind: PlanKind; amount: number; lineCount: number }[];
  accountNames: Record<string, string>;
  issues: { level: "error" | "warning"; message: string; keys: string[] }[];
  activities: PlanActivity[];
  existingActivities: { code: string; name: string }[];
  lineCount: number;
  onJump: (s: Step) => void;
}) {
  const errors = issues.filter((i) => i.level === "error");
  const warnings = issues.filter((i) => i.level === "warning");

  function actName(code: string | null) {
    if (!code) return "General (organisation-wide)";
    return (
      activities.find((a) => a.code === code)?.name ??
      existingActivities.find((a) => a.code === code)?.name ??
      code
    );
  }

  return (
    <div className="space-y-4">
      {/* Headline */}
      <div className="grid gap-3 sm:grid-cols-3">
        <Panel>
          <div className="label-cap">Budgeted income</div>
          <div className="tnum mt-1.5 text-xl font-semibold text-favourable">{ngn(totals.income)}</div>
        </Panel>
        <Panel>
          <div className="label-cap">Budgeted expenditure</div>
          <div className="tnum mt-1.5 text-xl font-semibold text-adverse">{ngn(totals.expenditure)}</div>
        </Panel>
        <Panel>
          <div className="label-cap">{totals.net >= 0 ? "Budgeted surplus" : "Budgeted deficit"}</div>
          <div
            className={`tnum mt-1.5 text-xl font-semibold ${
              totals.net >= 0 ? "text-favourable" : "text-adverse"
            }`}
          >
            {ngnSigned(totals.net)}
          </div>
        </Panel>
      </div>

      {errors.length > 0 && (
        <div className="rounded-md border border-destructive/30 bg-destructive/5 p-3">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-destructive">
            <AlertTriangle className="h-3.5 w-3.5" /> {errors.length} problem
            {errors.length === 1 ? "" : "s"} must be fixed before saving
          </div>
          <ul className="mt-1.5 list-disc space-y-0.5 pl-4 text-[11px] text-destructive">
            {errors.map((e, i) => (
              <li key={i}>{e.message}</li>
            ))}
          </ul>
          <Button variant="outline" size="sm" className="mt-2" onClick={() => onJump(2)}>
            <ArrowLeft className="mr-1.5 h-3.5 w-3.5" /> Back to the lines
          </Button>
        </div>
      )}

      {warnings.length > 0 && (
        <div className="rounded-md border border-warn/40 bg-warn-bg p-3">
          <div className="flex items-center gap-1.5 text-xs font-semibold">
            <Info className="h-3.5 w-3.5" /> Worth a second look
          </div>
          <ul className="mt-1.5 list-disc space-y-0.5 pl-4 text-[11px]">
            {warnings.map((w, i) => (
              <li key={i}>{w.message}</li>
            ))}
          </ul>
          <p className="mt-1.5 text-[10px] text-muted-foreground">
            These do not block saving — a budgeted deficit is a legitimate plan if it is deliberate.
          </p>
        </div>
      )}

      {/* By activity */}
      <Panel>
        <SectionHead right={<span className="label-cap">{byActivity.length} group(s)</span>}>
          By activity
        </SectionHead>
        <div className="overflow-x-auto">
          <table className="ledger">
            <thead>
              <tr>
                <th>Activity</th>
                <th className="num">Income</th>
                <th className="num">Expenditure</th>
                <th className="num">Net</th>
                <th className="num">Lines</th>
              </tr>
            </thead>
            <tbody>
              {byActivity.map((a) => (
                <tr key={a.activityCode ?? "__general"}>
                  <td className="text-sm">
                    {a.activityCode ? (
                      <>
                        <span className="tnum mr-1.5 rounded bg-muted px-1.5 py-0.5 text-[10px]">
                          {a.activityCode}
                        </span>
                        {actName(a.activityCode)}
                      </>
                    ) : (
                      <span className="text-muted-foreground">{actName(null)}</span>
                    )}
                  </td>
                  <td className="num text-sm">{ngn(a.income)}</td>
                  <td className="num text-sm">{ngn(a.expenditure)}</td>
                  <td className={`num text-sm ${a.net >= 0 ? "text-favourable" : "text-adverse"}`}>
                    {ngnSigned(a.net)}
                  </td>
                  <td className="num text-xs text-muted-foreground">{a.lineCount}</td>
                </tr>
              ))}
              <tr className="total-row">
                <td>Total</td>
                <td className="num">{ngn(totals.income)}</td>
                <td className="num">{ngn(totals.expenditure)}</td>
                <td className="num">{ngnSigned(totals.net)}</td>
                <td className="num">{lineCount}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </Panel>

      {/* By account */}
      <Panel>
        <SectionHead right={<span className="label-cap">What the variance report will compare</span>}>
          By category
        </SectionHead>
        <div className="overflow-x-auto">
          <table className="ledger">
            <thead>
              <tr>
                <th>Code</th>
                <th>Account</th>
                <th className="w-20">Type</th>
                <th className="num">Budget</th>
              </tr>
            </thead>
            <tbody>
              {byAccount.map((a) => (
                <tr key={`${a.kind}|${a.accountCode}`}>
                  <td className="tnum text-xs">{a.accountCode}</td>
                  <td className="text-sm">{accountNames[a.accountCode] ?? a.accountCode}</td>
                  <td>
                    <span
                      className={`rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${
                        a.kind === "income"
                          ? "bg-favourable-bg text-favourable"
                          : "bg-adverse-bg text-adverse"
                      }`}
                    >
                      {a.kind === "income" ? "In" : "Out"}
                    </span>
                  </td>
                  <td className="num text-sm">{ngn(a.amount)}</td>
                </tr>
              ))}
              <tr className="total-row">
                <td colSpan={3}>Total budgeted</td>
                <td className="num">{ngn(totals.income + totals.expenditure)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </Panel>

      <Panel>
        <SectionHead>Status on save</SectionHead>
        <div className="grid gap-2 sm:grid-cols-2">
          <button
            onClick={() => onStatus("draft")}
            className={`rounded-md border p-2.5 text-left ${
              status === "draft" ? "border-primary bg-secondary" : "border-border bg-card"
            }`}
          >
            <div className="text-xs font-semibold">Save as draft</div>
            <div className="mt-0.5 text-[11px] text-muted-foreground">
              Still being worked on. Editable and clearly marked.
            </div>
          </button>
          <button
            onClick={() => onStatus("approved")}
            className={`rounded-md border p-2.5 text-left ${
              status === "approved" ? "border-primary bg-secondary" : "border-border bg-card"
            }`}
          >
            <div className="text-xs font-semibold">Mark as approved</div>
            <div className="mt-0.5 text-[11px] text-muted-foreground">
              The figures have been agreed. Still editable, but recorded as the approved plan.
            </div>
          </button>
        </div>
        <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
          Saving a budget writes the plan only. No transaction and no journal entry is created — a
          budget is what you intend to spend, and the ledger records what you actually spent. Because of
          that, saving here cannot unbalance the books.
        </p>
      </Panel>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   Live summary rail
   ───────────────────────────────────────────────────────────────────────────── */
function SummaryRail({
  totals,
  lineCount,
  activityCount,
  fiscalYear,
  errors,
  warnings,
  onJump,
  step,
}: {
  totals: { income: number; expenditure: number; net: number };
  lineCount: number;
  activityCount: number;
  fiscalYear: number | null;
  errors: number;
  warnings: number;
  onJump: (s: Step) => void;
  step: Step;
}) {
  return (
    <aside className="space-y-3 lg:sticky lg:top-4 lg:self-start">
      <Panel>
        <div className="label-cap mb-2">Your plan so far</div>
        <div className="space-y-2">
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-xs text-muted-foreground">Year</span>
            <span className="tnum text-xs font-semibold">
              {fiscalYear ? fiscalYearLabel(fiscalYear) : "—"}
            </span>
          </div>
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-xs text-muted-foreground">Activities</span>
            <span className="tnum text-xs font-semibold">{activityCount}</span>
          </div>
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-xs text-muted-foreground">Lines</span>
            <span className="tnum text-xs font-semibold">{lineCount}</span>
          </div>
          <div className="my-2 h-px bg-border" />
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-xs text-muted-foreground">Income</span>
            <span className="tnum text-xs font-semibold text-favourable">{ngn(totals.income)}</span>
          </div>
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-xs text-muted-foreground">Expenditure</span>
            <span className="tnum text-xs font-semibold text-adverse">{ngn(totals.expenditure)}</span>
          </div>
          <div className="mt-1 flex items-baseline justify-between gap-2 border-t border-border pt-2">
            <span className="text-xs font-medium">
              {totals.net >= 0 ? "Surplus" : "Deficit"}
            </span>
            <span
              className={`tnum text-sm font-semibold ${
                totals.net >= 0 ? "text-favourable" : "text-adverse"
              }`}
            >
              {ngnSigned(totals.net)}
            </span>
          </div>
        </div>
      </Panel>

      {(errors > 0 || warnings > 0) && (
        <Panel>
          <div className="label-cap mb-1.5">Checks</div>
          {errors > 0 && (
            <button
              onClick={() => onJump(2)}
              className="flex w-full items-center gap-1.5 rounded border border-destructive/30 bg-destructive/5 px-2 py-1.5 text-left text-[11px] text-destructive"
            >
              <AlertTriangle className="h-3 w-3 shrink-0" />
              {errors} error{errors === 1 ? "" : "s"} blocking save
            </button>
          )}
          {warnings > 0 && (
            <div className="mt-1.5 flex items-center gap-1.5 rounded border border-warn/40 bg-warn-bg px-2 py-1.5 text-[11px]">
              <Info className="h-3 w-3 shrink-0" />
              {warnings} note{warnings === 1 ? "" : "s"} — not blocking
            </div>
          )}
        </Panel>
      )}

      <Panel>
        <div className="label-cap mb-1.5">Jump to</div>
        <div className="space-y-0.5">
          {STEPS.map((s, i) => (
            <button
              key={s.title}
              onClick={() => onJump(i as Step)}
              disabled={i > 3}
              className={`flex w-full items-center gap-1.5 rounded px-1.5 py-1 text-left text-[11px] transition-colors ${
                i === step
                  ? "bg-secondary font-semibold text-secondary-foreground"
                  : "text-muted-foreground hover:bg-muted/60"
              }`}
            >
              <span className="tnum w-3 text-[10px]">{i + 1}</span>
              {s.title}
            </button>
          ))}
        </div>
      </Panel>
    </aside>
  );
}
