import { useMemo, useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { EmptyState, Loading, ErrorBox, SectionHead, Panel } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ngn, fmtDate, today } from "@shared/finance";
import { roleFlags } from "@/lib/roles";
import { ArrowLeftRight, Plus, Search, Upload, X, CheckCircle2 } from "lucide-react";

export default function Transactions() {
  const utils = trpc.useUtils();
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<"" | "Income" | "Expense">("");
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 50;

  const list = trpc.transactions.list.useQuery({
    search: search || undefined,
    type: typeFilter || undefined,
    limit: PAGE_SIZE,
    offset: page * PAGE_SIZE,
  });
  const rows = list.data?.rows ?? [];
  const total = list.data?.total ?? 0;
  const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const postable = trpc.accounts.postable.useQuery();
  const cash = trpc.cash.list.useQuery();
  const activities = trpc.activities.list.useQuery();
  // Posting is a register write: the auditor may do it, the president may not.
  const access = trpc.access.list.useQuery(undefined, { staleTime: 60_000 });
  const { canEnterRegisters } = roleFlags(access.data?.myRole);

  const incomeAccounts = useMemo(
    () => (postable.data ?? []).filter((a) => a.type === "income"),
    [postable.data],
  );
  const expenseAccounts = useMemo(
    () => (postable.data ?? []).filter((a) => a.type === "expense"),
    [postable.data],
  );

  return (
    <AppShell
      title="Transactions"
      subtitle="The master register — every row posts a balanced double entry."
      actions={
        canEnterRegisters ? (
          <Button onClick={() => setShowForm((v) => !v)} size="sm">
            {showForm ? <X className="mr-1.5 h-3.5 w-3.5" /> : <Plus className="mr-1.5 h-3.5 w-3.5" />}
            {showForm ? "Close" : "New transaction"}
          </Button>
        ) : undefined
      }
    >
      <div className="space-y-5">
        {showForm && (
          <EntryForm
            incomeAccounts={incomeAccounts}
            expenseAccounts={expenseAccounts}
            cashAccounts={cash.data ?? []}
            activities={activities.data ?? []}
            onDone={async () => {
              setShowForm(false);
              await utils.transactions.list.invalidate();
              await utils.dashboard.summary.invalidate();
            }}
          />
        )}

        <Panel>
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(0);
                }}
                placeholder="Search payee, reference or TXN id…"
                className="pl-8"
              />
            </div>
            <div className="flex gap-1 rounded-md border border-border p-0.5">
              {(["", "Income", "Expense"] as const).map((t) => (
                <button
                  key={t || "all"}
                  onClick={() => {
                    setTypeFilter(t);
                    setPage(0);
                  }}
                  className={`rounded px-2.5 py-1 text-xs font-medium transition-colors ${
                    typeFilter === t ? "bg-secondary text-secondary-foreground" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {t || "All"}
                </button>
              ))}
            </div>
          </div>

          {list.isLoading ? (
            <Loading />
          ) : list.error ? (
            <ErrorBox error={list.error} />
          ) : rows.length === 0 ? (
            <EmptyState
              icon={<ArrowLeftRight className="h-8 w-8" />}
              title={search || typeFilter ? "No transactions match" : "No transactions yet"}
              body={
                search || typeFilter
                  ? "Try a different search term or clear the filter."
                  : "Record your first receipt or payment. Each entry posts a balanced double entry and appears in every report."
              }
              action={
                !search && !typeFilter && canEnterRegisters ? (
                  <Button size="sm" onClick={() => setShowForm(true)}>
                    <Plus className="mr-1.5 h-3.5 w-3.5" /> New transaction
                  </Button>
                ) : undefined
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>Ref</th>
                    <th>Date</th>
                    <th>Payee / description</th>
                    <th>Category</th>
                    <th>Account</th>
                    <th>Activity</th>
                    <th className="num">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((t) => (
                    <tr key={t.id}>
                      <td className="tnum text-xs">
                        <Link
                          href={`/transactions/${t.id}`}
                          className="font-medium text-primary underline"
                        >
                          {t.txnId}
                        </Link>
                      </td>
                      <td className="tnum text-xs">{fmtDate(t.txnDate)}</td>
                      <td className="text-sm">{t.payee ?? "—"}</td>
                      <td className="tnum text-xs text-muted-foreground">{t.categoryCode}</td>
                      <td className="tnum text-xs text-muted-foreground">{t.cashAccountCode}</td>
                      <td className="text-xs text-muted-foreground">{t.activityCode ?? "—"}</td>
                      <td className={`num text-sm font-medium ${t.txnType === "Income" ? "text-favourable" : "text-adverse"}`}>
                        {t.txnType === "Income" ? "+" : "−"}
                        {ngn(t.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination. The register used to stop at 200 rows with no way past
              them; now every transaction is reachable. */}
          {total > 0 && (
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-border pt-3">
              <p className="text-xs text-muted-foreground">
                Showing <span className="tnum font-medium text-foreground">{page * PAGE_SIZE + 1}</span>–
                <span className="tnum font-medium text-foreground">{Math.min((page + 1) * PAGE_SIZE, total)}</span> of{" "}
                <span className="tnum font-medium text-foreground">{total}</span> transactions
              </p>
              <div className="flex items-center gap-1.5">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page === 0}
                  onClick={() => setPage((p) => Math.max(0, p - 1))}
                >
                  Previous
                </Button>
                <span className="tnum px-1 text-xs text-muted-foreground">
                  Page {page + 1} of {pageCount}
                </span>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page + 1 >= pageCount}
                  onClick={() => setPage((p) => p + 1)}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </Panel>
      </div>
    </AppShell>
  );
}

/* ── The entry form: single-entry input, double-entry output ───────────────── */
function EntryForm({
  incomeAccounts,
  expenseAccounts,
  cashAccounts,
  activities,
  onDone,
}: {
  incomeAccounts: { code: string; name: string }[];
  expenseAccounts: { code: string; name: string }[];
  cashAccounts: { code: string; name: string }[];
  activities: { code: string; name: string }[];
  onDone: () => Promise<void>;
}) {
  const [txnType, setTxnType] = useState<"Income" | "Expense">("Expense");
  const [txnDate, setTxnDate] = useState(today());
  const [categoryCode, setCategoryCode] = useState("");
  const [cashAccountCode, setCashAccountCode] = useState(cashAccounts[0]?.code ?? "BANK-01");
  const [payee, setPayee] = useState("");
  const [reference, setReference] = useState("");
  const [amount, setAmount] = useState("");
  const [activityCode, setActivityCode] = useState("");
  const [notes, setNotes] = useState("");
  const [evidenceId, setEvidenceId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const accounts = txnType === "Income" ? incomeAccounts : expenseAccounts;
  const create = trpc.transactions.create.useMutation();
  const createEvidence = trpc.evidence.create.useMutation();
  const setEvidenceStatus = trpc.evidence.setStatus.useMutation();
  const uploadUrl = trpc.files.uploadUrl.useMutation();
  const commit = trpc.files.commit.useMutation();

  const amountNum = Number(amount) || 0;
  const needsEvidence = amountNum >= 5000;

  async function handleFile(file: File) {
    setUploading(true);
    setError(null);
    try {
      const { key, uploadUrl: put } = await uploadUrl.mutateAsync({
        name: file.name,
        contentType: file.type || "application/octet-stream",
      });
      const res = await fetch(put, { method: "PUT", body: file, headers: { "Content-Type": file.type || "application/octet-stream" } });
      if (!res.ok) throw new Error("The upload failed. Try again.");
      await commit.mutateAsync({ key, name: file.name });
      const ev = await createEvidence.mutateAsync({
        docType: "receipt",
        description: file.name,
        storageKey: key,
        filePath: key,
        mimeType: file.type,
        fileSizeBytes: file.size,
      });
      // A document the treasurer just attached is treated as verified by them.
      await setEvidenceStatus.mutateAsync({ id: ev.id, status: "verified" });
      setEvidenceId(ev.id);
    } catch (e) {
      setError(e);
    } finally {
      setUploading(false);
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!categoryCode) {
      setError(new Error("Choose a category."));
      return;
    }
    if (amountNum <= 0) {
      setError(new Error("The amount must be greater than zero."));
      return;
    }
    try {
      await create.mutateAsync({
        txnType,
        txnDate,
        categoryCode,
        cashAccountCode,
        payee: payee || undefined,
        reference: reference || undefined,
        amount: amountNum,
        activityCode: activityCode || undefined,
        notes: notes || undefined,
        evidenceIds: evidenceId ? [evidenceId] : undefined,
      });
      await onDone();
    } catch (err) {
      setError(err);
    }
  }

  return (
    <Panel className="border-primary/30">
      <SectionHead>New transaction</SectionHead>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <div className="space-y-1.5">
            <Label>Type</Label>
            <div className="flex gap-1 rounded-md border border-border p-0.5">
              {(["Expense", "Income"] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => {
                    setTxnType(t);
                    setCategoryCode("");
                  }}
                  className={`flex-1 rounded px-2.5 py-1.5 text-xs font-medium transition-colors ${
                    txnType === t ? "bg-secondary text-secondary-foreground" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="date">Date</Label>
            <Input id="date" type="date" value={txnDate} onChange={(e) => setTxnDate(e.target.value)} required />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="amount">Amount (₦)</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              min="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              required
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="category">Category</Label>
            <select
              id="category"
              value={categoryCode}
              onChange={(e) => setCategoryCode(e.target.value)}
              className="h-9 w-full rounded-md border border-input bg-card px-2.5 text-sm"
              required
            >
              <option value="">Choose a category…</option>
              {accounts.map((a) => (
                <option key={a.code} value={a.code}>
                  {a.code} — {a.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="cash">Cash account</Label>
            <select
              id="cash"
              value={cashAccountCode}
              onChange={(e) => setCashAccountCode(e.target.value)}
              className="h-9 w-full rounded-md border border-input bg-card px-2.5 text-sm"
            >
              {cashAccounts.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.code} — {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="activity">Activity (optional)</Label>
            <select
              id="activity"
              value={activityCode}
              onChange={(e) => setActivityCode(e.target.value)}
              className="h-9 w-full rounded-md border border-input bg-card px-2.5 text-sm"
            >
              <option value="">None</option>
              {activities.map((a) => (
                <option key={a.code} value={a.code}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="payee">Payee / description</Label>
            <Input id="payee" value={payee} onChange={(e) => setPayee(e.target.value)} placeholder="e.g. Campus Printers — banners" />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="ref">Reference (optional)</Label>
            <Input id="ref" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="e.g. SPON-001" />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="notes">Notes (optional)</Label>
            <Input id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
        </div>

        {/* Evidence */}
        <div className="rounded-md border border-border bg-muted/30 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <div className="text-xs font-medium">
                Evidence {needsEvidence ? <span className="text-warn">· required above ₦5,000</span> : <span className="text-muted-foreground">· optional</span>}
              </div>
              <div className="text-[11px] text-muted-foreground">
                Attach the receipt or invoice. The posting engine refuses an entry above the threshold without a verified document.
              </div>
            </div>
            {evidenceId ? (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-favourable-bg px-2.5 py-1 text-xs font-medium text-favourable">
                <CheckCircle2 className="h-3.5 w-3.5" /> Attached & verified
              </span>
            ) : (
              <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-md border border-border bg-card px-2.5 py-1.5 text-xs font-medium hover:bg-muted">
                <Upload className="h-3.5 w-3.5" />
                {uploading ? "Uploading…" : "Attach document"}
                <input
                  type="file"
                  className="hidden"
                  accept="image/*,application/pdf"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) void handleFile(f);
                  }}
                />
              </label>
            )}
          </div>
        </div>

        {error ? <ErrorBox error={error} /> : null}

        <div className="flex items-center gap-2">
          <Button type="submit" disabled={create.isPending || uploading}>
            {create.isPending ? "Posting…" : "Post transaction"}
          </Button>
          <span className="text-[11px] text-muted-foreground">
            Posts a balanced double entry — {txnType === "Income" ? "Dr cash, Cr income" : "Dr expense, Cr cash"}.
          </span>
        </div>
      </form>
    </Panel>
  );
}
