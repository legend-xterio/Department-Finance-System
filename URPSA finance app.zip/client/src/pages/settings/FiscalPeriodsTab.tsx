import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { Loading, SectionHead, Panel } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import { fmtDate } from "@shared/finance";

/**
 * Fiscal periods. The posting engine already refuses entries dated inside a
 * closed period; this is the screen that lets the treasurer close one.
 */
export default function FiscalPeriodsTab() {
  const utils = trpc.useUtils();
  const org = trpc.org.get.useQuery();
  const periods = trpc.periods.list.useQuery();
  const createYear = trpc.periods.createYear.useMutation();
  const setPeriodStatus = trpc.periods.setStatus.useMutation();

  const periodStart = org.data ? String(org.data.periodStart).slice(0, 10) : "2026-10-01";
  const openCount = (periods.data ?? []).filter((p) => p.status === "open").length;

  return (
    <AppShell
      title="Fiscal periods"
      subtitle="Close a month once it is final — the posting engine refuses any entry dated inside it."
    >
      <Panel>
        <SectionHead
          right={
            <div className="flex items-center gap-2">
              <span className="label-cap">
                {openCount} open · {(periods.data?.length ?? 0) - openCount} closed
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  await createYear.mutateAsync({ fiscalYear: 2027, periodStart });
                  await utils.periods.list.invalidate();
                }}
                disabled={createYear.isPending}
              >
                Create the year
              </Button>
            </div>
          }
        >
          Periods
        </SectionHead>
        {periods.isLoading ? (
          <Loading />
        ) : (periods.data ?? []).length === 0 ? (
          <p className="py-3 text-sm text-muted-foreground">
            No periods yet. Create the administration year so entries can post.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Period</th>
                  <th>From</th>
                  <th>To</th>
                  <th>Status</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {(periods.data ?? []).map((p) => (
                  <tr key={p.id}>
                    <td className="tnum text-xs">
                      {p.fiscalYear}-{String(p.periodNo).padStart(2, "0")}
                    </td>
                    <td className="tnum text-xs">{fmtDate(p.startDate)}</td>
                    <td className="tnum text-xs">{fmtDate(p.endDate)}</td>
                    <td>
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${
                          p.status === "open"
                            ? "bg-favourable-bg text-favourable"
                            : p.status === "closed" || p.status === "locked"
                              ? "bg-adverse-bg text-adverse"
                              : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {p.status}
                      </span>
                    </td>
                    <td className="text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 px-2 text-[11px]"
                        disabled={setPeriodStatus.isPending}
                        onClick={async () => {
                          const closing = p.status === "open";
                          if (
                            !confirm(
                              closing
                                ? `Close ${p.fiscalYear}-${String(p.periodNo).padStart(2, "0")}?\n\nNo entry dated in this month will be accepted after this. You can reopen it later.`
                                : `Reopen ${p.fiscalYear}-${String(p.periodNo).padStart(2, "0")}?\n\nEntries dated in this month will be accepted again.`,
                            )
                          )
                            return;
                          await setPeriodStatus.mutateAsync({
                            id: p.id,
                            status: closing ? "closed" : "open",
                          });
                          await utils.periods.list.invalidate();
                        }}
                      >
                        {p.status === "open" ? "Close" : "Reopen"}
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </AppShell>
  );
}
