import { useEffect, useState } from "react";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { ErrorBox, SectionHead, Panel } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ngn, fmtDate, money } from "@shared/finance";
import { CheckCircle2, AlertCircle, Landmark } from "lucide-react";

/**
 * Opening balances. Saving posts a real, balanced opening journal entry dated at
 * the start of the session through the same posting engine as every other
 * entry — it is not a stored figure. Re-saving replaces the previous opening
 * rather than adding a second one.
 */
export default function OpeningBalancesTab() {
  const utils = trpc.useUtils();
  const org = trpc.org.get.useQuery();
  const opening = trpc.opening.get.useQuery();
  const saveOpening = trpc.opening.save.useMutation();

  const [ob, setOb] = useState({
    bankAmount: "",
    cashAmount: "",
    receivableAmount: "",
    payableAmount: "",
    fundAmount: "",
  });
  const [obSaved, setObSaved] = useState<string | null>(null);
  const [obError, setObError] = useState<unknown>(null);

  useEffect(() => {
    if (opening.data) {
      setOb({
        bankAmount: String(Number(opening.data.bankAmount) || ""),
        cashAmount: String(Number(opening.data.cashAmount) || ""),
        receivableAmount: String(Number(opening.data.receivableAmount) || ""),
        payableAmount: String(Number(opening.data.payableAmount) || ""),
        fundAmount: String(Number(opening.data.fundAmount) || ""),
      });
    }
  }, [opening.data]);

  const n = (v: string) => money(Number(v) || 0);
  const obAssets = money(n(ob.bankAmount) + n(ob.cashAmount) + n(ob.receivableAmount));
  const obClaims = money(n(ob.payableAmount) + n(ob.fundAmount));
  const obDiff = money(obAssets - obClaims);
  const obBalanced = obDiff === 0 && obAssets > 0;

  async function submitOpening(e: React.FormEvent) {
    e.preventDefault();
    setObError(null);
    setObSaved(null);
    try {
      const res = await saveOpening.mutateAsync({
        bankAmount: n(ob.bankAmount),
        cashAmount: n(ob.cashAmount),
        receivableAmount: n(ob.receivableAmount),
        payableAmount: n(ob.payableAmount),
        fundAmount: n(ob.fundAmount),
      });
      await Promise.all([
        utils.opening.get.invalidate(),
        utils.cash.list.invalidate(),
        utils.dashboard.summary.invalidate(),
      ]);
      setObSaved(res.entryNo);
    } catch (err) {
      setObError(err);
    }
  }

  const posted = opening.data?.entry ?? null;
  const periodStart = org.data ? String(org.data.periodStart).slice(0, 10) : "2026-10-01";

  return (
    <AppShell
      title="Opening balances"
      subtitle="The figures the ledger starts from — posted as a real journal entry."
    >
      <Panel>
        <SectionHead
          right={
            posted ? (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-favourable-bg px-2.5 py-1 text-[11px] font-semibold text-favourable">
                <CheckCircle2 className="h-3 w-3" /> Posted · {posted.entryNo} ·{" "}
                {ngn(posted.totalDebit)}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-[11px] font-semibold text-muted-foreground">
                <AlertCircle className="h-3 w-3" /> Not posted
              </span>
            )
          }
        >
          Opening balances
        </SectionHead>

        <p className="mb-4 max-w-3xl text-xs leading-relaxed text-muted-foreground">
          Saving posts a{" "}
          <strong className="font-medium text-foreground">real, balanced opening journal entry</strong>{" "}
          dated {fmtDate(periodStart)} — the first day of the session — through the same posting
          engine as every other entry. Debits go to the cash and receivable accounts; credits go to
          the payable and accumulated-fund accounts. Re-saving replaces the previous opening entry
          rather than adding a second one, so the book never carries two openings. No receipt is
          required: a brought-forward figure is not a payment.
        </p>

        <form onSubmit={submitOpening} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="obBank">Opening bank balance</Label>
              <Input
                id="obBank"
                type="number"
                step="0.01"
                min="0"
                value={ob.bankAmount}
                onChange={(e) => setOb({ ...ob, bankAmount: e.target.value })}
                placeholder="0.00"
              />
              <p className="text-[11px] text-muted-foreground">
                Money in the association's bank account on day one. Posts{" "}
                <span className="tnum">Dr 1012 Bank</span>.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="obCash">Opening cash balance</Label>
              <Input
                id="obCash"
                type="number"
                step="0.01"
                min="0"
                value={ob.cashAmount}
                onChange={(e) => setOb({ ...ob, cashAmount: e.target.value })}
                placeholder="0.00"
              />
              <p className="text-[11px] text-muted-foreground">
                Physical cash held by the treasurer. Posts{" "}
                <span className="tnum">Dr 1011 Cash on hand</span>.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="obRecv">Amounts owed to the association</Label>
              <Input
                id="obRecv"
                type="number"
                step="0.01"
                min="0"
                value={ob.receivableAmount}
                onChange={(e) => setOb({ ...ob, receivableAmount: e.target.value })}
                placeholder="0.00"
              />
              <p className="text-[11px] text-muted-foreground">
                Unpaid dues or pledges carried in from last session. Posts{" "}
                <span className="tnum">Dr 1013 Receivable</span>.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="obPay">Amounts owed by the association</Label>
              <Input
                id="obPay"
                type="number"
                step="0.01"
                min="0"
                value={ob.payableAmount}
                onChange={(e) => setOb({ ...ob, payableAmount: e.target.value })}
                placeholder="0.00"
              />
              <p className="text-[11px] text-muted-foreground">
                Bills and commitments carried in from last session. Posts{" "}
                <span className="tnum">Cr 2011 Liabilities</span>.
              </p>
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="obFund">Accumulated fund brought forward</Label>
              <Input
                id="obFund"
                type="number"
                step="0.01"
                min="0"
                value={ob.fundAmount}
                onChange={(e) => setOb({ ...ob, fundAmount: e.target.value })}
                placeholder="0.00"
              />
              <p className="text-[11px] text-muted-foreground">
                The balancing figure — what the association was worth at the start of the session.
                Posts <span className="tnum">Cr 3010 Accumulated fund</span>. It must equal{" "}
                <span className="tnum">bank + cash + receivable − payable</span>.
              </p>
            </div>
          </div>

          {/* Live balance check */}
          <div className="rounded-md border border-border bg-muted/40 px-3 py-2.5">
            <div className="flex flex-wrap items-center gap-x-6 gap-y-1 text-xs">
              <span className="text-muted-foreground">
                Debits (bank + cash + receivable){" "}
                <span className="tnum font-medium text-foreground">{ngn(obAssets)}</span>
              </span>
              <span className="text-muted-foreground">
                Credits (payable + fund){" "}
                <span className="tnum font-medium text-foreground">{ngn(obClaims)}</span>
              </span>
              <span className={`font-semibold ${obBalanced ? "text-favourable" : "text-adverse"}`}>
                {obBalanced
                  ? "Balanced — ready to post"
                  : obAssets === 0
                    ? "Enter the opening figures"
                    : `Out by ${ngn(Math.abs(obDiff))}`}
              </span>
            </div>
            {!obBalanced && obAssets > 0 ? (
              <p className="mt-1.5 text-[11px] text-muted-foreground">
                Set the accumulated fund to{" "}
                <span className="tnum font-medium text-foreground">
                  {ngn(money(obAssets - n(ob.payableAmount)))}
                </span>{" "}
                to balance the entry.
              </p>
            ) : null}
          </div>

          {obError ? <ErrorBox error={obError} /> : null}
          <div className="flex flex-wrap items-center gap-3">
            <Button type="submit" disabled={saveOpening.isPending || !obBalanced}>
              <Landmark className="mr-1.5 h-3.5 w-3.5" />
              {saveOpening.isPending
                ? "Posting…"
                : posted
                  ? "Replace the opening entry"
                  : "Post the opening entry"}
            </Button>
            {obSaved && (
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-favourable">
                <CheckCircle2 className="h-3.5 w-3.5" /> Posted as {obSaved}
              </span>
            )}
            {posted ? (
              <span className="text-[11px] text-muted-foreground">
                Currently posted: {posted.entryNo} dated {fmtDate(posted.entryDate)} for{" "}
                {ngn(posted.totalDebit)}.
              </span>
            ) : null}
          </div>
        </form>
      </Panel>
    </AppShell>
  );
}
