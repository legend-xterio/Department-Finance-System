import { useEffect, useState } from "react";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { Loading, ErrorBox, SectionHead, Panel } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { orgInitials } from "@shared/org-display";
import { BrandMark } from "@/components/BrandMark";
import { CheckCircle2 } from "lucide-react";

/**
 * Organisation identity. Everything here flows into the app header, the report
 * headers and the CSV/PDF exports, so it is the single source of that text.
 */
export default function OrganisationTab() {
  const utils = trpc.useUtils();
  const org = trpc.org.get.useQuery();
  const upsert = trpc.org.upsert.useMutation();

  const [form, setForm] = useState({
    legalName: "",
    shortName: "",
    institution: "",
    faculty: "",
    initials: "",
    contactEmail: "",
    contactPhone: "",
    baseCurrency: "NGN",
    periodStart: "2026-10-01",
    periodEnd: "2027-09-30",
    conversionDate: "2026-10-01",
    financialSecretary: "",
    treasurer: "",
    president: "",
    memberIdRule: "URPSA/YY/XXX",
    capitalisationThreshold: 50000,
    evidenceRequiredAbove: 5000,
  });
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<unknown>(null);

  useEffect(() => {
    if (org.data) {
      setForm({
        legalName: org.data.legalName,
        shortName: org.data.shortName ?? "",
        institution: org.data.institution ?? "",
        faculty: org.data.faculty ?? "",
        initials: org.data.initials ?? "",
        contactEmail: org.data.contactEmail ?? "",
        contactPhone: org.data.contactPhone ?? "",
        baseCurrency: org.data.baseCurrency ?? "NGN",
        periodStart: String(org.data.periodStart).slice(0, 10),
        periodEnd: String(org.data.periodEnd).slice(0, 10),
        conversionDate: String(org.data.conversionDate).slice(0, 10),
        financialSecretary: org.data.financialSecretary ?? "",
        treasurer: org.data.treasurer ?? "",
        president: org.data.president ?? "",
        memberIdRule: org.data.memberIdRule ?? "",
        capitalisationThreshold: Number(org.data.capitalisationThreshold),
        evidenceRequiredAbove: Number(org.data.evidenceRequiredAbove),
      });
    }
  }, [org.data]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaved(false);
    try {
      await upsert.mutateAsync({
        legalName: form.legalName,
        shortName: form.shortName || undefined,
        institution: form.institution || undefined,
        faculty: form.faculty || undefined,
        initials: form.initials || undefined,
        contactEmail: form.contactEmail || undefined,
        contactPhone: form.contactPhone || undefined,
        baseCurrency: form.baseCurrency || "NGN",
        periodStart: form.periodStart,
        periodEnd: form.periodEnd,
        conversionDate: form.conversionDate,
        financialSecretary: form.financialSecretary || undefined,
        treasurer: form.treasurer || undefined,
        president: form.president || undefined,
        memberIdRule: form.memberIdRule || undefined,
        capitalisationThreshold: form.capitalisationThreshold,
        evidenceRequiredAbove: form.evidenceRequiredAbove,
      });
      await utils.org.get.invalidate();
      setSaved(true);
    } catch (err) {
      setError(err);
    }
  }

  if (org.isLoading) {
    return (
      <AppShell title="Organisation details">
        <Loading />
      </AppShell>
    );
  }

  return (
    <AppShell
      title="Organisation details"
      subtitle="The association's identity and accounting configuration."
    >
      <Panel>
        <SectionHead right={<span className="label-cap">Flows to every report and export</span>}>
          Organisation
        </SectionHead>
        <form onSubmit={save} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="legalName">Association name</Label>
              <Input
                id="legalName"
                value={form.legalName}
                onChange={(e) => setForm({ ...form, legalName: e.target.value })}
                placeholder="Urban and Regional Planning Students' Association"
                required
              />
              <p className="text-[11px] text-muted-foreground">
                The full name printed at the top of every statement and CSV export.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="shortName">Short name / acronym</Label>
              <Input
                id="shortName"
                value={form.shortName}
                onChange={(e) => setForm({ ...form, shortName: e.target.value })}
                placeholder="URPSA"
              />
              <p className="text-[11px] text-muted-foreground">
                Appended to the name in reports and used in export filenames.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label>Association crest</Label>
              <div className="flex items-center gap-3 rounded-md border border-border bg-muted/30 p-3">
                <BrandMark org={org.data} size="xl" plate="always" />
                <div className="min-w-0 text-[11px] leading-relaxed text-muted-foreground">
                  <div className="font-medium text-foreground">Shown on the sidebar, the sign-in screen and every printed statement.</div>
                  <div className="mt-0.5">
                    The crest is a fixed image file, so it cannot be replaced from this page — ask
                    for a new one to be installed. The initials below are the fallback used if the
                    image ever fails to load.
                  </div>
                </div>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="initials">Logo mark (initials)</Label>
              <Input
                id="initials"
                value={form.initials}
                maxLength={4}
                onChange={(e) => setForm({ ...form, initials: e.target.value })}
                placeholder={orgInitials({ shortName: form.shortName, legalName: form.legalName })}
              />
              <p className="text-[11px] text-muted-foreground">
                Up to 4 characters used only if the crest image fails to load. Leave blank to
                derive it from the short name.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="institution">Institution</Label>
              <Input
                id="institution"
                value={form.institution}
                onChange={(e) => setForm({ ...form, institution: e.target.value })}
                placeholder="University of Lagos"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="faculty">Faculty / school</Label>
              <Input
                id="faculty"
                value={form.faculty}
                onChange={(e) => setForm({ ...form, faculty: e.target.value })}
                placeholder="Faculty of Environmental Sciences"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="contactEmail">Contact email</Label>
              <Input
                id="contactEmail"
                type="email"
                value={form.contactEmail}
                onChange={(e) => setForm({ ...form, contactEmail: e.target.value })}
                placeholder="treasurer@urpsa.org"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="contactPhone">Contact phone</Label>
              <Input
                id="contactPhone"
                value={form.contactPhone}
                onChange={(e) => setForm({ ...form, contactPhone: e.target.value })}
                placeholder="+234 800 000 0000"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="currency">Currency</Label>
              <Input
                id="currency"
                value={form.baseCurrency}
                onChange={(e) => setForm({ ...form, baseCurrency: e.target.value.toUpperCase() })}
                placeholder="NGN"
                maxLength={3}
              />
              <p className="text-[11px] text-muted-foreground">
                ISO code — appears in report column headers and export filenames.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="memberIdRule">Member ID rule</Label>
              <Input
                id="memberIdRule"
                value={form.memberIdRule}
                onChange={(e) => setForm({ ...form, memberIdRule: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="periodStart">Session starts</Label>
              <Input
                id="periodStart"
                type="date"
                value={form.periodStart}
                onChange={(e) => setForm({ ...form, periodStart: e.target.value })}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="periodEnd">Session ends</Label>
              <Input
                id="periodEnd"
                type="date"
                value={form.periodEnd}
                onChange={(e) => setForm({ ...form, periodEnd: e.target.value })}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="conversionDate">Conversion date</Label>
              <Input
                id="conversionDate"
                type="date"
                value={form.conversionDate}
                onChange={(e) => setForm({ ...form, conversionDate: e.target.value })}
                required
              />
              <p className="text-[11px] text-muted-foreground">Nothing may post before this date.</p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="evidence">Evidence required above (₦)</Label>
              <Input
                id="evidence"
                type="number"
                value={form.evidenceRequiredAbove}
                onChange={(e) => setForm({ ...form, evidenceRequiredAbove: Number(e.target.value) })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="fs">Financial Secretary</Label>
              <Input
                id="fs"
                value={form.financialSecretary}
                onChange={(e) => setForm({ ...form, financialSecretary: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="treasurer">Treasurer</Label>
              <Input
                id="treasurer"
                value={form.treasurer}
                onChange={(e) => setForm({ ...form, treasurer: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="president">President</Label>
              <Input
                id="president"
                value={form.president}
                onChange={(e) => setForm({ ...form, president: e.target.value })}
              />
            </div>
          </div>
          {error ? <ErrorBox error={error} /> : null}
          <div className="flex items-center gap-3">
            <Button type="submit" disabled={upsert.isPending}>
              {upsert.isPending ? "Saving…" : "Save settings"}
            </Button>
            {saved && (
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-favourable">
                <CheckCircle2 className="h-3.5 w-3.5" /> Saved
              </span>
            )}
          </div>
        </form>
      </Panel>
    </AppShell>
  );
}
