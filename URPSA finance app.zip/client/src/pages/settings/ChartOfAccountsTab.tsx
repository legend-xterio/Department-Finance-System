import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { Loading, SectionHead, Panel } from "@/components/finance-ui";
import { ngn } from "@shared/finance";

/** The chart of accounts — read-only reference; headings are not postable. */
export default function ChartOfAccountsTab() {
  const accounts = trpc.accounts.list.useQuery();
  const cash = trpc.cash.list.useQuery();

  if (accounts.isLoading) {
    return (
      <AppShell title="Chart of accounts">
        <Loading />
      </AppShell>
    );
  }

  return (
    <AppShell
      title="Chart of accounts"
      subtitle="The accounts every posting must use. Headings group; only postable accounts take entries."
    >
      <div className="space-y-4">
        <Panel>
          <SectionHead right={<span className="label-cap">{cash.data?.length ?? 0} accounts</span>}>
            Cash accounts
          </SectionHead>
          <div className="overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Name</th>
                  <th>Type</th>
                  <th className="num">Opening</th>
                </tr>
              </thead>
              <tbody>
                {(cash.data ?? []).map((c) => (
                  <tr key={c.id}>
                    <td className="tnum text-xs">{c.code}</td>
                    <td className="text-sm">{c.name}</td>
                    <td className="text-xs text-muted-foreground">{c.accountType}</td>
                    <td className="num text-sm">{ngn(c.openingBalance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>

        <Panel>
          <SectionHead right={<span className="label-cap">{accounts.data?.length ?? 0} accounts</span>}>
            All accounts
          </SectionHead>
          <div className="overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Name</th>
                  <th>Type</th>
                  <th>Category</th>
                  <th>Postable</th>
                </tr>
              </thead>
              <tbody>
                {(accounts.data ?? []).map((a) => (
                  <tr key={a.code} className={a.isPostable ? "" : "bg-muted/30"}>
                    <td className="tnum text-xs">{a.code}</td>
                    <td className={`text-sm ${a.isPostable ? "" : "font-semibold"}`}>{a.name}</td>
                    <td className="text-xs text-muted-foreground">{a.type}</td>
                    <td className="text-xs text-muted-foreground">{a.category ?? "—"}</td>
                    <td className="text-xs text-muted-foreground">
                      {a.isPostable ? "Yes" : "Heading"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </div>
    </AppShell>
  );
}
