import { useState } from "react";
import { Link, useParams } from "wouter";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { Loading, ErrorBox, SectionHead, Panel } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ngn, fmtDate } from "@shared/finance";
import { ArrowLeft, RotateCcw, FileText } from "lucide-react";

export default function TransactionDetail() {
  const { id } = useParams<{ id: string }>();
  const utils = trpc.useUtils();
  const q = trpc.transactions.get.useQuery({ id: id! });
  const reverse = trpc.transactions.reverse.useMutation();
  const [reason, setReason] = useState("");
  const [showReverse, setShowReverse] = useState(false);
  const [error, setError] = useState<unknown>(null);

  if (q.isLoading) {
    return (
      <AppShell title="Transaction">
        <Loading />
      </AppShell>
    );
  }
  if (q.error || !q.data) {
    return (
      <AppShell title="Transaction">
        <ErrorBox error={q.error ?? new Error("Not found")} />
      </AppShell>
    );
  }

  const { txn, lines, entry, evidence } = q.data;
  const isIncome = txn.txnType === "Income";

  async function doReverse() {
    setError(null);
    try {
      await reverse.mutateAsync({ id: txn.id, reason });
      await utils.transactions.get.invalidate({ id: txn.id });
      await utils.transactions.list.invalidate();
      await utils.dashboard.summary.invalidate();
      setShowReverse(false);
      setReason("");
    } catch (e) {
      setError(e);
    }
  }

  return (
    <AppShell
      title={txn.txnId}
      subtitle={`${txn.txnType} · ${fmtDate(txn.txnDate)}`}
      actions={
        <Link
          href="/transactions"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to the register
        </Link>
      }
    >
      <div className="space-y-5">
        <div className="grid gap-4 lg:grid-cols-3">
          <Panel className="lg:col-span-2">
            <SectionHead>Entry</SectionHead>
            <dl className="grid gap-3 sm:grid-cols-2">
              <Field label="Payee / description" value={txn.payee ?? "—"} />
              <Field label="Amount" value={ngn(txn.amount)} strong tone={isIncome ? "favourable" : "adverse"} />
              <Field label="Category" value={txn.categoryCode} />
              <Field label="Cash account" value={txn.cashAccountCode} />
              <Field label="Activity" value={txn.activityCode ?? "—"} />
              <Field label="Reference" value={txn.reference ?? "—"} />
              <Field label="Member" value={txn.memberId ?? "—"} />
              <Field label="Approval" value={`${txn.approvalStatus}${txn.approvedBy ? ` · ${txn.approvedBy}` : ""}`} />
              {txn.notes ? <Field label="Notes" value={txn.notes} /> : null}
            </dl>
          </Panel>

          <Panel>
            <SectionHead>Ledger entry</SectionHead>
            {entry ? (
              <dl className="space-y-2 text-sm">
                <Field label="Entry no." value={entry.entryNo} />
                <Field label="Status" value={entry.status} />
                <Field label="Source" value={entry.source} />
                <Field label="Prepared by" value={entry.preparedBy} />
                <Field label="Posted" value={entry.postedAt ? fmtDate(entry.postedAt) : "—"} />
              </dl>
            ) : (
              <p className="text-sm text-muted-foreground">No ledger entry linked.</p>
            )}
          </Panel>
        </div>

        <Panel>
          <SectionHead right={<span className="label-cap">Double entry</span>}>Journal lines</SectionHead>
          <div className="overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Account</th>
                  <th>Memo</th>
                  <th className="num">Debit</th>
                  <th className="num">Credit</th>
                </tr>
              </thead>
              <tbody>
                {lines.map((l) => (
                  <tr key={l.id}>
                    <td className="tnum text-xs text-muted-foreground">{l.lineNo}</td>
                    <td className="tnum text-sm">{l.accountCode}</td>
                    <td className="text-xs text-muted-foreground">{l.memo ?? "—"}</td>
                    <td className="num text-sm">{Number(l.debit) > 0 ? ngn(l.debit) : "—"}</td>
                    <td className="num text-sm">{Number(l.credit) > 0 ? ngn(l.credit) : "—"}</td>
                  </tr>
                ))}
                <tr className="total-row">
                  <td colSpan={3}>Total</td>
                  <td className="num">{ngn(lines.reduce((s, l) => s + Number(l.debit), 0))}</td>
                  <td className="num">{ngn(lines.reduce((s, l) => s + Number(l.credit), 0))}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </Panel>

        <Panel>
          <SectionHead right={<FileText className="h-4 w-4 text-muted-foreground" />}>Evidence</SectionHead>
          {evidence.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No document attached to this transaction.
            </p>
          ) : (
            <ul className="space-y-2">
              {evidence.map((e) => (
                <li key={e.id} className="flex items-center justify-between rounded-md border border-border px-3 py-2">
                  <div>
                    <div className="text-sm font-medium">{e.evidenceId} · {e.docType}</div>
                    <div className="text-[11px] text-muted-foreground">{e.description ?? "—"}</div>
                  </div>
                  <span
                    className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${
                      e.status === "verified" ? "bg-favourable-bg text-favourable" : "bg-warn-bg text-warn"
                    }`}
                  >
                    {e.status}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        {/* Reversal */}
        {entry && entry.status !== "reversed" && (
          <Panel>
            <SectionHead right={<RotateCcw className="h-4 w-4 text-muted-foreground" />}>Correct this entry</SectionHead>
            <p className="text-sm text-muted-foreground">
              A posted entry is never edited or deleted. A correction posts a mirrored reversal, so the
              audit trail keeps both.
            </p>
            {showReverse ? (
              <div className="mt-3 space-y-3">
                <div className="space-y-1.5">
                  <Label htmlFor="reason">Reason for the reversal</Label>
                  <Input id="reason" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. posted to the wrong category" />
                </div>
                {error ? <ErrorBox error={error} /> : null}
                <div className="flex gap-2">
                  <Button variant="destructive" size="sm" onClick={doReverse} disabled={!reason || reverse.isPending}>
                    {reverse.isPending ? "Reversing…" : "Post the reversal"}
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setShowReverse(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <Button variant="outline" size="sm" className="mt-3" onClick={() => setShowReverse(true)}>
                <RotateCcw className="mr-1.5 h-3.5 w-3.5" /> Reverse this entry
              </Button>
            )}
          </Panel>
        )}
      </div>
    </AppShell>
  );
}

function Field({
  label,
  value,
  strong,
  tone,
}: {
  label: string;
  value: string;
  strong?: boolean;
  tone?: "favourable" | "adverse";
}) {
  return (
    <div>
      <dt className="label-cap">{label}</dt>
      <dd
        className={`tnum mt-0.5 text-sm ${strong ? "font-semibold" : ""} ${
          tone === "favourable" ? "text-favourable" : tone === "adverse" ? "text-adverse" : ""
        }`}
      >
        {value}
      </dd>
    </div>
  );
}
