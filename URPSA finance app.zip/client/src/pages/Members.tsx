import { useState } from "react";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { EmptyState, Loading, ErrorBox, SectionHead, Panel } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Modal,
  Field,
  Select,
  TextInput,
  MoneyInput,
  parseMoney,
  SubmitBtn,
  RowAction,
  ConfirmDialog,
  FormError,
  useToast,
} from "@/components/form-ui";
import { ngn, pct, fmtDate } from "@shared/finance";
import { Users, Search, Plus, Pencil, Trash2, Archive, ArchiveRestore } from "lucide-react";

type Member = {
  id: string;
  memberId: string;
  fullName: string;
  admissionYear: string | null;
  matricNumber: string | null;
  level: string | null;
  phone: string | null;
  email: string | null;
  status: string;
  archivedAt: string | null;
};

export default function Members() {
  const [search, setSearch] = useState("");
  const [showArchived, setShowArchived] = useState(false);
  const members = trpc.members.list.useQuery({
    search: search || undefined,
    includeArchived: showArchived,
  });
  const collection = trpc.dues.collection.useQuery();
  const { toast, toastNode } = useToast();
  const utils = trpc.useUtils();

  const [editing, setEditing] = useState<Partial<Member> | null>(null);
  const [deleting, setDeleting] = useState<Member | null>(null);
  const [duesRow, setDuesRow] = useState<(typeof rows)[number] | null>(null);

  const create = trpc.members.create.useMutation({
    onSuccess: () => {
      utils.members.list.invalidate();
      utils.dues.collection.invalidate();
      setEditing(null);
      toast("Member added");
    },
  });
  const update = trpc.members.update.useMutation({
    onSuccess: () => {
      utils.members.list.invalidate();
      utils.dues.collection.invalidate();
      setEditing(null);
      toast("Member updated");
    },
  });
  const archive = trpc.members.archive.useMutation({
    onSuccess: (_d, v) => {
      utils.members.list.invalidate();
      toast(v.archived ? "Member archived" : "Member restored");
    },
  });
  const remove = trpc.members.remove.useMutation({
    onSuccess: () => {
      utils.members.list.invalidate();
      utils.dues.collection.invalidate();
      setDeleting(null);
      toast("Member deleted");
    },
  });
  const saveDues = trpc.dues.update.useMutation({
    onSuccess: () => {
      utils.dues.collection.invalidate();
      setDuesRow(null);
      toast("Dues updated");
    },
  });

  const rows = collection.data ?? [];
  const totalAssessed = rows.reduce((s, r) => s + r.assessed, 0);
  const totalCollected = rows.reduce((s, r) => s + r.collected, 0);
  const memberRows = (members.data ?? []) as Member[];

  return (
    <AppShell
      title="Members & dues"
      subtitle="The register of members and what each has paid against their dues. New IDs follow URPSA/YY/XXX."
      actions={
        <Button size="sm" onClick={() => setEditing({ status: "active" })}>
          <Plus className="mr-1.5 h-3.5 w-3.5" /> Add member
        </Button>
      }
    >
      {toastNode}
      <div className="space-y-5">
        <div className="grid gap-3 sm:grid-cols-3">
          <Panel>
            <div className="label-cap">Members on the register</div>
            <div className="tnum mt-1.5 text-xl font-semibold">{memberRows.length}</div>
          </Panel>
          <Panel>
            <div className="label-cap">Dues assessed</div>
            <div className="tnum mt-1.5 text-xl font-semibold">{ngn(totalAssessed)}</div>
          </Panel>
          <Panel>
            <div className="label-cap">Collected</div>
            <div className="tnum mt-1.5 text-xl font-semibold text-favourable">{ngn(totalCollected)}</div>
            <div className="mt-1 text-[11px] text-muted-foreground">
              {pct(totalCollected, totalAssessed)}% of dues
            </div>
          </Panel>
        </div>

        <Panel>
          <SectionHead
            right={
              <div className="flex items-center gap-2">
                <label className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={showArchived}
                    onChange={(e) => setShowArchived(e.target.checked)}
                    className="h-3 w-3"
                  />
                  Show archived
                </label>
                <div className="relative w-56">
                  <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search name or member ID…"
                    className="pl-8"
                  />
                </div>
              </div>
            }
          >
            Dues collection
          </SectionHead>
          {collection.isLoading ? (
            <Loading />
          ) : collection.error ? (
            <ErrorBox error={collection.error} />
          ) : rows.length === 0 ? (
            <EmptyState
              icon={<Users className="h-8 w-8" />}
              title="No dues recorded"
              body="Add members and their dues obligations, and this page tracks what each has actually paid against the ledger."
              action={
                <Button size="sm" onClick={() => setEditing({ status: "active" })}>
                  <Plus className="mr-1.5 h-3.5 w-3.5" /> Add the first member
                </Button>
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>Ref</th>
                    <th>Member</th>
                    <th>Member ID</th>
                    <th>Dues type</th>
                    <th>Due</th>
                    <th className="num">Assessed</th>
                    <th className="num">Collected</th>
                    <th className="num">Outstanding</th>
                    <th className="no-print" />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.duesRef}>
                      <td className="tnum text-xs text-muted-foreground">{r.duesRef}</td>
                      <td className="text-sm">{r.fullName ?? "—"}</td>
                      <td className="tnum text-xs text-muted-foreground">{r.memberId}</td>
                      <td className="text-xs text-muted-foreground">{r.duesType}</td>
                      <td className="tnum text-xs">{fmtDate(r.dueDate)}</td>
                      <td className="num text-sm">{ngn(r.assessed)}</td>
                      <td className="num text-sm text-favourable">{ngn(r.collected)}</td>
                      <td className={`num text-sm ${r.outstanding > 0 ? "text-adverse" : ""}`}>
                        {ngn(r.outstanding)}
                      </td>
                      <td className="no-print">
                        <RowAction onClick={() => setDuesRow(r)} title="Edit dues">
                          <Pencil className="h-3 w-3" /> Dues
                        </RowAction>
                      </td>
                    </tr>
                  ))}
                  <tr className="total-row">
                    <td colSpan={5}>Total</td>
                    <td className="num">{ngn(totalAssessed)}</td>
                    <td className="num">{ngn(totalCollected)}</td>
                    <td className="num">{ngn(totalAssessed - totalCollected)}</td>
                    <td />
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </Panel>

        <Panel>
          <SectionHead
            right={<span className="label-cap">IDs follow URPSA/YY/XXX</span>}
          >
            Member register
          </SectionHead>
          {members.isLoading ? (
            <Loading />
          ) : members.error ? (
            <ErrorBox error={members.error} />
          ) : memberRows.length === 0 ? (
            <p className="py-4 text-sm text-muted-foreground">
              {search ? "No members match that search." : "No members on the register yet."}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>Member ID</th>
                    <th>Name</th>
                    <th>Level</th>
                    <th>Matric no.</th>
                    <th>Admitted</th>
                    <th>Contact</th>
                    <th>Status</th>
                    <th className="no-print" />
                  </tr>
                </thead>
                <tbody>
                  {memberRows.map((m) => (
                    <tr key={m.id} className={m.archivedAt ? "opacity-60" : ""}>
                      <td className="tnum text-xs">{m.memberId}</td>
                      <td className="text-sm">{m.fullName}</td>
                      <td className="tnum text-xs text-muted-foreground">{m.level ?? "—"}</td>
                      <td className="tnum text-xs text-muted-foreground">{m.matricNumber ?? "—"}</td>
                      <td className="tnum text-xs text-muted-foreground">{m.admissionYear ?? "—"}</td>
                      <td className="text-xs text-muted-foreground">{m.phone ?? m.email ?? "—"}</td>
                      <td>
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${
                            m.archivedAt
                              ? "bg-muted text-muted-foreground"
                              : "bg-secondary text-secondary-foreground"
                          }`}
                        >
                          {m.archivedAt ? "archived" : m.status}
                        </span>
                      </td>
                      <td className="no-print whitespace-nowrap">
                        <RowAction onClick={() => setEditing(m)} title="Edit member">
                          <Pencil className="h-3 w-3" />
                        </RowAction>
                        <RowAction
                          onClick={() => archive.mutate({ id: m.id, archived: !m.archivedAt })}
                          title={m.archivedAt ? "Restore member" : "Archive member"}
                        >
                          {m.archivedAt ? (
                            <ArchiveRestore className="h-3 w-3" />
                          ) : (
                            <Archive className="h-3 w-3" />
                          )}
                        </RowAction>
                        <RowAction onClick={() => setDeleting(m)} tone="danger" title="Delete member">
                          <Trash2 className="h-3 w-3" />
                        </RowAction>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>

      {/* ── Member editor ─────────────────────────────────────────────────── */}
      <Modal
        open={!!editing}
        onClose={() => setEditing(null)}
        title={editing?.id ? `Edit ${editing.memberId}` : "Add member"}
        description={
          editing?.id
            ? "The member ID is fixed once issued — every transaction and dues record points at it."
            : "The next free URPSA/YY/XXX is allocated from the admission year."
        }
        width="lg"
        footer={
          <>
            <Button variant="outline" size="sm" onClick={() => setEditing(null)}>
              Cancel
            </Button>
            <SubmitBtn
              label={editing?.id ? "Save changes" : "Add member"}
              busy={create.isPending || update.isPending}
              disabled={!editing?.fullName?.trim()}
              onClick={() => {
                if (!editing) return;
                if (editing.id) {
                  update.mutate({
                    id: editing.id,
                    fullName: editing.fullName!.trim(),
                    memberId: editing.memberId!,
                    admissionYear: editing.admissionYear || undefined,
                    matricNumber: editing.matricNumber || undefined,
                    level: editing.level || undefined,
                    phone: editing.phone || undefined,
                    email: editing.email || undefined,
                    status: (editing.status ?? "active") as never,
                  });
                } else {
                  create.mutate({
                    fullName: editing.fullName!.trim(),
                    admissionYear: editing.admissionYear || undefined,
                    matricNumber: editing.matricNumber || undefined,
                    level: editing.level || undefined,
                    phone: editing.phone || undefined,
                    email: editing.email || undefined,
                    status: (editing.status ?? "active") as never,
                    memberId: editing.memberId || undefined,
                  });
                }
              }}
            />
          </>
        }
      >
        {editing && (
          <div className="space-y-3">
            <FormError error={create.error ?? update.error} />
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Full name" required>
                <TextInput
                  value={editing.fullName ?? ""}
                  onChange={(v) => setEditing({ ...editing, fullName: v })}
                  placeholder="e.g. Adebayo Ogunlesi"
                  autoFocus
                />
              </Field>
              <Field
                label="Member ID"
                hint={editing.id ? "Fixed once issued." : "Leave blank to take the next free ID."}
              >
                <TextInput
                  value={editing.memberId ?? ""}
                  onChange={(v) => setEditing({ ...editing, memberId: v.toUpperCase() })}
                  placeholder="URPSA/26/013"
                  disabled={!!editing.id}
                />
              </Field>
              <Field label="Admission year">
                <TextInput
                  value={editing.admissionYear ?? ""}
                  onChange={(v) => setEditing({ ...editing, admissionYear: v })}
                  placeholder="2026"
                />
              </Field>
              <Field label="Level">
                <TextInput
                  value={editing.level ?? ""}
                  onChange={(v) => setEditing({ ...editing, level: v })}
                  placeholder="e.g. 300"
                />
              </Field>
              <Field label="Matric number">
                <TextInput
                  value={editing.matricNumber ?? ""}
                  onChange={(v) => setEditing({ ...editing, matricNumber: v })}
                />
              </Field>
              <Field label="Status">
                <Select
                  value={editing.status ?? "active"}
                  onChange={(v) => setEditing({ ...editing, status: v })}
                  options={[
                    { value: "active", label: "Active" },
                    { value: "inactive", label: "Inactive" },
                    { value: "graduated", label: "Graduated" },
                  ]}
                />
              </Field>
              <Field label="Phone">
                <TextInput
                  value={editing.phone ?? ""}
                  onChange={(v) => setEditing({ ...editing, phone: v })}
                />
              </Field>
              <Field label="Email">
                <TextInput
                  value={editing.email ?? ""}
                  onChange={(v) => setEditing({ ...editing, email: v })}
                />
              </Field>
            </div>
          </div>
        )}
      </Modal>

      {/* ── Dues editor ───────────────────────────────────────────────────── */}
      {duesRow && (
        <DuesModal
          row={duesRow}
          onClose={() => setDuesRow(null)}
          busy={saveDues.isPending}
          error={saveDues.error}
          onSave={(v) => saveDues.mutate({ id: duesRow.id!, ...v })}
        />
      )}

      <ConfirmDialog
        open={!!deleting}
        title="Delete this member?"
        body={`${deleting?.fullName ?? ""} (${deleting?.memberId ?? ""}) will be removed. If they appear on any transaction or dues record the app will refuse — archive them instead so the history stays intact.`}
        busy={remove.isPending}
        onClose={() => setDeleting(null)}
        onConfirm={() => deleting && remove.mutate({ id: deleting.id })}
      />
      {remove.error && (
        <div className="mt-3">
          <ErrorBox error={remove.error} />
        </div>
      )}
    </AppShell>
  );
}

function DuesModal({
  row,
  onClose,
  onSave,
  busy,
  error,
}: {
  row: { id?: string; duesRef: string; duesType: string; dueDate: string | null; assessed: number };
  onClose: () => void;
  onSave: (v: { duesType: string; dueDate?: string; amountAssessed: number }) => void;
  busy: boolean;
  error: unknown;
}) {
  const [type, setType] = useState(row.duesType);
  const [due, setDue] = useState(row.dueDate ?? "");
  const [amount, setAmount] = useState(String(row.assessed));

  return (
    <Modal
      open
      onClose={onClose}
      title={`Edit dues — ${row.duesRef}`}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <SubmitBtn
            label="Save dues"
            busy={busy}
            onClick={() =>
              onSave({ duesType: type, dueDate: due || undefined, amountAssessed: parseMoney(amount) })
            }
          />
        </>
      }
    >
      <div className="space-y-3">
        <FormError error={error} />
        <Field label="Dues type" required>
          <TextInput value={type} onChange={setType} />
        </Field>
        <Field label="Amount assessed">
          <MoneyInput value={amount} onChange={setAmount} />
        </Field>
        <Field label="Due date">
          <TextInput type="date" value={due} onChange={setDue} />
        </Field>
        <p className="rounded-md bg-muted px-3 py-2 text-[11px] text-muted-foreground">
          Changing the assessment does not touch the ledger — collections are read from the
          transactions actually posted.
        </p>
      </div>
    </Modal>
  );
}
