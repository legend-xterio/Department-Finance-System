import { useEffect, useState } from "react";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { Loading, ErrorBox, Panel, ControlStrip } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import { ngn, ngnSigned, fmtDate, downloadCsv, today } from "@shared/finance";
import { orgTitle, orgSubtitle, orgSession, orgContact } from "@shared/org-display";
import { BrandMark, PrintMark } from "@/components/BrandMark";
import {
  incomeExpenditureCsv,
  financialPositionCsv,
  cashFlowCsv,
  trialBalanceCsv,
  controlChecksCsv,
  reportFilename,
} from "@shared/report-csv";
import { Printer, Download, FileBarChart2 } from "lucide-react";

type ReportKey = "ie" | "position" | "cashflow" | "trial" | "controls";

const REPORTS: { key: ReportKey; label: string; blurb: string }[] = [
  { key: "ie", label: "Income & Expenditure", blurb: "What came in, what went out, and the surplus for the period." },
  { key: "position", label: "Financial Position", blurb: "Assets, liabilities and funds at a point in time." },
  { key: "cashflow", label: "Cash Flows", blurb: "Operating, investing and financing movement in cash." },
  { key: "trial", label: "Trial Balance", blurb: "Every account's debits and credits — must balance to zero." },
  { key: "controls", label: "Control Checks", blurb: "The ledger identities, computed rather than typed." },
];

const FILENAME: Record<ReportKey, string> = {
  ie: "income-expenditure",
  position: "financial-position",
  cashflow: "cash-flow",
  trial: "trial-balance",
  controls: "control-checks",
};

const KEYS: ReportKey[] = ["ie", "position", "cashflow", "trial", "controls"];

/** The sidebar links straight to a statement via ?r=, so the URL is the source
 *  of truth for which one is open — a deep link and a click behave the same. */
function keyFromUrl(): ReportKey {
  const r = new URLSearchParams(window.location.search).get("r");
  return KEYS.includes(r as ReportKey) ? (r as ReportKey) : "ie";
}

export default function Reports() {
  const [active, setActive] = useState<ReportKey>(keyFromUrl);
  const to = today();

  // Keep the picker in step with the address bar (back/forward, sidebar links).
  useEffect(() => {
    const sync = () => setActive(keyFromUrl());
    window.addEventListener("popstate", sync);
    sync();
    return () => window.removeEventListener("popstate", sync);
  }, []);

  function pick(key: ReportKey) {
    setActive(key);
    const url = new URL(window.location.href);
    url.searchParams.set("r", key);
    window.history.replaceState(null, "", url.toString());
  }
  // Identity comes from Settings, so a renamed association or a new session
  // flows into the on-screen statement, the print/PDF output and the CSV.
  const org = trpc.org.get.useQuery();

  const ie = trpc.reports.incomeAndExpenditure.useQuery({ to }, { enabled: active === "ie" });
  const pos = trpc.reports.financialPosition.useQuery({ to }, { enabled: active === "position" });
  const cf = trpc.reports.cashFlow.useQuery({ to }, { enabled: active === "cashflow" });
  const tb = trpc.reports.trialBalance.useQuery({ to }, { enabled: active === "trial" });
  const cc = trpc.reports.controlChecks.useQuery({ to }, { enabled: active === "controls" });

  const meta = REPORTS.find((r) => r.key === active)!;

  /**
   * One export path for every statement. Each report's CSV comes from a pure
   * builder in shared/report-csv.ts, so what downloads is exactly what is shown
   * — and the builders are unit-tested rather than clicked.
   */
  function exportCsv() {
    // A CSV cannot carry an image, so the title block names the department mark
    // and gives its absolute URL instead of pretending to embed it.
    const markUrl = `${window.location.origin}/brand/urpsa-crest-256.png`;
    let csv: string | null = null;
    if (active === "ie" && ie.data) csv = incomeExpenditureCsv(ie.data, to, org.data, markUrl);
    else if (active === "position" && pos.data) csv = financialPositionCsv(pos.data, to, org.data, markUrl);
    else if (active === "cashflow" && cf.data) csv = cashFlowCsv(cf.data, to, org.data, markUrl);
    else if (active === "trial" && tb.data) csv = trialBalanceCsv(tb.data, to, org.data, markUrl);
    else if (active === "controls" && cc.data) csv = controlChecksCsv(cc.data, to, org.data, markUrl);

    if (!csv) return;
    downloadCsv(reportFilename(FILENAME[active], to, org.data), csv);
  }

  const loading =
    (active === "ie" && ie.isLoading) ||
    (active === "position" && pos.isLoading) ||
    (active === "cashflow" && cf.isLoading) ||
    (active === "trial" && tb.isLoading) ||
    (active === "controls" && cc.isLoading);

  const error =
    (active === "ie" ? ie.error : null) ??
    (active === "position" ? pos.error : null) ??
    (active === "cashflow" ? cf.error : null) ??
    (active === "trial" ? tb.error : null) ??
    (active === "controls" ? cc.error : null);

  /**
   * Is there anything in the ledger at all? A statement of all zeros is a valid
   * statement, but on a brand-new book it reads like a broken page. This drives
   * one explanatory line above the table — never a replacement for it, because
   * the structure and the control checks are the point.
   */
  const isEmpty =
    (active === "ie" && !!ie.data && ie.data.income.length === 0 && ie.data.expenditure.length === 0) ||
    (active === "position" &&
      !!pos.data &&
      pos.data.assets.length === 0 &&
      pos.data.liabilities.length === 0 &&
      pos.data.funds.length === 0) ||
    (active === "cashflow" &&
      !!cf.data &&
      cf.data.operating === 0 &&
      cf.data.investing === 0 &&
      cf.data.financing === 0 &&
      cf.data.closingCash === 0) ||
    (active === "trial" && !!tb.data && tb.data.rows.length === 0);

  return (
    <AppShell
      title="Reports"
      subtitle="Every figure derives from the journal — nothing is a stored balance."
      actions={
        <div className="no-print flex gap-2">
          <Button variant="outline" size="sm" onClick={exportCsv} disabled={loading || !meta}>
            <Download className="mr-1.5 h-3.5 w-3.5" /> CSV
          </Button>
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer className="mr-1.5 h-3.5 w-3.5" /> Print / PDF
          </Button>
        </div>
      }
    >
      <div className="space-y-5">
        {/* Report picker */}
        <div className="no-print grid gap-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {REPORTS.map((r) => (
            <button
              key={r.key}
              onClick={() => pick(r.key)}
              className={`rounded-lg border p-3 text-left transition-colors ${
                active === r.key
                  ? "border-primary bg-secondary"
                  : "border-border bg-card hover:bg-muted/50"
              }`}
            >
              <div className="text-sm font-medium leading-snug">{r.label}</div>
              <div className="mt-0.5 text-[11px] leading-snug text-muted-foreground">{r.blurb}</div>
            </button>
          ))}
        </div>

        {/* The statement */}
        <Panel>
          <div className="mb-4 border-b border-border pb-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex min-w-0 items-start gap-3">
                {/* On paper the crest sits on the sheet itself, so no plate: its
                    white disc is the paper. On screen the statement card is
                    white too, so the same bare treatment is correct here.
                    A separate 900px copy is used for print — the on-screen
                    512px file would smear at 15mm across a laser printer. */}
                <BrandMark org={org.data} size="lg" plate="never" className="no-print" />
                <div className="hidden print:block">
                  <PrintMark org={org.data} mm={15} />
                </div>
                <div className="min-w-0">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.09em] text-muted-foreground">
                    {orgTitle(org.data)}
                  </div>
                  <h2 className="mt-1 text-base font-semibold tracking-tight">{meta.label}</h2>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {[orgSubtitle(org.data), orgSession(org.data), `as at ${fmtDate(to)}`]
                      .filter(Boolean)
                      .join(" · ")}
                  </p>
                </div>
              </div>
              <FileBarChart2 className="no-print h-4 w-4 shrink-0 text-muted-foreground" />
            </div>
          </div>

          {!loading && !error && isEmpty ? (
            <div className="mb-4 rounded-md border border-border bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
              <strong className="font-medium text-foreground">No postings yet.</strong> The ledger is
              empty, so every line below is zero. Record a transaction and this statement fills in
              from the journal — the structure and the control checks stay the same.
            </div>
          ) : null}

          {loading ? (
            <Loading label="Computing from the journal…" />
          ) : error ? (
            <ErrorBox error={error} />
          ) : active === "ie" && ie.data ? (
            <IEView d={ie.data} />
          ) : active === "position" && pos.data ? (
            <PositionView d={pos.data} />
          ) : active === "cashflow" && cf.data ? (
            <CashFlowView d={cf.data} />
          ) : active === "trial" && tb.data ? (
            <TrialView d={tb.data} />
          ) : active === "controls" && cc.data ? (
            <ControlStrip
              checks={cc.data.map((c) => ({ key: c.name, label: c.name, ok: c.pass, detail: c.detail }))}
            />
          ) : null}

          {/* Print/PDF footer — the statement must identify its own books once
              it leaves the app. Hidden on screen, printed at the end. */}
          <div className="mt-6 hidden border-t border-border pt-2 text-[10px] text-muted-foreground print:block">
            {[orgTitle(org.data), orgSubtitle(org.data), orgContact(org.data)]
              .filter(Boolean)
              .join(" · ")}
            {" — prepared "}
            {fmtDate(to)}
          </div>
        </Panel>
      </div>
    </AppShell>
  );
}

function IEView({ d }: { d: { income: { code: string; name: string; amount: number }[]; expenditure: { code: string; name: string; amount: number }[]; totalIncome: number; totalExpenditure: number; surplus: number } }) {
  return (
    <table className="ledger">
      <tbody>
        <tr className="section-row"><td colSpan={2}>Income</td></tr>
        {d.income.map((r) => (
          <tr key={r.code}>
            <td className="text-sm"><span className="tnum mr-2 text-xs text-muted-foreground">{r.code}</span>{r.name}</td>
            <td className="num text-sm">{ngn(r.amount)}</td>
          </tr>
        ))}
        <tr className="total-row"><td>Total income</td><td className="num">{ngn(d.totalIncome)}</td></tr>
        <tr className="section-row"><td colSpan={2}>Expenditure</td></tr>
        {d.expenditure.map((r) => (
          <tr key={r.code}>
            <td className="text-sm"><span className="tnum mr-2 text-xs text-muted-foreground">{r.code}</span>{r.name}</td>
            <td className="num text-sm">{ngn(r.amount)}</td>
          </tr>
        ))}
        <tr className="total-row"><td>Total expenditure</td><td className="num">{ngn(d.totalExpenditure)}</td></tr>
        <tr className="total-row">
          <td className="text-base">Net surplus for the period</td>
          <td className={`num text-base ${d.surplus >= 0 ? "text-favourable" : "text-adverse"}`}>{ngnSigned(d.surplus)}</td>
        </tr>
      </tbody>
    </table>
  );
}

function PositionView({ d }: { d: { assets: { code: string; name: string; amount: number }[]; liabilities: { code: string; name: string; amount: number }[]; funds: { code: string; name: string; amount: number }[]; totalAssets: number; totalLiabilities: number; totalFunds: number; currentSurplus: number; difference: number } }) {
  return (
    <table className="ledger">
      <tbody>
        <tr className="section-row"><td colSpan={2}>Assets</td></tr>
        {d.assets.map((r) => (
          <tr key={r.code}>
            <td className="text-sm"><span className="tnum mr-2 text-xs text-muted-foreground">{r.code}</span>{r.name}</td>
            <td className="num text-sm">{ngn(r.amount)}</td>
          </tr>
        ))}
        <tr className="total-row"><td>Total assets</td><td className="num">{ngn(d.totalAssets)}</td></tr>

        <tr className="section-row"><td colSpan={2}>Liabilities</td></tr>
        {d.liabilities.length === 0 ? (
          <tr><td className="text-sm text-muted-foreground">None</td><td className="num text-sm">—</td></tr>
        ) : (
          d.liabilities.map((r) => (
            <tr key={r.code}>
              <td className="text-sm"><span className="tnum mr-2 text-xs text-muted-foreground">{r.code}</span>{r.name}</td>
              <td className="num text-sm">{ngn(r.amount)}</td>
            </tr>
          ))
        )}
        <tr className="total-row"><td>Total liabilities</td><td className="num">{ngn(d.totalLiabilities)}</td></tr>

        <tr className="section-row"><td colSpan={2}>Funds</td></tr>
        {d.funds.map((r) => (
          <tr key={r.code}>
            <td className="text-sm"><span className="tnum mr-2 text-xs text-muted-foreground">{r.code}</span>{r.name}</td>
            <td className="num text-sm">{ngn(r.amount)}</td>
          </tr>
        ))}
        <tr>
          <td className="text-sm">Period result (income less expenditure)</td>
          <td className="num text-sm">{ngnSigned(d.currentSurplus)}</td>
        </tr>
        <tr className="total-row"><td>Total funds</td><td className="num">{ngn(d.totalFunds + d.currentSurplus)}</td></tr>

        <tr className="total-row">
          <td className="text-base">Total liabilities and funds</td>
          <td className="num text-base">{ngn(d.totalLiabilities + d.totalFunds + d.currentSurplus)}</td>
        </tr>
        <tr>
          <td className="text-xs text-muted-foreground">Difference (must be zero)</td>
          <td className={`num text-xs ${d.difference === 0 ? "text-favourable" : "text-adverse"}`}>{ngn(d.difference)}</td>
        </tr>
      </tbody>
    </table>
  );
}

function CashFlowView({ d }: { d: { operating: number; investing: number; financing: number; netMovement: number; openingCash: number; closingCash: number; difference: number } }) {
  return (
    <table className="ledger">
      <tbody>
        <tr className="section-row"><td colSpan={2}>Cash flows for the period</td></tr>
        <tr><td className="text-sm">Net cash from operating activities</td><td className="num text-sm">{ngnSigned(d.operating)}</td></tr>
        <tr><td className="text-sm">Net cash from investing activities</td><td className="num text-sm">{ngnSigned(d.investing)}</td></tr>
        <tr><td className="text-sm">Net cash from financing activities</td><td className="num text-sm">{ngnSigned(d.financing)}</td></tr>
        <tr className="total-row"><td>Net movement in cash</td><td className="num">{ngnSigned(d.netMovement)}</td></tr>
        <tr><td className="text-sm">Cash at the start of the period</td><td className="num text-sm">{ngn(d.openingCash)}</td></tr>
        <tr className="total-row"><td className="text-base">Cash at the end of the period</td><td className="num text-base">{ngn(d.closingCash)}</td></tr>
        <tr>
          <td className="text-xs text-muted-foreground">Control difference (must be zero)</td>
          <td className={`num text-xs ${d.difference === 0 ? "text-favourable" : "text-adverse"}`}>{ngn(d.difference)}</td>
        </tr>
      </tbody>
    </table>
  );
}

function TrialView({ d }: { d: { rows: { code: string; name: string; debit: number; credit: number }[]; totalDebit: number; totalCredit: number; difference: number } }) {
  return (
    <table className="ledger">
      <thead>
        <tr>
          <th>Code</th>
          <th>Account</th>
          <th className="num">Debit</th>
          <th className="num">Credit</th>
        </tr>
      </thead>
      <tbody>
        {d.rows.map((r) => (
          <tr key={r.code}>
            <td className="tnum text-xs text-muted-foreground">{r.code}</td>
            <td className="text-sm">{r.name}</td>
            <td className="num text-sm">{r.debit > 0 ? ngn(r.debit) : "—"}</td>
            <td className="num text-sm">{r.credit > 0 ? ngn(r.credit) : "—"}</td>
          </tr>
        ))}
        <tr className="total-row">
          <td colSpan={2}>Total</td>
          <td className="num">{ngn(d.totalDebit)}</td>
          <td className="num">{ngn(d.totalCredit)}</td>
        </tr>
        <tr>
          <td colSpan={2} className="text-xs text-muted-foreground">Difference (must be zero)</td>
          <td colSpan={2} className={`num text-xs ${d.difference === 0 ? "text-favourable" : "text-adverse"}`}>{ngn(d.difference)}</td>
        </tr>
      </tbody>
    </table>
  );
}
