import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { EmptyState, Loading, ErrorBox, SectionHead, Panel, FundChip } from "@/components/finance-ui";
import { useEvidenceUpload } from "@/components/use-evidence";
import { Button } from "@/components/ui/button";
import {
  Modal,
  Field,
  Select,
  TextInput,
  TextArea,
  MoneyInput,
  parseMoney,
  SubmitBtn,
  RowAction,
  ConfirmDialog,
  FormError,
  EvidenceField,
  useToast,
} from "@/components/form-ui";
import { ngn, pct } from "@shared/finance";
import { roleFlags } from "@/lib/roles";
import { Handshake, Plus, Pencil, Trash2, BadgeDollarSign } from "lucide-react";

const STAGES = [
  { key: "approached", label: "Approached", weight: 0.1 },
  { key: "proposal_sent", label: "Proposal sent", weight: 0.25 },
  { key: "negotiating", label: "Negotiating", weight: 0.5 },
  { key: "contract_signed", label: "Contract signed", weight: 0.9 },
  { key: "pledged", label: "Pledged", weight: 0.75 },
  { key: "received", label: "Received", weight: 1 },
  { key: "declined", label: "Declined", weight: 0 },
];

type Pledge = {
  id: string;
  sponsorshipId: string;
  sponsor: string;
  purpose: string | null;
  contact: string | null;
  commitmentDate: string | null;
  expectedDate: string | null;
  amountPledged: number;
  stage: string;
  restriction: string;
  notes: string | null;
  activityCode: string | null;
  received: number;
  outstanding: number;
};

export default function Sponsorship() {
  const q = trpc.sponsorship.list.useQuery();
  const activities = trpc.activities.list.useQuery();
  const cash = trpc.cash.list.useQuery();
  const { toast, toastNode } = useToast();
  const utils = trpc.useUtils();
  // Recording a receipt is a register write (auditor may); adding or deleting a
  // sponsor is book management (treasurer only).
  const access = trpc.access.list.useQuery(undefined, { staleTime: 60_000 });
  const { canEnterRegisters, canManageBook } = roleFlags(access.data?.myRole);

  const [editing, setEditing] = useState<Partial<Pledge> | null>(null);
  const [deleting, setDeleting] = useState<Pledge | null>(null);
  const [receipt, setReceipt] = useState<Pledge | null>(null);

  const save = trpc.sponsorship.upsert.useMutation({
    onSuccess: () => {
      utils.sponsorship.list.invalidate();
      setEditing(null);
      toast("Pledge saved");
    },
  });
  const remove = trpc.sponsorship.remove.useMutation({
    onSuccess: () => {
      utils.sponsorship.list.invalidate();
      setDeleting(null);
      toast("Pledge deleted");
    },
  });

  if (q.isLoading) {
    return (
      <AppShell title="Sponsorship">
        <Loading />
      </AppShell>
    );
  }
  if (q.error) {
    return (
      <AppShell title="Sponsorship">
        <ErrorBox error={q.error} />
      </AppShell>
    );
  }

  const rows = (q.data ?? []) as Pledge[];
  const totalPledged = rows.reduce((s, r) => s + r.amountPledged, 0);
  const totalReceived = rows.reduce((s, r) => s + r.received, 0);
  const weighted = rows.reduce((s, r) => {
    const w = STAGES.find((x) => x.key === r.stage)?.weight ?? 0;
    return s + r.amountPledged * w;
  }, 0);

  const byStage = STAGES.map((s) => ({
    ...s,
    count: rows.filter((r) => r.stage === s.key).length,
    value: rows.filter((r) => r.stage === s.key).reduce((a, r) => a + r.amountPledged, 0),
  }));

  return (
    <AppShell
      title="Sponsorship"
      subtitle="The pipeline from first approach to money in the bank."
      actions={
        canManageBook ? (
          <Button size="sm" onClick={() => setEditing({ stage: "pledged", restriction: "restricted" })}>
            <Plus className="mr-1.5 h-3.5 w-3.5" /> Add sponsor
          </Button>
        ) : undefined
      }
    >
      {toastNode}
      {rows.length === 0 ? (
        <EmptyState
          icon={<Handshake className="h-8 w-8" />}
          title="No sponsors yet"
          body="Record a sponsor and this page tracks the pledge through every stage, then matches it against the receipts posted to the ledger."
          action={
            canManageBook ? (
              <Button size="sm" onClick={() => setEditing({ stage: "pledged", restriction: "restricted" })}>
                <Plus className="mr-1.5 h-3.5 w-3.5" /> Add the first sponsor
              </Button>
            ) : undefined
          }
        />
      ) : (
        <div className="space-y-5">
          <div className="grid gap-3 sm:grid-cols-3">
            <Panel>
              <div className="label-cap">Total pledged</div>
              <div className="tnum mt-1.5 text-xl font-semibold">{ngn(totalPledged)}</div>
            </Panel>
            <Panel>
              <div className="label-cap">Received</div>
              <div className="tnum mt-1.5 text-xl font-semibold text-favourable">{ngn(totalReceived)}</div>
              <div className="mt-1 text-[11px] text-muted-foreground">
                {pct(totalReceived, totalPledged)}% of pledges
              </div>
            </Panel>
            <Panel>
              <div className="label-cap">Weighted pipeline</div>
              <div className="tnum mt-1.5 text-xl font-semibold">{ngn(weighted)}</div>
              <div className="mt-1 text-[11px] text-muted-foreground">Pledges × stage probability</div>
            </Panel>
          </div>

          <Panel>
            <SectionHead>Pipeline</SectionHead>
            <div className="grid gap-2 sm:grid-cols-3 lg:grid-cols-7">
              {byStage.map((s) => (
                <div key={s.key} className="rounded-md border border-border p-2.5">
                  <div className="label-cap">{s.label}</div>
                  <div className="tnum mt-1 text-sm font-semibold">{s.count}</div>
                  <div className="tnum text-[11px] text-muted-foreground">
                    {ngn(s.value, { decimals: false })}
                  </div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel>
            <SectionHead right={<span className="label-cap">{rows.length} sponsors</span>}>
              Sponsors
            </SectionHead>
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>Ref</th>
                    <th>Sponsor</th>
                    <th>Purpose</th>
                    <th>Activity</th>
                    <th>Stage</th>
                    <th>Restriction</th>
                    <th>Expected</th>
                    <th className="num">Pledged</th>
                    <th className="num">Received</th>
                    <th className="num">Outstanding</th>
                    <th className="no-print" />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.id}>
                      <td className="tnum text-xs">
                        <Link href={`/sponsorship/${r.id}`} className="font-medium text-primary underline">
                          {r.sponsorshipId}
                        </Link>
                      </td>
                      <td className="text-sm font-medium">{r.sponsor}</td>
                      <td className="max-w-[16rem] truncate text-xs text-muted-foreground">
                        {r.purpose ?? "—"}
                      </td>
                      <td className="text-xs text-muted-foreground">{r.activityCode ?? "—"}</td>
                      <td>
                        <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-semibold uppercase text-secondary-foreground">
                          {r.stage.replace(/_/g, " ")}
                        </span>
                      </td>
                      <td>
                        <FundChip restriction={r.restriction} />
                      </td>
                      <td className="tnum text-xs text-muted-foreground">{r.expectedDate ?? "—"}</td>
                      <td className="num text-sm">{ngn(r.amountPledged)}</td>
                      <td className="num text-sm text-favourable">{ngn(r.received)}</td>
                      <td className={`num text-sm ${r.outstanding > 0 ? "text-adverse" : ""}`}>
                        {ngn(r.outstanding)}
                      </td>
                      <td className="no-print whitespace-nowrap">
                        {canEnterRegisters && (
                          <RowAction onClick={() => setReceipt(r)} title="Record a receipt">
                            <BadgeDollarSign className="h-3 w-3" /> Receipt
                          </RowAction>
                        )}
                        {canManageBook && (
                          <>
                            <RowAction onClick={() => setEditing(r)} title="Edit pledge">
                              <Pencil className="h-3 w-3" />
                            </RowAction>
                            <RowAction onClick={() => setDeleting(r)} tone="danger" title="Delete pledge">
                              <Trash2 className="h-3 w-3" />
                            </RowAction>
                          </>
                        )}
                      </td>
                    </tr>
                  ))}
                  <tr className="total-row">
                    <td colSpan={7}>Total</td>
                    <td className="num">{ngn(totalPledged)}</td>
                    <td className="num">{ngn(totalReceived)}</td>
                    <td className="num">{ngn(totalPledged - totalReceived)}</td>
                    <td />
                  </tr>
                </tbody>
              </table>
            </div>
          </Panel>
        </div>
      )}

      {/* ── Pledge editor ─────────────────────────────────────────────────── */}
      <Modal
        open={!!editing}
        onClose={() => setEditing(null)}
        title={editing?.id ? `Edit ${editing.sponsorshipId}` : "Add sponsor / pledge"}
        description="A new pledge is allocated the next SPT reference automatically."
        width="lg"
        footer={
          <>
            <Button variant="outline" size="sm" onClick={() => setEditing(null)}>
              Cancel
            </Button>
            <SubmitBtn
              label={editing?.id ? "Save changes" : "Add pledge"}
              busy={save.isPending}
              disabled={!editing?.sponsor?.trim()}
              onClick={() =>
                editing &&
                save.mutate({
                  sponsorshipId: editing.sponsorshipId,
                  sponsor: editing.sponsor!.trim(),
                  purpose: editing.purpose || undefined,
                  contact: editing.contact || undefined,
                  commitmentDate: editing.commitmentDate || undefined,
                  expectedDate: editing.expectedDate || undefined,
                  amountPledged: Number(editing.amountPledged ?? 0),
                  stage: (editing.stage ?? "pledged") as never,
                  restriction: (editing.restriction ?? "restricted") as never,
                  notes: editing.notes || undefined,
                  activityCode: editing.activityCode || undefined,
                })
              }
            />
          </>
        }
      >
        {editing && (
          <div className="space-y-3">
            <FormError error={save.error} />
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Sponsor" required>
                <TextInput
                  value={editing.sponsor ?? ""}
                  onChange={(v) => setEditing({ ...editing, sponsor: v })}
                  placeholder="e.g. Zenith Bank"
                  autoFocus
                />
              </Field>
              <Field label="Amount pledged">
                <MoneyInput
                  value={String(editing.amountPledged ?? "")}
                  onChange={(v) => setEditing({ ...editing, amountPledged: parseMoney(v) })}
                />
              </Field>
              <Field label="Stage">
                <Select
                  value={editing.stage ?? "pledged"}
                  onChange={(v) => setEditing({ ...editing, stage: v })}
                  options={STAGES.map((s) => ({ value: s.key, label: s.label }))}
                />
              </Field>
              <Field label="Restriction" hint="How the money may be used.">
                <Select
                  value={editing.restriction ?? "restricted"}
                  onChange={(v) => setEditing({ ...editing, restriction: v })}
                  options={[
                    { value: "unrestricted", label: "Unrestricted" },
                    { value: "restricted", label: "Restricted" },
                    { value: "designated", label: "Designated" },
                  ]}
                />
              </Field>
              <Field label="Activity">
                <Select
                  value={editing.activityCode ?? ""}
                  onChange={(v) => setEditing({ ...editing, activityCode: v || null })}
                  options={(activities.data ?? []).map((a) => ({
                    value: a.code,
                    label: `${a.code} · ${a.name}`,
                  }))}
                  placeholder="None"
                />
              </Field>
              <Field label="Contact">
                <TextInput
                  value={editing.contact ?? ""}
                  onChange={(v) => setEditing({ ...editing, contact: v })}
                  placeholder="Name, phone or email"
                />
              </Field>
              <Field label="Commitment date">
                <TextInput
                  type="date"
                  value={editing.commitmentDate ?? ""}
                  onChange={(v) => setEditing({ ...editing, commitmentDate: v })}
                />
              </Field>
              <Field label="Expected date" hint="When the money is due in.">
                <TextInput
                  type="date"
                  value={editing.expectedDate ?? ""}
                  onChange={(v) => setEditing({ ...editing, expectedDate: v })}
                />
              </Field>
            </div>
            <Field label="Purpose">
              <TextInput
                value={editing.purpose ?? ""}
                onChange={(v) => setEditing({ ...editing, purpose: v })}
                placeholder="What the sponsor is funding"
              />
            </Field>
            <Field label="Notes">
              <TextArea
                value={editing.notes ?? ""}
                onChange={(v) => setEditing({ ...editing, notes: v })}
                placeholder="Anything worth remembering about this relationship"
              />
            </Field>
          </div>
        )}
      </Modal>

      {/* ── Receipt ───────────────────────────────────────────────────────── */}
      {receipt && (
        <ReceiptModal
          pledge={receipt}
          cashAccounts={(cash.data ?? []).map((c) => ({ value: c.code, label: `${c.code} · ${c.name}` }))}
          onClose={() => setReceipt(null)}
          onDone={() => {
            utils.sponsorship.list.invalidate();
            setReceipt(null);
            toast("Receipt posted to the ledger");
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleting}
        title="Delete this pledge?"
        body={`${deleting?.sponsor ?? ""} (${deleting?.sponsorshipId ?? ""}) will be removed from the pipeline. If any receipt has been posted against it, the app will refuse — reverse the transaction first.`}
        busy={remove.isPending}
        onClose={() => setDeleting(null)}
        onConfirm={() => deleting && remove.mutate({ id: deleting.id })}
      />
      {remove.error && <div className="mt-3"><ErrorBox error={remove.error} /></div>}
    </AppShell>
  );
}

/* ── Receipt modal: money moves through the posting engine, never directly ── */
function ReceiptModal({
  pledge,
  cashAccounts,
  onClose,
  onDone,
}: {
  pledge: Pledge;
  cashAccounts: { value: string; label: string }[];
  onClose: () => void;
  onDone: () => void;
}) {
  const [amount, setAmount] = useState(String(pledge.outstanding > 0 ? pledge.outstanding : ""));
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [cashCode, setCashCode] = useState(cashAccounts[0]?.value ?? "");
  const [reference, setReference] = useState("");
  const ev = useEvidenceUpload();

  const record = trpc.sponsorship.recordReceipt.useMutation({ onSuccess: onDone });
  const threshold = 5000;
  const needsEvidence = parseMoney(amount) >= threshold;

  return (
    <Modal
      open
      onClose={onClose}
      title={`Record receipt — ${pledge.sponsor}`}
      description={`${pledge.sponsorshipId} · ${ngn(pledge.outstanding)} outstanding of ${ngn(pledge.amountPledged)}`}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <SubmitBtn
            label="Post receipt"
            busy={record.isPending}
            disabled={!amount || !cashCode || ev.uploading}
            onClick={() =>
              record.mutate({
                id: pledge.id,
                amount: parseMoney(amount),
                receivedDate: date,
                cashAccountCode: cashCode,
                reference: reference || undefined,
                evidenceIds: ev.evidenceIds,
              })
            }
          />
        </>
      }
    >
      <div className="space-y-3">
        <FormError error={record.error} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Amount received" required>
            <MoneyInput value={amount} onChange={setAmount} />
          </Field>
          <Field label="Date received" required>
            <TextInput type="date" value={date} onChange={setDate} />
          </Field>
          <Field label="Paid into" required>
            <Select value={cashCode} onChange={setCashCode} options={cashAccounts} />
          </Field>
          <Field label="Bank reference">
            <TextInput value={reference} onChange={setReference} placeholder="Teller / transfer ref" />
          </Field>
        </div>
        <p className="rounded-md bg-muted px-3 py-2 text-[11px] text-muted-foreground">
          This posts <strong>Dr {cashCode || "cash"} / Cr 4002 Sponsorship income</strong> through
          the same engine every other entry uses, so the ledger stays balanced. Once receipts cover
          the pledge, its stage moves to <strong>Received</strong> on its own.
        </p>
        <EvidenceField
          uploading={ev.uploading}
          fileName={ev.fileName}
          needsEvidence={needsEvidence}
          threshold={threshold}
          onFile={(f) => void ev.handleFile(f)}
          error={ev.error}
        />
      </div>
    </Modal>
  );
}
