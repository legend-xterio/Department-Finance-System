import { useState } from "react";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { Loading, ErrorBox, SectionHead, Panel, EmptyState } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import { fmtDate } from "@shared/finance";
import { History, ShieldCheck } from "lucide-react";

const ENTITY_LABEL: Record<string, string> = {
  asset: "Asset",
  liability: "Commitment",
  member: "Member",
  dues: "Dues",
  budget_line: "Budget line",
  sponsor: "Sponsor",
  transaction: "Transaction",
  settings: "Settings",
  access: "Access",
  period: "Period",
  reconciliation: "Reconciliation",
};

const ACTION_TONE: Record<string, string> = {
  created: "bg-favourable-bg text-favourable",
  updated: "bg-secondary text-secondary-foreground",
  deleted: "bg-adverse-bg text-adverse",
  archived: "bg-muted text-muted-foreground",
  restored: "bg-favourable-bg text-favourable",
  disposed: "bg-warn-bg text-warn",
  settled: "bg-favourable-bg text-favourable",
  posted: "bg-secondary text-secondary-foreground",
};

/**
 * The change log.
 *
 * Journal entries are immutable and reversal-only, so the ledger needs no log.
 * The registers do: an asset's cost, a member's dues status, a budget line, a
 * sponsor, the settings. This is where the auditor and president see who did
 * what, and when.
 */
export default function ChangeLog() {
  const [entity, setEntity] = useState<string>("");
  const [page, setPage] = useState(0);
  const PAGE = 50;

  const log = trpc.changeLog.list.useQuery({
    entity: entity || undefined,
    limit: PAGE,
    offset: page * PAGE,
  });

  const rows = log.data?.rows ?? [];
  const total = log.data?.total ?? 0;
  const pageCount = Math.max(1, Math.ceil(total / PAGE));

  return (
    <AppShell
      title="Change log"
      subtitle="Who changed what, and when. Journal entries are immutable — this covers the registers."
    >
      <div className="space-y-5">
        <Panel>
          <SectionHead
            right={
              <div className="flex flex-wrap items-center gap-1">
                {["", "transaction", "asset", "liability", "member", "dues", "budget_line", "sponsor", "settings", "access", "period"].map(
                  (e) => (
                    <button
                      key={e || "all"}
                      onClick={() => {
                        setEntity(e);
                        setPage(0);
                      }}
                      className={`rounded px-2 py-1 text-xs font-medium transition-colors ${
                        entity === e
                          ? "bg-secondary text-secondary-foreground"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {e ? ENTITY_LABEL[e] ?? e : "All"}
                    </button>
                  ),
                )}
              </div>
            }
          >
            Activity
          </SectionHead>

          {log.isLoading ? (
            <Loading />
          ) : log.error ? (
            <ErrorBox error={log.error} />
          ) : rows.length === 0 ? (
            <EmptyState
              icon={<History className="h-8 w-8" />}
              title="Nothing logged yet"
              body="Edits to assets, members, dues, budget lines, sponsors and settings are recorded here as they happen."
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>When</th>
                    <th>Who</th>
                    <th>Role</th>
                    <th>Register</th>
                    <th>Action</th>
                    <th>What changed</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.id}>
                      <td className="tnum whitespace-nowrap text-xs text-muted-foreground">
                        {fmtDate(String(r.createdAt).slice(0, 10))}
                      </td>
                      <td className="text-sm">{r.actorName ?? "—"}</td>
                      <td className="text-xs text-muted-foreground">
                        {r.actorRole ? (
                          <span
                            className={
                              r.actorRole === "auditor"
                                ? "rounded-full bg-warn-bg px-1.5 py-0.5 font-medium text-warn"
                                : ""
                            }
                          >
                            {r.actorRole}
                          </span>
                        ) : (
                          "—"
                        )}
                      </td>
                      <td className="text-xs">{ENTITY_LABEL[r.entity] ?? r.entity}</td>
                      <td>
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${
                            ACTION_TONE[r.action] ?? "bg-muted text-muted-foreground"
                          }`}
                        >
                          {r.action}
                        </span>
                      </td>
                      <td className="text-sm">{r.summary}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {total > PAGE && (
            <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
              <p className="text-xs text-muted-foreground">
                {page * PAGE + 1}–{Math.min((page + 1) * PAGE, total)} of {total}
              </p>
              <div className="flex items-center gap-1.5">
                <Button size="sm" variant="outline" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>
                  Previous
                </Button>
                <span className="tnum px-1 text-xs text-muted-foreground">
                  Page {page + 1} of {pageCount}
                </span>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page + 1 >= pageCount}
                  onClick={() => setPage((p) => p + 1)}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </Panel>

        <div className="flex items-start gap-2 rounded-lg border border-border bg-card p-3 text-xs text-muted-foreground">
          <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
          <p>
            Journal entries are never edited or deleted — a mistake is corrected by posting a
            reversal with a reason, which leaves both the original and the correction visible. That
            is why the ledger itself needs no change log.
          </p>
        </div>
      </div>
    </AppShell>
  );
}
