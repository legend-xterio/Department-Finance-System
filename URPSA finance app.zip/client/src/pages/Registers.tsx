import { useState } from "react";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { EmptyState, Loading, ErrorBox, SectionHead, Panel } from "@/components/finance-ui";
import { useEvidenceUpload } from "@/components/use-evidence";
import { Button } from "@/components/ui/button";
import {
  Modal,
  Field,
  Select,
  TextInput,
  TextArea,
  MoneyInput,
  parseMoney,
  SubmitBtn,
  RowAction,
  ConfirmDialog,
  FormError,
  EvidenceField,
  useToast,
} from "@/components/form-ui";
import { ngn, fmtDate } from "@shared/finance";
import { roleFlags } from "@/lib/roles";
import { Boxes, Plus, Pencil, Trash2, Archive, CheckCircle2, BookOpen } from "lucide-react";

type Asset = {
  id: string;
  assetId: string;
  description: string;
  category: string;
  serial: string | null;
  custodian: string | null;
  location: string | null;
  purchaseDate: string | null;
  cost: string | number;
  condition: string;
  status: string;
  disposalDate: string | null;
  disposalReason: string | null;
  disposalProceeds: string | null;
  lastVerified: string | null;
  notes: string | null;
};

type Liability = {
  id: string;
  liabilityId: string;
  payee: string;
  description: string | null;
  activityCode: string | null;
  dateIncurred: string | null;
  dueDate: string | null;
  amountCommitted: string | number;
  approvalStatus: string;
  status: string;
  settledDate: string | null;
  settledAmount: string | null;
  /** Which expense this becomes when recognised; defaults to 5007. */
  expenseAccountCode: string;
  /** Null until the commitment is recognised in the books. */
  accrualEntryId: string | null;
};

const CONDITIONS = [
  { value: "new", label: "New" },
  { value: "good", label: "Good" },
  { value: "fair", label: "Fair" },
  { value: "poor", label: "Poor" },
];

const CATEGORIES = ["equipment", "furniture", "electronics", "vehicle", "other"];

export default function Registers() {
  const assets = trpc.assets.list.useQuery();
  const liabilities = trpc.liabilities.list.useQuery();
  const cash = trpc.cash.list.useQuery();
  const activities = trpc.activities.list.useQuery();
  const { toast, toastNode } = useToast();
  const utils = trpc.useUtils();
  // Adding/editing an asset or commitment is a register write (auditor may);
  // deleting one is book management (treasurer only).
  const access = trpc.access.list.useQuery(undefined, { staleTime: 60_000 });
  const { canEnterRegisters, canManageBook } = roleFlags(access.data?.myRole);

  const [assetEdit, setAssetEdit] = useState<Partial<Asset> | null>(null);
  const [assetDelete, setAssetDelete] = useState<Asset | null>(null);
  const [assetDispose, setAssetDispose] = useState<Asset | null>(null);

  const [liaEdit, setLiaEdit] = useState<Partial<Liability> | null>(null);
  const [liaDelete, setLiaDelete] = useState<Liability | null>(null);
  const [liaSettle, setLiaSettle] = useState<Liability | null>(null);
  const [liaAccrue, setLiaAccrue] = useState<Liability | null>(null);
  const liaEv = useEvidenceUpload();

  const saveAsset = trpc.assets.upsert.useMutation({
    onSuccess: () => {
      utils.assets.list.invalidate();
      setAssetEdit(null);
      toast("Asset saved");
    },
  });
  const removeAsset = trpc.assets.remove.useMutation({
    onSuccess: () => {
      utils.assets.list.invalidate();
      setAssetDelete(null);
      toast("Asset deleted");
    },
  });

  const saveLia = trpc.liabilities.upsert.useMutation({
    onSuccess: () => {
      utils.liabilities.list.invalidate();
      setLiaEdit(null);
      toast("Commitment saved");
    },
  });
  const removeLia = trpc.liabilities.remove.useMutation({
    onSuccess: () => {
      utils.liabilities.list.invalidate();
      setLiaDelete(null);
      toast("Commitment deleted");
    },
  });

  const assetRows = (assets.data ?? []) as Asset[];
  const liaRows = (liabilities.data ?? []) as Liability[];

  const activeAssets = assetRows.filter((a) => a.status !== "disposed");
  const totalCost = activeAssets.reduce((s, a) => s + Number(a.cost), 0);
  const totalCommitted = liaRows
    .filter((l) => l.status === "outstanding")
    .reduce((s, l) => s + Number(l.amountCommitted), 0);

  const cashOptions = (cash.data ?? []).map((c) => ({ value: c.code, label: `${c.code} · ${c.name}` }));
  const activityOptions = (activities.data ?? []).map((a) => ({
    value: a.code,
    label: `${a.code} · ${a.name}`,
  }));

  return (
    <AppShell
      title="Assets & liabilities"
      subtitle="What the association owns, and what it still owes. Disposals and settlements post to the ledger."
      actions={
        canEnterRegisters ? (
          <div className="no-print flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setLiaEdit({ approvalStatus: "Approved", status: "outstanding" })}>
              <Plus className="mr-1.5 h-3.5 w-3.5" /> Add commitment
            </Button>
            <Button size="sm" onClick={() => setAssetEdit({ condition: "good", category: "equipment" })}>
              <Plus className="mr-1.5 h-3.5 w-3.5" /> Add asset
            </Button>
          </div>
        ) : undefined
      }
    >
      {toastNode}
      <div className="space-y-5">
        <div className="grid gap-3 sm:grid-cols-3">
          <Panel>
            <div className="label-cap">Assets on the register</div>
            <div className="tnum mt-1.5 text-xl font-semibold">{activeAssets.length}</div>
            {assetRows.length !== activeAssets.length && (
              <div className="mt-1 text-[11px] text-muted-foreground">
                {assetRows.length - activeAssets.length} disposed
              </div>
            )}
          </Panel>
          <Panel>
            <div className="label-cap">Total asset cost</div>
            <div className="tnum mt-1.5 text-xl font-semibold">{ngn(totalCost)}</div>
          </Panel>
          <Panel>
            <div className="label-cap">Outstanding commitments</div>
            <div className="tnum mt-1.5 text-xl font-semibold text-adverse">{ngn(totalCommitted)}</div>
          </Panel>
        </div>

        {/* ── Asset register ─────────────────────────────────────────────── */}
        <Panel>
          <SectionHead right={<Boxes className="h-4 w-4 text-muted-foreground" />}>Asset register</SectionHead>
          {assets.isLoading ? (
            <Loading />
          ) : assets.error ? (
            <ErrorBox error={assets.error} />
          ) : assetRows.length === 0 ? (
            <EmptyState
              icon={<Boxes className="h-8 w-8" />}
              title="No assets registered"
              body="Record what the association owns — equipment, furniture, anything with a custodian — and this register tracks its condition, location and disposal."
              action={
                <Button size="sm" onClick={() => setAssetEdit({ condition: "good", category: "equipment" })}>
                  <Plus className="mr-1.5 h-3.5 w-3.5" /> Add the first asset
                </Button>
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>Ref</th>
                    <th>Description</th>
                    <th>Category</th>
                    <th>Serial</th>
                    <th>Custodian</th>
                    <th>Location</th>
                    <th>Purchased</th>
                    <th>Condition</th>
                    <th>Status</th>
                    <th className="num">Cost</th>
                    <th className="no-print" />
                  </tr>
                </thead>
                <tbody>
                  {assetRows.map((a) => {
                    const disposed = a.status === "disposed";
                    return (
                      <tr key={a.id} className={disposed ? "opacity-60" : ""}>
                        <td className="tnum text-xs text-muted-foreground">{a.assetId}</td>
                        <td className="text-sm">{a.description}</td>
                        <td className="text-xs text-muted-foreground">{a.category}</td>
                        <td className="tnum text-xs text-muted-foreground">{a.serial ?? "—"}</td>
                        <td className="text-xs text-muted-foreground">{a.custodian ?? "—"}</td>
                        <td className="text-xs text-muted-foreground">{a.location ?? "—"}</td>
                        <td className="tnum text-xs">{fmtDate(a.purchaseDate)}</td>
                        <td>
                          <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-semibold uppercase text-secondary-foreground">
                            {a.condition}
                          </span>
                        </td>
                        <td>
                          <span
                            className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${
                              disposed ? "bg-adverse-bg text-adverse" : "bg-favourable-bg text-favourable"
                            }`}
                            title={disposed ? (a.disposalReason ?? "") : undefined}
                          >
                            {disposed ? "disposed" : "in use"}
                          </span>
                        </td>
                        <td className="num text-sm">{ngn(a.cost)}</td>
                        <td className="no-print whitespace-nowrap">
                          {!disposed && canEnterRegisters && (
                            <>
                              <RowAction onClick={() => setAssetEdit(a)} title="Edit asset">
                                <Pencil className="h-3 w-3" />
                              </RowAction>
                              <RowAction onClick={() => setAssetDispose(a)} title="Dispose of asset">
                                <Archive className="h-3 w-3" />
                              </RowAction>
                            </>
                          )}
                          {canManageBook && (
                            <RowAction onClick={() => setAssetDelete(a)} tone="danger" title="Delete asset">
                              <Trash2 className="h-3 w-3" />
                            </RowAction>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                  <tr className="total-row">
                    <td colSpan={9}>Total cost on the register</td>
                    <td className="num">{ngn(totalCost)}</td>
                    <td />
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </Panel>

        {/* ── Liabilities ────────────────────────────────────────────────── */}
        <Panel>
          <SectionHead
            right={<span className="label-cap">Settling a commitment posts Dr 2011 / Cr cash</span>}
          >
            Liabilities & commitments
          </SectionHead>
          {liabilities.isLoading ? (
            <Loading />
          ) : liabilities.error ? (
            <ErrorBox error={liabilities.error} />
          ) : liaRows.length === 0 ? (
            <EmptyState
              icon={<Boxes className="h-8 w-8" />}
              title="No commitments recorded"
              body="Record what the association owes — a supplier invoice, an agreed honorarium — and settling it moves the liability off the balance sheet with the cash."
              action={
                <Button variant="outline" size="sm" onClick={() => setLiaEdit({ approvalStatus: "Approved", status: "outstanding" })}>
                  <Plus className="mr-1.5 h-3.5 w-3.5" /> Add a commitment
                </Button>
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>Ref</th>
                    <th>Payee</th>
                    <th>Description</th>
                    <th>Activity</th>
                    <th>Incurred</th>
                    <th>Due</th>
                    <th>Approval</th>
                    <th>Status</th>
                    <th className="num">Committed</th>
                    <th className="no-print" />
                  </tr>
                </thead>
                <tbody>
                  {liaRows.map((l) => {
                    const settled = l.status === "settled";
                    return (
                      <tr key={l.id} className={settled ? "opacity-60" : ""}>
                        <td className="tnum text-xs text-muted-foreground">{l.liabilityId}</td>
                        <td className="text-sm font-medium">{l.payee}</td>
                        <td className="max-w-[14rem] truncate text-xs text-muted-foreground">
                          {l.description ?? "—"}
                        </td>
                        <td className="text-xs text-muted-foreground">{l.activityCode ?? "—"}</td>
                        <td className="tnum text-xs">{fmtDate(l.dateIncurred)}</td>
                        <td className="tnum text-xs">{fmtDate(l.dueDate)}</td>
                        <td className="text-xs text-muted-foreground">{l.approvalStatus}</td>
                        <td>
                          <span
                            className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${
                              settled ? "bg-favourable-bg text-favourable" : "bg-warn-bg text-warn"
                            }`}
                            title={settled ? `Settled ${l.settledDate ?? ""}` : undefined}
                          >
                            {l.status}
                          </span>
                        </td>
                        <td className="num text-sm">{ngn(l.amountCommitted)}</td>
                        <td className="no-print whitespace-nowrap">
                          {!settled && canEnterRegisters && (
                            <>
                              {l.accrualEntryId ? (
                                <RowAction onClick={() => setLiaSettle(l)} title="Settle commitment">
                                  <CheckCircle2 className="h-3 w-3" /> Settle
                                </RowAction>
                              ) : (
                                <RowAction
                                  onClick={() => setLiaAccrue(l)}
                                  title="Recognise in the books first, then settle"
                                >
                                  <BookOpen className="h-3 w-3" /> Recognise
                                </RowAction>
                              )}
                              <RowAction onClick={() => setLiaEdit(l)} title="Edit commitment">
                                <Pencil className="h-3 w-3" />
                              </RowAction>
                            </>
                          )}
                          {canManageBook && (
                            <RowAction onClick={() => setLiaDelete(l)} tone="danger" title="Delete commitment">
                              <Trash2 className="h-3 w-3" />
                            </RowAction>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                  <tr className="total-row">
                    <td colSpan={8}>Outstanding</td>
                    <td className="num">{ngn(totalCommitted)}</td>
                    <td />
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>

      {/* ── Asset editor ─────────────────────────────────────────────────── */}
      <Modal
        open={!!assetEdit}
        onClose={() => setAssetEdit(null)}
        title={assetEdit?.id ? `Edit ${assetEdit.assetId}` : "Add asset"}
        description="A new asset is allocated the next AST reference automatically."
        width="lg"
        footer={
          <>
            <Button variant="outline" size="sm" onClick={() => setAssetEdit(null)}>
              Cancel
            </Button>
            <SubmitBtn
              label={assetEdit?.id ? "Save changes" : "Add asset"}
              busy={saveAsset.isPending}
              disabled={!assetEdit?.description?.trim()}
              onClick={() =>
                assetEdit &&
                saveAsset.mutate({
                  assetId: assetEdit.assetId,
                  description: assetEdit.description!.trim(),
                  category: assetEdit.category ?? "equipment",
                  serial: assetEdit.serial || undefined,
                  custodian: assetEdit.custodian || undefined,
                  location: assetEdit.location || undefined,
                  purchaseDate: assetEdit.purchaseDate || undefined,
                  cost: Number(assetEdit.cost ?? 0),
                  condition: (assetEdit.condition ?? "good") as never,
                  lastVerified: assetEdit.lastVerified || undefined,
                  notes: assetEdit.notes || undefined,
                })
              }
            />
          </>
        }
      >
        {assetEdit && (
          <div className="space-y-3">
            <FormError error={saveAsset.error} />
            <Field label="Description" required>
              <TextInput
                value={assetEdit.description ?? ""}
                onChange={(v) => setAssetEdit({ ...assetEdit, description: v })}
                placeholder="e.g. Projector — Epson EB-X06"
                autoFocus
              />
            </Field>
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Category">
                <Select
                  value={assetEdit.category ?? "equipment"}
                  onChange={(v) => setAssetEdit({ ...assetEdit, category: v })}
                  options={CATEGORIES.map((c) => ({ value: c, label: c }))}
                />
              </Field>
              <Field label="Condition">
                <Select
                  value={assetEdit.condition ?? "good"}
                  onChange={(v) => setAssetEdit({ ...assetEdit, condition: v })}
                  options={CONDITIONS}
                />
              </Field>
              <Field label="Cost">
                <MoneyInput
                  value={String(assetEdit.cost ?? "")}
                  onChange={(v) => setAssetEdit({ ...assetEdit, cost: parseMoney(v) })}
                />
              </Field>
              <Field label="Serial number">
                <TextInput
                  value={assetEdit.serial ?? ""}
                  onChange={(v) => setAssetEdit({ ...assetEdit, serial: v })}
                />
              </Field>
              <Field label="Custodian">
                <TextInput
                  value={assetEdit.custodian ?? ""}
                  onChange={(v) => setAssetEdit({ ...assetEdit, custodian: v })}
                />
              </Field>
              <Field label="Location">
                <TextInput
                  value={assetEdit.location ?? ""}
                  onChange={(v) => setAssetEdit({ ...assetEdit, location: v })}
                />
              </Field>
              <Field label="Purchase date">
                <TextInput
                  type="date"
                  value={assetEdit.purchaseDate ?? ""}
                  onChange={(v) => setAssetEdit({ ...assetEdit, purchaseDate: v })}
                />
              </Field>
              <Field label="Last verified">
                <TextInput
                  type="date"
                  value={assetEdit.lastVerified ?? ""}
                  onChange={(v) => setAssetEdit({ ...assetEdit, lastVerified: v })}
                />
              </Field>
            </div>
            <Field label="Notes">
              <TextArea
                value={assetEdit.notes ?? ""}
                onChange={(v) => setAssetEdit({ ...assetEdit, notes: v })}
              />
            </Field>
          </div>
        )}
      </Modal>

      {/* ── Disposal ─────────────────────────────────────────────────────── */}
      {assetDispose && (
        <DisposeModal
          asset={assetDispose}
          cashOptions={cashOptions}
          onClose={() => setAssetDispose(null)}
          onDone={() => {
            utils.assets.list.invalidate();
            utils.reports.controlChecks.invalidate();
            setAssetDispose(null);
            toast("Asset disposed");
          }}
        />
      )}

      {/* ── Liability editor ─────────────────────────────────────────────── */}
      <Modal
        open={!!liaEdit}
        onClose={() => setLiaEdit(null)}
        title={liaEdit?.id ? `Edit ${liaEdit.liabilityId}` : "Add commitment"}
        description="A new commitment is allocated the next LIA reference automatically."
        width="lg"
        footer={
          <>
            <Button variant="outline" size="sm" onClick={() => setLiaEdit(null)}>
              Cancel
            </Button>
            <SubmitBtn
              label={liaEdit?.id ? "Save changes" : "Add commitment"}
              busy={saveLia.isPending}
              disabled={!liaEdit?.payee?.trim() || liaEv.uploading}
              onClick={() =>
                liaEdit &&
                saveLia.mutate({
                  liabilityId: liaEdit.liabilityId,
                  payee: liaEdit.payee!.trim(),
                  description: liaEdit.description || undefined,
                  activityCode: liaEdit.activityCode || undefined,
                  dateIncurred: liaEdit.dateIncurred || undefined,
                  dueDate: liaEdit.dueDate || undefined,
                  amountCommitted: Number(liaEdit.amountCommitted ?? 0),
                  approvalStatus: (liaEdit.approvalStatus ?? "Approved") as never,
                  evidenceIds: liaEv.evidenceIds,
                  status: (liaEdit.status ?? "outstanding") as never,
                })
              }
            />
          </>
        }
      >
        {liaEdit && (
          <div className="space-y-3">
            <FormError error={saveLia.error} />
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Payee" required>
                <TextInput
                  value={liaEdit.payee ?? ""}
                  onChange={(v) => setLiaEdit({ ...liaEdit, payee: v })}
                  placeholder="e.g. Faculty of Environmental Sciences"
                  autoFocus
                />
              </Field>
              <Field label="Amount committed">
                <MoneyInput
                  value={String(liaEdit.amountCommitted ?? "")}
                  onChange={(v) => setLiaEdit({ ...liaEdit, amountCommitted: parseMoney(v) })}
                />
              </Field>
              <Field label="Activity">
                <Select
                  value={liaEdit.activityCode ?? ""}
                  onChange={(v) => setLiaEdit({ ...liaEdit, activityCode: v || null })}
                  options={activityOptions}
                  placeholder="None"
                />
              </Field>
              <Field label="Approval">
                <Select
                  value={liaEdit.approvalStatus ?? "Approved"}
                  onChange={(v) => setLiaEdit({ ...liaEdit, approvalStatus: v })}
                  options={[
                    { value: "Approved", label: "Approved" },
                    { value: "Pending", label: "Pending" },
                  ]}
                />
              </Field>
              <Field label="Date incurred">
                <TextInput
                  type="date"
                  value={liaEdit.dateIncurred ?? ""}
                  onChange={(v) => setLiaEdit({ ...liaEdit, dateIncurred: v })}
                />
              </Field>
              <Field label="Due date">
                <TextInput
                  type="date"
                  value={liaEdit.dueDate ?? ""}
                  onChange={(v) => setLiaEdit({ ...liaEdit, dueDate: v })}
                />
              </Field>
            </div>
            <Field label="Description">
              <TextInput
                value={liaEdit.description ?? ""}
                onChange={(v) => setLiaEdit({ ...liaEdit, description: v })}
              />
            </Field>
            <EvidenceField
              uploading={liaEv.uploading}
              fileName={liaEv.fileName}
              needsEvidence={Number(liaEdit.amountCommitted ?? 0) >= 5000 && !liaEdit.id}
              threshold={5000}
              onFile={(f) => void liaEv.handleFile(f)}
              error={liaEv.error}
            />
          </div>
        )}
      </Modal>

      {/* ── Settlement ───────────────────────────────────────────────────── */}
      {liaAccrue && (
        <AccrueModal
          liability={liaAccrue}
          onClose={() => setLiaAccrue(null)}
          onDone={() => {
            void utils.liabilities.list.invalidate();
            void utils.reports.controlChecks.invalidate();
            setLiaAccrue(null);
          }}
        />
      )}
      {liaSettle && (
        <SettleModal
          liability={liaSettle}
          cashOptions={cashOptions}
          onClose={() => setLiaSettle(null)}
          onDone={() => {
            utils.liabilities.list.invalidate();
            utils.reports.controlChecks.invalidate();
            setLiaSettle(null);
            toast("Commitment settled and posted to the ledger");
          }}
        />
      )}

      <ConfirmDialog
        open={!!assetDelete}
        title="Delete this asset?"
        body={`${assetDelete?.description ?? ""} (${assetDelete?.assetId ?? ""}) will be removed from the register. If disposal proceeds were posted to the ledger, the app will refuse — reverse that transaction first.`}
        busy={removeAsset.isPending}
        onClose={() => setAssetDelete(null)}
        onConfirm={() => assetDelete && removeAsset.mutate({ id: assetDelete.id })}
      />
      <ConfirmDialog
        open={!!liaDelete}
        title="Delete this commitment?"
        body={`${liaDelete?.payee ?? ""} (${liaDelete?.liabilityId ?? ""}) will be removed. If it has been settled, the app will refuse — reverse the settlement first.`}
        busy={removeLia.isPending}
        onClose={() => setLiaDelete(null)}
        onConfirm={() => liaDelete && removeLia.mutate({ id: liaDelete.id })}
      />
      {(removeAsset.error || removeLia.error) && (
        <div className="mt-3">
          <ErrorBox error={removeAsset.error ?? removeLia.error} />
        </div>
      )}
    </AppShell>
  );
}

/* ── Disposal: proceeds post to 4005, the row stays as `disposed` ─────────── */
function DisposeModal({
  asset,
  cashOptions,
  onClose,
  onDone,
}: {
  asset: Asset;
  cashOptions: { value: string; label: string }[];
  onClose: () => void;
  onDone: () => void;
}) {
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [reason, setReason] = useState("");
  const [proceeds, setProceeds] = useState("0");
  const [cashCode, setCashCode] = useState(cashOptions[0]?.value ?? "");
  const dispose = trpc.assets.dispose.useMutation({ onSuccess: onDone });
  const ev = useEvidenceUpload();
  const needsEvidence = parseMoney(proceeds) >= 5000;

  return (
    <Modal
      open
      onClose={onClose}
      title={`Dispose of ${asset.assetId}`}
      description={`${asset.description} · ${ngn(asset.cost)} on the register`}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <SubmitBtn
            label="Dispose"
            busy={dispose.isPending}
            disabled={!reason.trim() || ev.uploading}
            onClick={() =>
              dispose.mutate({
                id: asset.id,
                disposalDate: date,
                disposalReason: reason.trim(),
                proceeds: parseMoney(proceeds),
                cashAccountCode: parseMoney(proceeds) > 0 ? cashCode : undefined,
                evidenceIds: ev.evidenceIds,
              })
            }
          />
        </>
      }
    >
      <div className="space-y-3">
        <FormError error={dispose.error} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Disposal date" required>
            <TextInput type="date" value={date} onChange={setDate} />
          </Field>
          <Field label="Proceeds received" hint="Leave 0 if it was scrapped or given away.">
            <MoneyInput value={proceeds} onChange={setProceeds} />
          </Field>
        </div>
        {parseMoney(proceeds) > 0 && (
          <Field label="Paid into" required>
            <Select value={cashCode} onChange={setCashCode} options={cashOptions} />
          </Field>
        )}
        <Field label="Reason" required>
          <TextInput
            value={reason}
            onChange={setReason}
            placeholder="e.g. Beyond repair; replaced under warranty"
            autoFocus
          />
        </Field>
        <p className="rounded-md bg-muted px-3 py-2 text-[11px] text-muted-foreground">
          The asset stays on the register marked <strong>disposed</strong> — history is not
          rewritten. Any proceeds are posted as other income so the cash and the register agree.
        </p>
        {parseMoney(proceeds) > 0 && (
          <EvidenceField
            uploading={ev.uploading}
            fileName={ev.fileName}
            needsEvidence={needsEvidence}
            threshold={5000}
            onFile={(f) => void ev.handleFile(f)}
            error={ev.error}
          />
        )}
      </div>
    </Modal>
  );
}

/* ── Settlement: Dr 2011 Liabilities / Cr cash, through the engine ────────── */
/* ── Recognition: Dr expense / Cr 2011, through the engine ────────────────── */
function AccrueModal({
  liability,
  onClose,
  onDone,
}: {
  liability: Liability;
  onClose: () => void;
  onDone: () => void;
}) {
  const [date, setDate] = useState(liability.dateIncurred ?? new Date().toISOString().slice(0, 10));
  const ev = useEvidenceUpload();
  const needsEvidence = Number(liability.amountCommitted) >= 5000;
  const accrue = trpc.liabilities.accrue.useMutation({ onSuccess: onDone });

  return (
    <Modal
      open
      onClose={onClose}
      title={`Recognise ${liability.liabilityId}`}
      description={`${liability.payee} · ${ngn(liability.amountCommitted)}`}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <SubmitBtn
            label="Recognise and post"
            busy={accrue.isPending}
            disabled={ev.uploading}
            onClick={() =>
              accrue.mutate({
                id: liability.id,
                entryDate: date,
                evidenceIds: ev.evidenceIds,
              })
            }
          />
        </>
      }
    >
      <div className="space-y-3">
        <FormError error={accrue.error} />
        <Field label="Date incurred" required>
          <TextInput type="date" value={date} onChange={setDate} />
        </Field>
        <p className="rounded-md bg-muted px-3 py-2 text-[11px] text-muted-foreground">
          This posts <strong>Dr {liability.expenseAccountCode} / Cr 2011 Liabilities</strong>. Until a
          commitment is recognised it is only a memo line and has no balance-sheet effect — which is
          why paying it would drive the liability account negative. After this, Settle becomes
          available.
        </p>
        <EvidenceField
          uploading={ev.uploading}
          fileName={ev.fileName}
          needsEvidence={needsEvidence}
          threshold={5000}
          onFile={(f) => void ev.handleFile(f)}
          error={ev.error}
        />
      </div>
    </Modal>
  );
}

function SettleModal({
  liability,
  cashOptions,
  onClose,
  onDone,
}: {
  liability: Liability;
  cashOptions: { value: string; label: string }[];
  onClose: () => void;
  onDone: () => void;
}) {
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [amount, setAmount] = useState(String(Number(liability.amountCommitted)));
  const [cashCode, setCashCode] = useState(cashOptions[0]?.value ?? "");
  const [ref, setRef] = useState("");
  const settle = trpc.liabilities.settle.useMutation({ onSuccess: onDone });
  const ev = useEvidenceUpload();
  const needsEvidence = parseMoney(amount) >= 5000;

  return (
    <Modal
      open
      onClose={onClose}
      title={`Settle ${liability.liabilityId}`}
      description={`${liability.payee} · ${ngn(liability.amountCommitted)} committed`}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <SubmitBtn
            label="Settle and post"
            busy={settle.isPending}
            disabled={!amount || !cashCode || ev.uploading}
            onClick={() =>
              settle.mutate({
                id: liability.id,
                settledDate: date,
                amount: parseMoney(amount),
                cashAccountCode: cashCode,
                settlementRef: ref || undefined,
                evidenceIds: ev.evidenceIds,
              })
            }
          />
        </>
      }
    >
      <div className="space-y-3">
        <FormError error={settle.error} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Amount paid" required>
            <MoneyInput value={amount} onChange={setAmount} />
          </Field>
          <Field label="Settlement date" required>
            <TextInput type="date" value={date} onChange={setDate} />
          </Field>
          <Field label="Paid from" required>
            <Select value={cashCode} onChange={setCashCode} options={cashOptions} />
          </Field>
          <Field label="Payment reference">
            <TextInput value={ref} onChange={setRef} placeholder="Cheque / transfer ref" />
          </Field>
        </div>
        <p className="rounded-md bg-muted px-3 py-2 text-[11px] text-muted-foreground">
          This posts <strong>Dr 2011 Liabilities / Cr {cashCode || "cash"}</strong>. The commitment
          leaves the balance sheet at the same moment the cash does.
        </p>
        <EvidenceField
          uploading={ev.uploading}
          fileName={ev.fileName}
          needsEvidence={needsEvidence}
          threshold={5000}
          onFile={(f) => void ev.handleFile(f)}
          error={ev.error}
        />
      </div>
    </Modal>
  );
}
