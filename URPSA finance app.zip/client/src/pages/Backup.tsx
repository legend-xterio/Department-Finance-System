import { useState } from "react";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { ErrorBox, SectionHead, Panel } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ngn } from "@shared/finance";
import { Download, CheckCircle2, AlertTriangle, Database, FileJson } from "lucide-react";

/**
 * Backup (export only — there is no in-app restore).
 *
 * The five report CSVs prove the figures; this archive is the full record behind
 * them. The validator re-reads a downloaded file and checks the journal
 * balances, so the treasurer can prove the file is complete before they ever
 * need it. Re-importing is a manual developer job, and the UI says so.
 */
export default function Backup() {
  const exportBook = trpc.export.book.useMutation();
  const validate = trpc.export.validate.useMutation();

  const [result, setResult] = useState<{
    filename: string;
    counts: Record<string, number>;
    bytes: number;
    checksum: string;
  } | null>(null);
  const [error, setError] = useState<unknown>(null);

  const [check, setCheck] = useState<{
    ok: boolean;
    problems: string[];
    counts: Record<string, number>;
    exportedAt: string | null;
    totalDebit: number;
    totalCredit: number;
    difference: number;
  } | null>(null);
  const [checkError, setCheckError] = useState<unknown>(null);

  async function download() {
    setError(null);
    try {
      const res = await exportBook.mutateAsync();
      const blob = new Blob([res.json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = res.filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      setResult({
        filename: res.filename,
        counts: res.counts,
        bytes: res.bytes,
        checksum: res.checksum,
      });
    } catch (err) {
      setError(err);
    }
  }

  async function onFile(file: File) {
    setCheckError(null);
    setCheck(null);
    try {
      const text = await file.text();
      const res = await validate.mutateAsync({ json: text });
      setCheck(res);
    } catch (err) {
      setCheckError(err);
    }
  }

  return (
    <AppShell
      title="Backup"
      subtitle="A complete archive of the whole book — not a statement."
    >
      <div className="space-y-5">
        <Panel>
          <SectionHead right={<span className="label-cap">Every table</span>}>
            Download the full book
          </SectionHead>
          <p className="text-sm text-muted-foreground">
            One JSON file containing the chart of accounts, transactions, journal entries and lines,
            evidence metadata, budgets and lines, activities, members and dues, sponsors and pledges,
            assets, liabilities, reconciliations, settings and the change log. Keep a copy off the
            server — this is the only thing that can rebuild the book if the database is lost.
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <Button size="sm" onClick={download} disabled={exportBook.isPending}>
              <Download className="mr-1.5 h-3.5 w-3.5" />
              {exportBook.isPending ? "Building the archive…" : "Download the full book"}
            </Button>
            {result && (
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-favourable">
                <CheckCircle2 className="h-3.5 w-3.5" />
                {result.filename} · {(result.bytes / 1024).toFixed(1)} KB
              </span>
            )}
          </div>
          {error ? (
            <div className="mt-3">
              <ErrorBox error={error} />
            </div>
          ) : null}

          {result && (
            <div className="mt-4 rounded-lg border border-border bg-muted/30 p-3">
              <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold">
                <Database className="h-3.5 w-3.5" /> What is in the file
              </div>
              <div className="grid gap-1.5 sm:grid-cols-3 lg:grid-cols-4">
                {Object.entries(result.counts).map(([table, n]) => (
                  <div key={table} className="flex items-baseline justify-between gap-2 text-xs">
                    <span className="text-muted-foreground">{table.replace(/_/g, " ")}</span>
                    <span className="tnum font-medium">{n}</span>
                  </div>
                ))}
              </div>
              <p className="mt-3 break-all text-[11px] text-muted-foreground">
                SHA-256 {result.checksum}
              </p>
            </div>
          )}
        </Panel>

        <Panel>
          <SectionHead right={<span className="label-cap">Read-only check</span>}>
            Validate an archive
          </SectionHead>
          <p className="text-sm text-muted-foreground">
            Load a downloaded archive to prove it is complete and internally consistent. Nothing is
            written — this only reads the file and re-checks that every journal entry balances and
            every line points at an entry that is present.
          </p>
          <div className="mt-4 space-y-1.5">
            <Label htmlFor="file">Archive file</Label>
            <Input
              id="file"
              type="file"
              accept="application/json,.json"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onFile(f);
              }}
            />
          </div>

          {validate.isPending && <p className="mt-3 text-sm text-muted-foreground">Checking…</p>}

          {check && (
            <div
              className={`mt-4 rounded-lg border p-3 ${
                check.ok ? "border-favourable/40 bg-favourable-bg" : "border-warn/40 bg-warn-bg"
              }`}
            >
              <div className="flex items-center gap-1.5 text-sm font-medium">
                {check.ok ? (
                  <CheckCircle2 className="h-4 w-4 text-favourable" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-warn" />
                )}
                {check.ok ? "Archive is complete and balanced" : "Problems found"}
              </div>
              <div className="mt-2 grid gap-1 text-xs sm:grid-cols-3">
                <div>
                  <span className="text-muted-foreground">Debits </span>
                  <span className="tnum font-medium">{ngn(check.totalDebit)}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Credits </span>
                  <span className="tnum font-medium">{ngn(check.totalCredit)}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Difference </span>
                  <span className={`tnum font-medium ${check.difference === 0 ? "text-favourable" : "text-adverse"}`}>
                    {ngn(check.difference)}
                  </span>
                </div>
              </div>
              {check.problems.length > 0 && (
                <ul className="mt-2 list-inside list-disc text-xs text-adverse">
                  {check.problems.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
              )}
              {check.exportedAt && (
                <p className="mt-2 text-[11px] text-muted-foreground">
                  Exported {new Date(check.exportedAt).toLocaleString()}
                </p>
              )}
            </div>
          )}
          {checkError ? (
            <div className="mt-3">
              <ErrorBox error={checkError} />
            </div>
          ) : null}
        </Panel>

        <div className="flex items-start gap-2 rounded-lg border border-border bg-card p-3 text-xs text-muted-foreground">
          <FileJson className="mt-0.5 h-4 w-4 shrink-0" />
          <p>
            The archive is plain JSON with a version and a checksum, so it can be read by a human
            and diffed between months. Download one after every month-end close and keep it
            somewhere other than this server.
          </p>
          <p className="mt-2">
            <strong className="font-medium text-foreground">There is no in-app restore button.</strong>{" "}
            The file is a complete, readable record of every table — enough for a developer to
            rebuild the book — but re-importing it is a manual job, not a click. Treat it as your
            evidence and your escape hatch, not as a one-button undo.
          </p>
        </div>
      </div>
    </AppShell>
  );
}
