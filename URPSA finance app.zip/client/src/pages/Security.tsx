import { useState } from "react";
import { trpc } from "@/_core/trpc";
import { AppShell } from "@/components/AppShell";
import { Loading, ErrorBox, SectionHead, Panel } from "@/components/finance-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { fmtDate } from "@shared/finance";
import { PrintMark } from "@/components/BrandMark";
import { roleFlags } from "@/lib/roles";
import {
  KeyRound,
  ShieldCheck,
  UserPlus,
  Trash2,
  Copy,
  CheckCircle2,
  AlertTriangle,
  Printer,
} from "lucide-react";

const ROLE_LABEL: Record<string, string> = {
  treasurer: "Treasurer (owner)",
  admin: "Admin — full access",
  auditor: "Auditor — read only",
  president: "President — read only",
};

/**
 * Security & access.
 *
 * Three things a treasurer needs and could not do before: change their own
 * password, hold recovery codes that work without an email service, and give
 * the president or an auditor a login that cannot change the book.
 */
export default function Security() {
  const utils = trpc.useUtils();
  const me = trpc.auth.me.useQuery();
  const access = trpc.access.list.useQuery();
  const recovery = trpc.auth.recoveryStatus.useQuery();
  const org = trpc.org.get.useQuery();

  const changePassword = trpc.auth.changePassword.useMutation();
  const genCodes = trpc.auth.generateRecoveryCodes.useMutation();
  const invite = trpc.access.invite.useMutation();
  const setRole = trpc.access.setRole.useMutation();
  const remove = trpc.access.remove.useMutation();
  const setSignup = trpc.access.setPublicSignup.useMutation();

  const [pw, setPw] = useState({ current: "", next: "", confirm: "" });
  const [pwMsg, setPwMsg] = useState<string | null>(null);
  const [pwErr, setPwErr] = useState<unknown>(null);

  const [codes, setCodes] = useState<string[] | null>(null);
  const [copied, setCopied] = useState(false);
  const [printErr, setPrintErr] = useState<string | null>(null);

  /**
   * Print the codes on their own sheet.
   *
   * The sheet is rendered inside this page but hidden on screen; a body class
   * hides the app and reveals it for the print pass only. The class is removed
   * on `afterprint` so a later Ctrl+P of a report is unaffected.
   */
  function printCodes() {
    if (!codes) return;
    setPrintErr(null);
    document.body.classList.add("printing-codes");
    const cleanup = () => {
      document.body.classList.remove("printing-codes");
      window.removeEventListener("afterprint", cleanup);
    };
    window.addEventListener("afterprint", cleanup);
    try {
      window.print();
    } catch {
      cleanup();
      setPrintErr("Your browser blocked the print dialog. Use Copy all instead.");
    }
    // Safari does not always fire afterprint; do not leave the app hidden.
    setTimeout(cleanup, 60_000);
  }

  const [inv, setInv] = useState({ email: "", name: "", role: "auditor" as "admin" | "auditor" | "president", password: "" });
  const [invMsg, setInvMsg] = useState<string | null>(null);
  const [invErr, setInvErr] = useState<unknown>(null);

  const myRole = access.data?.myRole ?? "treasurer";
  const canWrite = roleFlags(myRole).canManageBook;

  async function submitPassword(e: React.FormEvent) {
    e.preventDefault();
    setPwErr(null);
    setPwMsg(null);
    if (pw.next !== pw.confirm) {
      setPwErr(new Error("The two new passwords do not match."));
      return;
    }
    try {
      await changePassword.mutateAsync({ currentPassword: pw.current, newPassword: pw.next });
      setPw({ current: "", next: "", confirm: "" });
      setPwMsg("Password changed. Every other device has been signed out.");
    } catch (err) {
      setPwErr(err);
    }
  }

  async function submitInvite(e: React.FormEvent) {
    e.preventDefault();
    setInvErr(null);
    setInvMsg(null);
    try {
      const res = await invite.mutateAsync(inv);
      setInvMsg(
        res.password
          ? `Created ${res.email} as ${ROLE_LABEL[res.role]}. Temporary password: ${res.password} — give it to them and ask them to change it on first sign-in.`
          : `Gave ${res.email} ${ROLE_LABEL[res.role]} access.`,
      );
      setInv({ email: "", name: "", role: "auditor", password: "" });
      await utils.access.list.invalidate();
    } catch (err) {
      setInvErr(err);
    }
  }

  return (
    <AppShell
      title="Security & access"
      subtitle="Your password, recovery codes, and who else can see this book."
    >
      <div className="space-y-5">
        {/* The read-only banner is drawn once by AppShell, above the page, so it
            is not repeated here. */}

        {/* ── Password ──────────────────────────────────────────────────────── */}
        <Panel>
          <SectionHead right={<span className="label-cap">Signed in as {me.data?.email}</span>}>
            Change your password
          </SectionHead>
          <form onSubmit={submitPassword} className="grid gap-4 sm:grid-cols-3">
            <div className="space-y-1.5">
              <Label htmlFor="cur">Current password</Label>
              <Input
                id="cur"
                type="password"
                autoComplete="current-password"
                value={pw.current}
                onChange={(e) => setPw({ ...pw, current: e.target.value })}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="next">New password</Label>
              <Input
                id="next"
                type="password"
                autoComplete="new-password"
                value={pw.next}
                onChange={(e) => setPw({ ...pw, next: e.target.value })}
                minLength={8}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="conf">Confirm new password</Label>
              <Input
                id="conf"
                type="password"
                autoComplete="new-password"
                value={pw.confirm}
                onChange={(e) => setPw({ ...pw, confirm: e.target.value })}
                minLength={8}
                required
              />
            </div>
            <div className="sm:col-span-3 flex flex-wrap items-center gap-3">
              <Button type="submit" size="sm" disabled={changePassword.isPending}>
                {changePassword.isPending ? "Saving…" : "Change password"}
              </Button>
              {pwMsg && (
                <span className="inline-flex items-center gap-1.5 text-xs font-medium text-favourable">
                  <CheckCircle2 className="h-3.5 w-3.5" /> {pwMsg}
                </span>
              )}
            </div>
            {pwErr ? (
              <div className="sm:col-span-3">
                <ErrorBox error={pwErr} />
              </div>
            ) : null}
          </form>
        </Panel>

        {/* ── Recovery codes ───────────────────────────────────────────────── */}
        <Panel>
          <SectionHead
            right={
              <span className="label-cap">
                {recovery.data && recovery.data.total > 0
                  ? `${recovery.data.unused} of ${recovery.data.total} unused`
                  : "Not set up"}
              </span>
            }
          >
            Recovery codes
          </SectionHead>
          <p className="text-sm text-muted-foreground">
            This app has no email service, so a forgotten password is recovered with a one-time
            code. Generate a set, print it, and keep it with the books. Each code works once, and
            only a hash is stored — nobody can read them back out of the database.
          </p>
          {recovery.data && recovery.data.total > 0 && (
            <p className="mt-2 text-xs text-muted-foreground">
              Last issued {recovery.data.issuedAt ? fmtDate(String(recovery.data.issuedAt).slice(0, 10)) : "—"}.
              Generating a new set invalidates every old code.
            </p>
          )}

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button
              size="sm"
              variant={recovery.data && recovery.data.total > 0 ? "outline" : "default"}
              disabled={genCodes.isPending}
              onClick={async () => {
                const res = await genCodes.mutateAsync();
                setCodes(res.codes);
                setCopied(false);
                await utils.auth.recoveryStatus.invalidate();
              }}
            >
              <KeyRound className="mr-1.5 h-3.5 w-3.5" />
              {genCodes.isPending
                ? "Generating…"
                : recovery.data && recovery.data.total > 0
                  ? "Generate new codes (replaces the old set)"
                  : "Generate recovery codes"}
            </Button>
            {codes && (
              <>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={async () => {
                    await navigator.clipboard.writeText(codes.join("\n"));
                    setCopied(true);
                  }}
                >
                  <Copy className="mr-1.5 h-3.5 w-3.5" />
                  {copied ? "Copied" : "Copy all"}
                </Button>
                <Button size="sm" variant="ghost" onClick={printCodes}>
                  <Printer className="mr-1.5 h-3.5 w-3.5" />
                  Print sheet
                </Button>
              </>
            )}
          </div>
          {printErr && <p className="mt-2 text-xs text-destructive">{printErr}</p>}

          {codes && (
            <div className="mt-4 rounded-lg border border-warn/40 bg-warn-bg p-4">
              <div className="flex items-start gap-2">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warn" />
                <div className="text-xs">
                  <div className="font-semibold">These are shown once. Print or copy them now.</div>
                  <div className="text-muted-foreground">
                    They will not be displayed again — only hashes are stored.
                  </div>
                </div>
              </div>
              <div className="mt-3 grid gap-1.5 sm:grid-cols-2">
                {codes.map((c) => (
                  <div
                    key={c}
                    className="tnum rounded border border-border bg-card px-2.5 py-1.5 text-sm tracking-wider"
                  >
                    {c}
                  </div>
                ))}
              </div>
            </div>
          )}
        </Panel>

        {/* ── People with access ───────────────────────────────────────────── */}
        <Panel>
          <SectionHead right={<span className="label-cap">{access.data?.members.length ?? 0} people</span>}>
            Who can see this book
          </SectionHead>

          {access.isLoading ? (
            <Loading />
          ) : access.error ? (
            <ErrorBox error={access.error} />
          ) : (
            <div className="overflow-x-auto">
              <table className="ledger">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Added</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {access.data?.owner && (
                    <tr>
                      <td className="text-sm font-medium">{access.data.owner.name ?? "—"}</td>
                      <td className="text-xs text-muted-foreground">{access.data.owner.email}</td>
                      <td>
                        <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-semibold uppercase">
                          Financial secretary
                        </span>
                      </td>
                      <td className="text-xs text-muted-foreground">Owner</td>
                      <td />
                    </tr>
                  )}
                  {(access.data?.members ?? []).map((m) => (
                    <tr key={m.id}>
                      <td className="text-sm">{m.displayName ?? m.name ?? "—"}</td>
                      <td className="text-xs text-muted-foreground">{m.email}</td>
                      <td>
                        {canWrite ? (
                          <select
                            value={m.role}
                            onChange={async (e) => {
                              await setRole.mutateAsync({ id: m.id, role: e.target.value as any });
                              await utils.access.list.invalidate();
                            }}
                            className="rounded border border-border bg-card px-1.5 py-1 text-xs"
                          >
                            <option value="admin">Admin — full access</option>
                            <option value="auditor">Auditor — read only</option>
                            <option value="president">President — read only</option>
                          </select>
                        ) : (
                          <span className="text-xs">{ROLE_LABEL[m.role]}</span>
                        )}
                      </td>
                      <td className="tnum text-xs text-muted-foreground">
                        {fmtDate(String(m.createdAt).slice(0, 10))}
                      </td>
                      <td className="text-right">
                        {canWrite && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-destructive"
                            onClick={async () => {
                              if (!confirm(`Revoke ${m.email}'s access to this book?`)) return;
                              await remove.mutateAsync({ id: m.id });
                              await utils.access.list.invalidate();
                            }}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {canWrite && (
            <form onSubmit={submitInvite} className="mt-5 border-t border-border pt-4">
              <div className="mb-3 flex items-center gap-1.5 text-sm font-medium">
                <UserPlus className="h-4 w-4" /> Add someone
              </div>
              <div className="grid gap-3 sm:grid-cols-4">
                <div className="space-y-1.5">
                  <Label htmlFor="iname">Name</Label>
                  <Input
                    id="iname"
                    value={inv.name}
                    onChange={(e) => setInv({ ...inv, name: e.target.value })}
                    placeholder="Adeola Okafor"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="iemail">Email</Label>
                  <Input
                    id="iemail"
                    type="email"
                    value={inv.email}
                    onChange={(e) => setInv({ ...inv, email: e.target.value })}
                    placeholder="president@urpsa.test"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="irole">Role</Label>
                  <select
                    id="irole"
                    value={inv.role}
                    onChange={(e) => setInv({ ...inv, role: e.target.value as any })}
                    className="h-9 w-full rounded-md border border-border bg-card px-2 text-sm"
                  >
                    <option value="auditor">Auditor — read only</option>
                    <option value="president">President — read only</option>
                    <option value="admin">Admin — full access</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ipw">Temporary password</Label>
                  <Input
                    id="ipw"
                    type="text"
                    value={inv.password}
                    onChange={(e) => setInv({ ...inv, password: e.target.value })}
                    placeholder="At least 8 characters"
                    minLength={8}
                    required
                  />
                </div>
              </div>
              <p className="mt-2 text-[11px] text-muted-foreground">
                There is no email service, so you set a temporary password and hand it over. Ask
                them to change it from this page on first sign-in.
              </p>
              <div className="mt-3 flex flex-wrap items-center gap-3">
                <Button type="submit" size="sm" disabled={invite.isPending}>
                  {invite.isPending ? "Adding…" : "Add to this book"}
                </Button>
                {invMsg && (
                  <span className="max-w-xl text-xs font-medium text-favourable">{invMsg}</span>
                )}
              </div>
              {invErr ? (
                <div className="mt-3">
                  <ErrorBox error={invErr} />
                </div>
              ) : null}
            </form>
          )}
        </Panel>

        {/* ── Signup gate ──────────────────────────────────────────────────── */}
        <Panel>
          <SectionHead right={<ShieldCheck className="h-4 w-4 text-muted-foreground" />}>
            Public signup
          </SectionHead>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="max-w-xl">
              <p className="text-sm">
                {org.data?.allowPublicSignup
                  ? "Open — anyone who finds the URL can create an account."
                  : "Closed — only people you add above can sign in."}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                A stranger who signs up gets their own empty book, never this one. But an open
                signup form on a finance app is an invitation, so it is closed by default.
              </p>
            </div>
            {canWrite && (
              <Button
                size="sm"
                variant={org.data?.allowPublicSignup ? "outline" : "default"}
                disabled={setSignup.isPending}
                onClick={async () => {
                  await setSignup.mutateAsync({ allow: !org.data?.allowPublicSignup });
                  await utils.org.get.invalidate();
                }}
              >
                {org.data?.allowPublicSignup ? "Close signup" : "Open signup"}
              </Button>
            )}
          </div>
        </Panel>
      </div>

      {/* ── The printed sheet ────────────────────────────────────────────────
          Hidden on screen, revealed only for the print pass. It carries the
          codes and nothing else, so what comes out of the printer is a sheet
          to fold and keep with the books — not a screenshot of the app. */}
      {codes && (
        <div className="print-sheet">
          <div style={{ fontFamily: "Georgia, serif", color: "#000", maxWidth: "150mm" }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                borderBottom: "2px solid #000",
                paddingBottom: 8,
                marginBottom: 14,
              }}
            >
              {/* The printed sheet must carry the association's own crest: it is
                  a record to be filed with the books, and an unmarked sheet of
                  one-time codes is indistinguishable from anyone else's. */}
              <PrintMark org={org.data} mm={16} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 15, fontWeight: 700, letterSpacing: "0.02em" }}>
                  {org.data?.legalName ?? "Account recovery codes"}
                </div>
                <div style={{ fontSize: 10, marginTop: 2 }}>
                  {[org.data?.institution, org.data?.faculty].filter(Boolean).join(" · ")}
                </div>
                <div style={{ fontSize: 9, marginTop: 2, color: "#333" }}>
                  {[org.data?.shortName, org.data?.contactEmail, org.data?.contactPhone]
                    .filter(Boolean)
                    .join(" · ")}
                </div>
              </div>
            </div>

            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 4 }}>
              Account recovery codes
            </div>
            <div style={{ fontSize: 10, lineHeight: 1.5, marginBottom: 12 }}>
              For the account <strong>{me.data?.email}</strong>. Each code works once. Use one at
              the sign-in page → “Use a recovery code” if the password is lost. Keep this sheet
              with the association's books, not on a phone or in an email.
            </div>

            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
              <tbody>
                {codes.map((c, i) => (
                  <tr key={c}>
                    <td style={{ padding: "5px 0", width: 24, color: "#555" }}>{i + 1}.</td>
                    <td
                      style={{
                        padding: "5px 0",
                        fontFamily: "ui-monospace, Menlo, monospace",
                        letterSpacing: "0.12em",
                        fontSize: 13,
                      }}
                    >
                      {c}
                    </td>
                    <td style={{ padding: "5px 0", width: 60, color: "#555", fontSize: 9 }}>
                      ☐ used
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div
              style={{
                marginTop: 16,
                borderTop: "1px solid #999",
                paddingTop: 8,
                fontSize: 9,
                lineHeight: 1.5,
              }}
            >
              Issued {new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "long", year: "numeric" })}.
              Generating a new set later invalidates every code on this sheet. Only hashes are
              stored, so these cannot be recovered from the app — if the sheet is lost, generate a
              new set while still signed in.
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}