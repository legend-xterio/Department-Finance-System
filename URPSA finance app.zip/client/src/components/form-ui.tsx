import { type ReactNode, useEffect, useId, useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { X, Loader2, Check, Upload } from "lucide-react";

/* ─────────────────────────────────────────────────────────────────────────────
   Form primitives for the editors.

   These deliberately wrap the raw <input> rather than introduce a form library:
   the app already has a dense, ledger-first look, and a modal that respects it
   is a dozen lines. Everything here is controlled — the parent owns the state.
   ───────────────────────────────────────────────────────────────────────────── */

/* ── Modal ────────────────────────────────────────────────────────────────── */
export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  width = "md",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
  width?: "sm" | "md" | "lg";
}) {
  // Escape closes — a modal a keyboard user cannot dismiss is a trap.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  const w = width === "sm" ? "max-w-md" : width === "lg" ? "max-w-3xl" : "max-w-xl";

  return (
    <div className="no-print fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-foreground/40 p-4 sm:p-8">
      <div
        className="absolute inset-0"
        onClick={onClose}
        aria-hidden
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cn(
          "relative z-10 my-auto w-full rounded-lg border border-border bg-card shadow-xl",
          w,
        )}
      >
        <div className="flex items-start justify-between border-b border-border px-5 py-4">
          <div>
            <h2 className="text-sm font-semibold tracking-tight">{title}</h2>
            {description && (
              <p className="mt-0.5 text-xs text-muted-foreground">{description}</p>
            )}
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="rounded p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="px-5 py-4">{children}</div>
        {footer && (
          <div className="flex items-center justify-end gap-2 border-t border-border px-5 py-3">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Field wrapper: a label, the control, and a hint or error ─────────────── */
export function Field({
  label,
  hint,
  error,
  required,
  children,
  className,
}: {
  label: string;
  hint?: string;
  error?: string | null;
  required?: boolean;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      <span className="label-cap">
        {label}
        {required && <span className="ml-0.5 text-destructive">*</span>}
      </span>
      <div className="mt-1">{children}</div>
      {error ? (
        <span className="mt-1 block text-[11px] text-destructive">{error}</span>
      ) : hint ? (
        <span className="mt-1 block text-[11px] text-muted-foreground">{hint}</span>
      ) : null}
    </label>
  );
}

const controlClass =
  "w-full rounded-md border border-input bg-background px-2.5 py-1.5 text-sm outline-none transition-colors focus:border-primary focus:ring-1 focus:ring-primary/30 disabled:cursor-not-allowed disabled:opacity-60";

export function TextInput({
  value,
  onChange,
  placeholder,
  type = "text",
  disabled,
  autoFocus,
  step,
  min,
  max,
  className,
}: {
  value: string | number;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  disabled?: boolean;
  autoFocus?: boolean;
  step?: string;
  min?: string | number;
  max?: string | number;
  className?: string;
}) {
  return (
    <input
      className={cn(controlClass, type === "number" && "tnum", className)}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      type={type}
      disabled={disabled}
      autoFocus={autoFocus}
      step={step}
      min={min}
      max={max}
    />
  );
}

export function TextArea({
  value,
  onChange,
  placeholder,
  rows = 3,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  rows?: number;
}) {
  return (
    <textarea
      className={cn(controlClass, "resize-y")}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      rows={rows}
    />
  );
}

export function Select({
  value,
  onChange,
  options,
  placeholder,
  disabled,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string; group?: string }[];
  placeholder?: string;
  disabled?: boolean;
}) {
  // Grouping keeps a 20-account dropdown readable without truncating labels.
  const groups = new Map<string, { value: string; label: string }[]>();
  for (const o of options) {
    const g = o.group ?? "";
    if (!groups.has(g)) groups.set(g, []);
    groups.get(g)!.push({ value: o.value, label: o.label });
  }
  const grouped = [...groups.keys()].some((g) => g !== "");

  return (
    <select
      className={cn(controlClass, "pr-7")}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled}
    >
      <option value="">{placeholder ?? "Select…"}</option>
      {grouped
        ? [...groups.entries()].map(([g, opts]) => (
            <optgroup key={g || "_"} label={g || "Other"}>
              {opts.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </optgroup>
          ))
        : options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
    </select>
  );
}

/* ── Money input: keeps the raw string, exposes a parsed number ──────────── */
export function MoneyInput({
  value,
  onChange,
  placeholder = "0.00",
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div className="relative">
      <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
        ₦
      </span>
      <input
        className={cn(controlClass, "tnum pl-6 text-right")}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        inputMode="decimal"
      />
    </div>
  );
}

export const parseMoney = (s: string): number => {
  const n = Number(String(s).replace(/[₦,\s]/g, ""));
  return Number.isFinite(n) ? n : 0;
};

/* ── Submit button with in-flight state ──────────────────────────────────── */
export function SubmitBtn({
  label,
  busy,
  disabled,
  onClick,
  variant = "default",
}: {
  label: string;
  busy?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  variant?: "default" | "outline" | "destructive";
}) {
  return (
    <Button variant={variant} size="sm" disabled={busy || disabled} onClick={onClick} type="button">
      {busy && <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />}
      {label}
    </Button>
  );
}

/* ── Small ghost action used in table rows ───────────────────────────────── */
export function RowAction({
  children,
  onClick,
  tone = "default",
  title,
  disabled,
}: {
  children: ReactNode;
  onClick: () => void;
  tone?: "default" | "danger";
  title?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "no-print inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] font-medium transition-colors",
        disabled && "cursor-not-allowed opacity-40",
        tone === "danger"
          ? "text-destructive hover:bg-destructive/10"
          : "text-muted-foreground hover:bg-muted hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}

/* ── Confirm-before-destroy ──────────────────────────────────────────────── */
export function ConfirmDialog({
  open,
  title,
  body,
  confirmLabel = "Delete",
  busy,
  onConfirm,
  onClose,
  danger = true,
}: {
  open: boolean;
  title: string;
  body: string;
  confirmLabel?: string;
  busy?: boolean;
  onConfirm: () => void;
  onClose: () => void;
  danger?: boolean;
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      width="sm"
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} disabled={busy}>
            Cancel
          </Button>
          <Button
            variant={danger ? "destructive" : "default"}
            size="sm"
            onClick={onConfirm}
            disabled={busy}
          >
            {busy && <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />}
            {confirmLabel}
          </Button>
        </>
      }
    >
      <p className="text-sm text-muted-foreground">{body}</p>
    </Modal>
  );
}

/* ── Inline status line for a mutation's error ───────────────────────────── */
export function FormError({ error }: { error: unknown }) {
  if (!error) return null;
  const msg = error instanceof Error ? error.message : "Something went wrong.";
  return (
    <div className="rounded-md border border-destructive/30 bg-destructive/5 px-3 py-2 text-xs text-destructive">
      {msg}
    </div>
  );
}

/* ── Toast: a mutation's success is otherwise invisible in a table ───────── */
export function useToast() {
  const [msg, setMsg] = useState<string | null>(null);
  useEffect(() => {
    if (!msg) return;
    const t = setTimeout(() => setMsg(null), 3500);
    return () => clearTimeout(t);
  }, [msg]);
  const node = msg ? (
    <div className="no-print fixed bottom-5 left-1/2 z-[60] flex -translate-x-1/2 items-center gap-2 rounded-md bg-foreground px-3 py-2 text-xs font-medium text-background shadow-lg">
      <Check className="h-3.5 w-3.5" />
      {msg}
    </div>
  ) : null;
  return { toast: setMsg, toastNode: node };
}

/* ── An expandable row section (used by the budget drill-down) ───────────── */
export function Disclosure({
  open,
  onToggle,
  children,
}: {
  open: boolean;
  onToggle: () => void;
  children: ReactNode;
}) {
  return (
    <>
      <tr
        className="cursor-pointer select-none"
        onClick={onToggle}
        aria-expanded={open}
      >
        {children}
      </tr>
    </>
  );
}

/* Stable ids for label/input pairing when a form has repeated fields. */
export function useFieldId(prefix: string) {
  const id = useId();
  return `${prefix}-${id}`;
}

/* ── Evidence attachment ───────────────────────────────────────────────────── */

function errText(e: unknown) {
  if (e instanceof Error) return e.message;
  const m = (e as any)?.message;
  return typeof m === "string" ? m : "Something went wrong.";
}

/**
 * The receipt picker every money-moving form needs. It says plainly when the
 * amount is above the threshold and nothing is attached — exactly the case the
 * posting engine refuses — rather than letting the save fail with a server error.
 */
export function EvidenceField({
  uploading,
  fileName,
  needsEvidence,
  threshold,
  onFile,
  error,
}: {
  uploading: boolean;
  fileName: string | null;
  needsEvidence: boolean;
  threshold: number;
  onFile: (f: File) => void;
  error?: unknown;
}) {
  const missing = needsEvidence && !fileName;
  return (
    <div
      className={cn(
        "rounded-md border p-3",
        missing ? "border-warn/40 bg-warn-bg/40" : "border-border bg-muted/30",
      )}
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="text-xs font-medium">
            Evidence{" "}
            {missing ? (
              <span className="text-warn">
                · required above ₦{threshold.toLocaleString()}
              </span>
            ) : (
              <span className="text-muted-foreground">· optional</span>
            )}
          </div>
          <div className="text-[11px] text-muted-foreground">
            {missing
              ? "The posting engine will refuse this entry until a document is attached."
              : "Attach the receipt or invoice. It is stored against the entry."}
          </div>
        </div>
        {fileName ? (
          <span className="inline-flex max-w-[14rem] items-center gap-1.5 truncate rounded-full bg-favourable-bg px-2.5 py-1 text-xs font-medium text-favourable">
            <Check className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">{fileName}</span>
          </span>
        ) : (
          <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-md border border-border bg-card px-2.5 py-1.5 text-xs font-medium hover:bg-muted">
            <Upload className="h-3.5 w-3.5" />
            {uploading ? "Uploading…" : "Attach document"}
            <input
              type="file"
              className="hidden"
              accept="image/*,application/pdf"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onFile(f);
              }}
            />
          </label>
        )}
      </div>
      {error ? <div className="mt-2 text-xs text-negative">{errText(error)}</div> : null}
    </div>
  );
}
