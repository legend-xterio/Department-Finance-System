// Pins the branding contract. The crest is a fixed image asset, so the things
// that can silently break are structural: the file disappearing from public/,
// a page falling back to a hardcoded "UR" square, the print sheet losing its
// mark, or a plate being drawn on the teal login panel (where the crest's white
// disc would otherwise have nothing to sit on).
//
// Static analysis, like App.routes.test.ts — vitest runs in node here on purpose.
import { existsSync, readFileSync, statSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const APP_ROOT = path.resolve(import.meta.dirname, "../..");
const PUBLIC = path.join(APP_ROOT, "public");
const CLIENT_SRC = path.resolve(import.meta.dirname, "..");

const read = (rel: string) => readFileSync(path.join(CLIENT_SRC, rel), "utf-8");
const shell = read("components/AppShell.tsx");
const login = read("pages/Login.tsx");
const reports = read("pages/Reports.tsx");
const security = read("pages/Security.tsx");
const brand = read("components/BrandMark.tsx");
const indexHtml = readFileSync(path.join(APP_ROOT, "index.html"), "utf-8");

describe("brand assets", () => {
  it("ships the crest at every size the app asks for", () => {
    for (const f of [
      "brand/urpsa-crest.png",
      "brand/urpsa-crest-256.png",
      "brand/urpsa-crest-print.png",
      "brand/apple-touch-icon.png",
      "brand/og-image.png",
      "favicon.ico",
      "favicon.png",
      "favicon-32.png",
      "favicon-180.png",
    ]) {
      const p = path.join(PUBLIC, f);
      expect(existsSync(p), `${f} must exist in client/public`).toBe(true);
      // A zero-byte or truncated asset renders as a broken image everywhere.
      expect(statSync(p).size, `${f} must not be empty`).toBeGreaterThan(1000);
    }
  });

  it("keeps the crest square and undistorted", () => {
    // Both the sidebar box and the <img> must be square with object-contain:
    // a stretched circle is the one thing a crest must never do.
    expect(brand).toMatch(/object-contain/);
    expect(brand).toMatch(/width=\{512\}/);
    expect(brand).toMatch(/height=\{512\}/);
  });

  it("declares a favicon and an opaque iOS icon in the document head", () => {
    expect(indexHtml).toMatch(/rel="icon"[^>]*favicon\.ico/);
    expect(indexHtml).toMatch(/rel="apple-touch-icon"/);
    expect(indexHtml).toMatch(/theme-color/);
  });
});

describe("crest placement", () => {
  it("opens with a <link rel=icon> before any script", () => {
    // A favicon declared after the module script still works, but the browser
    // fetches it late and the tab flashes a blank page icon on first paint.
    expect(indexHtml.indexOf('rel="icon"')).toBeLessThan(indexHtml.indexOf("<script"));
  });

  it("renders the crest in the sidebar instead of an initials square", () => {
    expect(shell).toMatch(/<BrandMark/);
    expect(shell).not.toMatch(/font-bold text-primary-foreground">\s*\{mark\}/);
  });

  it("plates the crest on the teal sign-in panel", () => {
    // plate="always" is load-bearing on bg-primary: the crest's interior disc
    // is white, so bare it reads as a bright coin on the panel.
    expect(login).toMatch(/<BrandMark[^>]*plate="always"/);
  });

  it("gives no page a hardcoded 'UR' placeholder mark", () => {
    for (const [name, src] of Object.entries({ shell, login, reports, security })) {
      expect(src, `${name} must not hardcode an initials square`).not.toMatch(
        />\s*UR\s*</,
      );
    }
  });

  it("puts the crest on printed statements and the recovery-code sheet", () => {
    // Print media gets the 900px copy: the 512px screen file smears at 15mm.
    expect(reports).toMatch(/<PrintMark/);
    expect(security).toMatch(/<PrintMark/);
    expect(brand).toMatch(/urpsa-crest-print\.png/);
  });
});

describe("fallback", () => {
  it("swaps to the initials mark when the image fails", () => {
    // The fallback is the whole reason a missing asset cannot leave a hole in
    // the header; it must be wired to onError, not merely declared.
    expect(brand).toMatch(/onError=\{\(\) => setFailed\(true\)\}/);
    expect(brand).toMatch(/if \(failed\)/);
    expect(brand).toMatch(/orgInitials/);
  });
});
