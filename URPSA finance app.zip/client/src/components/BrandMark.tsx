import { useState } from "react";
import { cn } from "@/lib/utils";
import { orgInitials, type OrgIdentity } from "@shared/org-display";

/**
 * The association's crest, in one place.
 *
 * The logo is a photographic-grade crest: a circular ring of set text around a
 * shield. Two facts about it drive the treatment here:
 *
 *  1. Its background is genuinely transparent (the corners are alpha 0), but the
 *     disc INSIDE the ring is white. Dropped straight onto the deep-teal sidebar
 *     the white disc reads as a bright coin floating on the panel, and the
 *     anti-aliased edge picks up a pale fringe. So on any surface that is not
 *     already white, the crest sits on its own white plate with a hairline ring —
 *     it then looks like a deliberate badge rather than a stray rectangle.
 *
 *  2. At 32px the wording around the ring is a texture, not language. That is
 *     expected for a crest and it is why the name is always set as real text
 *     next to the mark, never left to the logo to carry.
 *
 * If the file is missing or the request fails, the mark falls back to the
 * initials square it replaced, so a broken asset never leaves a hole in the
 * header. `onError` fires once and disables further retries — a cache-busting
 * loop of failing image requests is worse than a fallback.
 */

const SRC = "/brand/urpsa-crest.png";

type Size = "sm" | "md" | "lg" | "xl" | "2xl";

/**
 * Sizes are chosen against one measured fact: the ring of set text around the
 * crest is 10.5% of the image's diameter (measured on the 512px source — the
 * glyphs are 54px tall in a 512px circle). So the cap height a reader actually
 * gets is:
 *
 *     28px → 2.9px   36px → 3.8px   48px → 5.0px
 *     64px → 6.7px   96px → 10.1px  128px → 13.4px
 *
 * Below ~7px a glyph is a smudge, so the ring is texture, not language. 96px is
 * the smallest size at which the wording can be read at all, and it is what the
 * sidebar uses. 128px would be comfortably readable but eats a third of the
 * rail's height, so it is reserved for the sign-in panel and print.
 */
const BOX: Record<Size, string> = {
  sm: "h-7 w-7",
  md: "h-9 w-9",
  lg: "h-12 w-12",
  xl: "h-16 w-16",
  "2xl": "h-24 w-24",
};

const PAD: Record<Size, string> = {
  sm: "p-[2px]",
  md: "p-[3px]",
  lg: "p-1",
  xl: "p-1.5",
  "2xl": "p-2",
};

export function BrandMark({
  org,
  size = "md",
  plate = "auto",
  className,
  alt,
}: {
  org?: OrgIdentity | null;
  size?: Size;
  /**
   * `auto` plates on any non-white surface, `always` forces the plate,
   * `never` draws the crest bare (use on white paper only).
   */
  plate?: "auto" | "always" | "never";
  className?: string;
  alt?: string;
}) {
  const [failed, setFailed] = useState(false);
  const label = alt ?? org?.shortName?.trim() ?? "Association crest";

  if (failed) {
    const initials = orgInitials(org);
    return (
      <div
        className={cn(
          "flex shrink-0 items-center justify-center rounded-md bg-primary font-bold text-primary-foreground",
          BOX[size],
          size === "sm"
            ? "text-[10px]"
            : size === "md"
              ? "text-[11px]"
              : size === "2xl"
                ? "text-2xl"
                : "text-sm",
          className,
        )}
        aria-label={label}
        role="img"
      >
        {initials}
      </div>
    );
  }

  const img = (
    <img
      src={SRC}
      alt={label}
      width={512}
      height={512}
      decoding="async"
      // The crest is above the fold on every page; it should not pop in.
      loading="eager"
      onError={() => setFailed(true)}
      className={cn("h-full w-full object-contain", plate === "never" ? "" : "rounded-[3px]")}
    />
  );

  if (plate === "never") {
    return <div className={cn("shrink-0", BOX[size], className)}>{img}</div>;
  }

  return (
    <div
      className={cn(
        "flex shrink-0 items-center justify-center rounded-md bg-white ring-1 ring-black/[0.06]",
        plate === "always" && "shadow-[0_1px_2px_rgba(16,32,32,0.10)]",
        BOX[size],
        PAD[size],
        className,
      )}
    >
      {img}
    </div>
  );
}

/**
 * The crest at print resolution for a letterhead — 900px source, sized in mm so
 * it is a real physical size on paper rather than a shrunken screen px value.
 */
export function PrintMark({ org, mm = 16 }: { org?: OrgIdentity | null; mm?: number }) {
  const [failed, setFailed] = useState(false);
  if (failed) return null;
  return (
    <img
      src="/brand/urpsa-crest-print.png"
      alt={org?.shortName?.trim() || "Association crest"}
      onError={() => setFailed(true)}
      style={{ width: `${mm}mm`, height: `${mm}mm`, objectFit: "contain" }}
    />
  );
}
