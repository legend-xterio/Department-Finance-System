import { type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { ngn, ngnCompact } from "@shared/finance";
import { AlertTriangle, CheckCircle2 } from "lucide-react";

/* ── KPI card: one large figure, a muted caption, an optional delta ────────── */
export function Kpi({
  label,
  value,
  caption,
  tone = "default",
  compact = true,
}: {
  label: string;
  value: string | number;
  caption?: string;
  tone?: "default" | "positive" | "negative" | "accent";
  compact?: boolean;
}) {
  const toneClass =
    tone === "positive"
      ? "text-favourable"
      : tone === "negative"
        ? "text-adverse"
        : tone === "accent"
          ? "text-accent-foreground"
          : "text-foreground";
  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-[0_1px_2px_rgba(16,24,40,0.04)]">
      <div className="label-cap">{label}</div>
      <div className={cn("tnum mt-2 text-2xl font-semibold tracking-tight", toneClass)}>
        {compact && typeof value === "number" ? ngnCompact(value) : value}
      </div>
      {caption && <div className="mt-1 text-xs text-muted-foreground">{caption}</div>}
    </div>
  );
}

/* ── Variance pill: green favourable / rose adverse, never colour-only ────── */
export function VariancePill({
  amount,
  label,
}: {
  amount: number;
  label?: string;
}) {
  const positive = amount > 0.005;
  const neutral = Math.abs(amount) <= 0.005;
  return (
    <span
      className={cn(
        "tnum inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium",
        neutral
          ? "bg-muted text-muted-foreground"
          : positive
            ? "bg-favourable-bg text-favourable"
            : "bg-adverse-bg text-adverse",
      )}
    >
      {label ? `${label} · ` : ""}
      {amount > 0 ? "+" : ""}
      {ngn(Math.abs(amount) === 0 ? 0 : amount)}
    </span>
  );
}

/* ── Fund restriction chip ───────────────────────────────────────────────── */
export function FundChip({ restriction }: { restriction: string }) {
  const map: Record<string, string> = {
    unrestricted: "bg-secondary text-secondary-foreground",
    restricted: "bg-warn-bg text-warn",
    designated: "bg-accent/15 text-accent-foreground",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
        map[restriction] ?? "bg-muted text-muted-foreground",
      )}
    >
      {restriction}
    </span>
  );
}

/* ── Control-check strip: turns amber the moment a ledger control fails ──── */
export function ControlStrip({
  checks,
  compact = false,
}: {
  checks: { key: string; label: string; ok: boolean; detail: string }[];
  compact?: boolean;
}) {
  const failing = checks.filter((c) => !c.ok);
  const allOk = failing.length === 0;
  return (
    <div
      className={cn(
        "rounded-lg border p-3",
        allOk ? "border-border bg-card" : "border-warn/40 bg-warn-bg",
      )}
    >
      <div className="flex flex-wrap items-center gap-2">
        {allOk ? (
          <CheckCircle2 className="h-4 w-4 text-favourable" />
        ) : (
          <AlertTriangle className="h-4 w-4 text-warn" />
        )}
        <span className="text-sm font-medium">
          {allOk ? "All controls passing" : `${failing.length} control${failing.length === 1 ? "" : "s"} need attention`}
        </span>
        <span className="text-xs text-muted-foreground">
          {allOk ? `${checks.length} checks` : failing.map((f) => f.label).join(" · ")}
        </span>
      </div>
      {!compact && (
        <div className="mt-3 grid gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
          {checks.map((c) => (
            <div key={c.key} className="flex items-start gap-1.5 text-xs">
              <span
                className={cn(
                  "mt-1 h-1.5 w-1.5 shrink-0 rounded-full",
                  c.ok ? "bg-favourable" : "bg-warn",
                )}
              />
              <div>
                <div className={c.ok ? "text-muted-foreground" : "font-medium text-foreground"}>
                  {c.label}
                </div>
                <div className="tnum text-[11px] text-muted-foreground/80">{c.detail}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Empty state: every list explains itself and names the action ────────── */
export function EmptyState({
  icon,
  title,
  body,
  action,
}: {
  icon?: ReactNode;
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border bg-card/60 px-6 py-14 text-center">
      {icon && <div className="mb-3 text-muted-foreground">{icon}</div>}
      <h3 className="text-sm font-semibold">{title}</h3>
      <p className="mt-1 max-w-md text-sm text-muted-foreground">{body}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

/* ── Section heading ─────────────────────────────────────────────────────── */
export function SectionHead({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-3 flex items-end justify-between">
      <h2 className="text-sm font-semibold tracking-tight">{children}</h2>
      {right}
    </div>
  );
}

export function Panel({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("rounded-lg border border-border bg-card p-4", className)}>{children}</div>
  );
}

export function Loading({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 px-1 py-10 text-sm text-muted-foreground">
      <span className="h-3 w-3 animate-pulse rounded-full bg-primary/50" />
      {label}
    </div>
  );
}

/**
 * A tRPC error's `message` is often just the code ("NOT_FOUND"), which reads
 * like a crash to a treasurer. Map the codes we actually raise to a sentence,
 * and keep any real message the server wrote.
 */
function readableError(error: unknown): string {
  if (!error) return "Something went wrong.";
  const e = error as { message?: string; data?: { code?: string } };
  const code = e.data?.code;
  const msg = e.message ?? "";
  const isBareCode = !msg || /^[A-Z_]+$/.test(msg);
  if (isBareCode) {
    switch (code ?? msg) {
      case "NOT_FOUND":
        return "That record no longer exists — it may have been deleted. Go back and pick another.";
      case "UNAUTHORIZED":
        return "Your session has expired. Sign in again to continue.";
      case "FORBIDDEN":
        return "You do not have access to that record.";
      case "PRECONDITION_FAILED":
        return "That action is not allowed in the current state of the books.";
      case "BAD_REQUEST":
        return "That request was not valid. Check the values and try again.";
      default:
        return "Something went wrong. Try again, and if it persists check the app logs.";
    }
  }
  return msg;
}

export function ErrorBox({ error }: { error: unknown }) {
  return (
    <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
      {readableError(error)}
    </div>
  );
}
