// Guards the sidebar's shape. The complaint that produced this restructure was
// "too many top-level items" — a wall of twelve links. Nothing in the type
// system stops the next change from adding a thirteenth, so this pins the
// contract: a short daily-use rail, registers in one group, and every
// administrative page reachable as a Settings tab rather than a nav link.
//
// Static analysis, like App.routes.test.ts: vitest runs in a node environment
// here and jsdom is deliberately not a dependency.
import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const CLIENT_SRC = path.resolve(import.meta.dirname, "..");
const SHELL = path.join(CLIENT_SRC, "components", "AppShell.tsx");
const SETTINGS = path.join(CLIENT_SRC, "pages", "Settings.tsx");
const APP = path.join(CLIENT_SRC, "App.tsx");

const shellSrc = readFileSync(SHELL, "utf-8");
const settingsSrc = readFileSync(SETTINGS, "utf-8");
const appSrc = readFileSync(APP, "utf-8");

/** Every `href: "/x"` inside the GROUPS literal — the sidebar's own links. */
function navHrefs(src: string): string[] {
  const start = src.indexOf("const GROUPS");
  const end = src.indexOf("const ROLE_LABEL");
  const block = src.slice(start, end);
  return [...block.matchAll(/href:\s*"([^"]+)"/g)].map((m) => m[1]);
}

/** The Settings tab keys, in declaration order. */
function tabKeys(src: string): string[] {
  const start = src.indexOf("const GROUPS");
  const end = src.indexOf("const ALL_TABS");
  const block = src.slice(start, end);
  return [...block.matchAll(/key:\s*"([^"]+)"/g)].map((m) => m[1]);
}

describe("sidebar structure", () => {
  it("keeps the top-level rail short", () => {
    const hrefs = navHrefs(shellSrc);
    // Dashboard, Transactions, Reports + the four registers + Settings.
    expect(hrefs.length, `Sidebar links: ${hrefs.join(" ")}`).toBeLessThanOrEqual(8);
  });

  it("keeps only daily-use pages at the top level", () => {
    const hrefs = navHrefs(shellSrc);
    for (const daily of ["/", "/transactions", "/reports"]) {
      expect(hrefs, `${daily} must stay in the sidebar`).toContain(daily);
    }
  });

  it("does not put administrative pages back in the sidebar", () => {
    const hrefs = navHrefs(shellSrc);
    const admin = ["/security", "/reconciliation", "/change-log", "/backup"];
    const leaked = admin.filter((h) => hrefs.includes(h));
    expect(
      leaked,
      `These are Settings tabs now — a sidebar link duplicates them:\n  ${leaked.join("\n  ")}`,
    ).toEqual([]);
  });

  it("groups the registers under one heading", () => {
    expect(shellSrc).toMatch(/title:\s*"Registers"/);
  });

  it("nests the five reports under the Reports entry", () => {
    const start = shellSrc.indexOf("const REPORT_CHILDREN");
    const end = shellSrc.indexOf("const GROUPS");
    const children = [...shellSrc.slice(start, end).matchAll(/href:\s*"([^"]+)"/g)].map(
      (m) => m[1],
    );
    expect(children).toHaveLength(5);
    for (const c of children) expect(c.startsWith("/reports?r=")).toBe(true);
  });
});

describe("settings tabs", () => {
  it("covers every administrative page", () => {
    const keys = tabKeys(settingsSrc);
    for (const k of [
      "organisation",
      "opening",
      "accounts",
      "periods",
      "reconciliation",
      "security",
      "backup",
      "change-log",
    ]) {
      expect(keys, `Settings is missing the ${k} tab`).toContain(k);
    }
  });

  it("groups the tabs rather than listing them flat", () => {
    const groups = [...settingsSrc.matchAll(/title:\s*"([^"]+)"/g)].map((m) => m[1]);
    expect(groups).toEqual(["Book setup", "Controls", "Access & audit"]);
  });

  it("renders a body for every tab key", () => {
    const keys = tabKeys(settingsSrc);
    const missing = keys.filter((k) => !settingsSrc.includes(`tab === "${k}"`));
    expect(missing, `Tabs with no body: ${missing.join(", ")}`).toEqual([]);
  });
});

describe("old URLs still resolve", () => {
  it("redirects every moved page into its Settings tab", () => {
    const moved: [string, string][] = [
      ["/security", "security"],
      ["/reconciliation", "reconciliation"],
      ["/change-log", "change-log"],
      ["/backup", "backup"],
    ];
    for (const [route, tab] of moved) {
      expect(appSrc, `${route} must still be a route`).toContain(`path="${route}"`);
      expect(appSrc, `${route} must redirect to the ${tab} tab`).toContain(
        `<ToSettingsTab tab="${tab}" />`,
      );
    }
  });
});
