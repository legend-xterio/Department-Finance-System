import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  ArrowLeftRight,
  Target,
  Handshake,
  Boxes,
  FileBarChart2,
  Settings as SettingsIcon,
  LogOut,
  Users,
  ChevronDown,
  Menu,
  X,
  Lock,
} from "lucide-react";
import { useAuth } from "@/_core/useAuth";
import { trpc } from "@/_core/trpc";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { orgTitle, currencySymbol } from "@shared/org-display";
import { BrandMark } from "@/components/BrandMark";
import { setCurrencySymbol } from "@shared/finance";
import { roleFlags } from "@/lib/roles";

/**
 * The sidebar is deliberately short: three daily-use destinations, one
 * collapsible group of registers, and Settings. Everything administrative lives
 * inside Settings as a tab, so the nav reads as a handful of groups rather than
 * a wall of links.
 */
type NavChild = { href: string; label: string };
type NavItem = { href: string; label: string; icon: typeof LayoutDashboard; children?: NavChild[] };
type NavGroup = { title?: string; items: NavItem[] };

const REPORT_CHILDREN: NavChild[] = [
  { href: "/reports?r=ie", label: "Income & Expenditure" },
  { href: "/reports?r=position", label: "Financial Position" },
  { href: "/reports?r=cashflow", label: "Cash Flows" },
  { href: "/reports?r=trial", label: "Trial Balance" },
  { href: "/reports?r=controls", label: "Control Checks" },
];

const GROUPS: NavGroup[] = [
  {
    items: [
      { href: "/", label: "Dashboard", icon: LayoutDashboard },
      { href: "/transactions", label: "Transactions", icon: ArrowLeftRight },
      { href: "/reports", label: "Reports", icon: FileBarChart2, children: REPORT_CHILDREN },
    ],
  },
  {
    title: "Registers",
    items: [
      { href: "/members", label: "Members & dues", icon: Users },
      { href: "/sponsorship", label: "Sponsors", icon: Handshake },
      { href: "/registers", label: "Assets & liabilities", icon: Boxes },
      { href: "/budget", label: "Budgets", icon: Target },
    ],
  },
];

const ROLE_LABEL: Record<string, string> = {
  treasurer: "Treasurer",
  admin: "Administrator",
  auditor: "Auditor",
  president: "President",
};

function isActive(path: string, href: string) {
  if (href === "/") return path === "/";
  const base = href.split("?")[0];
  return path === base || path.startsWith(base + "/");
}

/** Nested AppShells (a page embedded as a Settings tab) render only their body. */
const ShellContext = createContext(false);

export function AppShell({
  title,
  subtitle,
  actions,
  children,
}: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  children: ReactNode;
}) {
  const [path] = useLocation();
  const { user, logout } = useAuth();
  const nested = useContext(ShellContext);
  const [drawer, setDrawer] = useState(false);
  // Reports and Registers start expanded so nothing is hidden on first visit;
  // the treasurer can collapse either to shorten the rail further.
  const [open, setOpen] = useState<Record<string, boolean>>({ Reports: true, Registers: true });

  // The association's identity is editable in Settings, so the header reads it
  // from the org row rather than hardcoding a name that can go stale.
  const org = trpc.org.get.useQuery(undefined, { staleTime: 60_000 });
  // The book role lives on the membership row, not on the user, so the shell
  // reads it from the access router — that is what the server enforces.
  const access = trpc.access.list.useQuery(undefined, { staleTime: 60_000 });
  const name = org.data?.shortName?.trim() || "URPSA";
  const fullName = orgTitle(org.data);

  // The base currency is editable in Settings, so every amount on every page
  // must render in it. Setting it here — once, in the shell that wraps every
  // signed-in page — is what keeps a dollar book from showing ₦.
  useEffect(() => {
    setCurrencySymbol(currencySymbol(org.data?.baseCurrency));
  }, [org.data?.baseCurrency]);

  const role: string = access.data?.myRole ?? "treasurer";
  const { canEnterRegisters, canManageBook } = roleFlags(role);
  // The banner is for a role that may not enter anything at all. An auditor CAN
  // now post to the registers, so telling them "read-only" would be a lie — they
  // get a narrower notice instead (see below).
  const readOnly = !canEnterRegisters;

  // Close the drawer whenever the route changes.
  useEffect(() => {
    setDrawer(false);
  }, [path]);

  // A page embedded as a Settings tab keeps its own heading and actions, but
  // must not draw a second sidebar.
  if (nested) {
    return (
      <div className="space-y-4">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h2 className="text-base font-semibold tracking-tight">{title}</h2>
            {subtitle && <p className="mt-0.5 text-xs text-muted-foreground">{subtitle}</p>}
          </div>
          {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
        </div>
        {children}
      </div>
    );
  }

  const nav = (
    <>
      {/* The crest is 96px, not 36px, because the ring of set text around it is
          only 10.5% of the image's diameter: at 36px each glyph is 3.8px tall,
          which is a smudge. At 96px it is 10.1px — the smallest size at which
          the wording can actually be read. That is too wide to sit beside the
          name in a 240px rail, so the header stacks: crest centred, name under
          it. The rail keeps its width and the nav keeps its room. */}
      <div className="flex flex-col items-center gap-2 px-4 pb-3 pt-4 text-center">
        <BrandMark org={org.data} size="2xl" plate="always" />
        <div className="min-w-0 leading-tight">
          <div className="truncate text-sm font-semibold">{name} Finance</div>
          <div className="truncate text-[11px] text-muted-foreground" title={fullName}>
            {org.data?.institution?.trim() || "Treasurer's ledger"}
          </div>
        </div>
      </div>

      <nav className="flex-1 space-y-3 overflow-y-auto px-2.5 pb-2">
        {GROUPS.map((group, gi) => (
          <div key={group.title ?? `g${gi}`} className="space-y-0.5">
            {group.title && (
              <div className="px-2.5 pb-1 pt-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
                {group.title}
              </div>
            )}
            {group.items.map((item) => {
              const active = isActive(path, item.href);
              const Icon = item.icon;
              const hasChildren = !!item.children?.length;
              const expanded = open[item.label] ?? false;
              return (
                <div key={item.href}>
                  <div className="flex items-center">
                    <Link
                      href={item.href}
                      className={cn(
                        "flex min-w-0 flex-1 items-center gap-2.5 rounded-md px-2.5 py-2 text-sm transition-colors",
                        active
                          ? "bg-secondary font-medium text-secondary-foreground"
                          : "text-muted-foreground hover:bg-muted hover:text-foreground",
                      )}
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </Link>
                    {hasChildren && (
                      <button
                        type="button"
                        aria-label={expanded ? `Collapse ${item.label}` : `Expand ${item.label}`}
                        aria-expanded={expanded}
                        onClick={() => setOpen((o) => ({ ...o, [item.label]: !expanded }))}
                        className="ml-0.5 rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
                      >
                        <ChevronDown
                          className={cn("h-3.5 w-3.5 transition-transform", expanded && "rotate-180")}
                        />
                      </button>
                    )}
                  </div>
                  {hasChildren && expanded && (
                    <div className="mb-1 ml-4 mt-0.5 space-y-0.5 border-l border-border pl-2">
                      {item.children!.map((child) => {
                        const childKey = new URLSearchParams(child.href.split("?")[1]).get("r");
                        const childActive =
                          path === "/reports" &&
                          new URLSearchParams(window.location.search).get("r") === childKey;
                        return (
                          <Link
                            key={child.href}
                            href={child.href}
                            className={cn(
                              "block truncate rounded px-2 py-1.5 text-[13px] transition-colors",
                              childActive
                                ? "bg-secondary/70 font-medium text-secondary-foreground"
                                : "text-muted-foreground hover:bg-muted hover:text-foreground",
                            )}
                          >
                            {child.label}
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}

        <div className="border-t border-border pt-2">
          <Link
            href="/settings"
            className={cn(
              "flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm transition-colors",
              isActive(path, "/settings")
                ? "bg-secondary font-medium text-secondary-foreground"
                : "text-muted-foreground hover:bg-muted hover:text-foreground",
            )}
          >
            <SettingsIcon className="h-4 w-4 shrink-0" />
            Settings
          </Link>
        </div>
      </nav>

      <div className="border-t border-border p-3">
        <div className="mb-2 px-1.5">
          <div className="truncate text-xs font-medium">{user?.name ?? user?.email}</div>
          <div className="label-cap">{ROLE_LABEL[role] ?? role}</div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start gap-2 text-muted-foreground"
          onClick={() => logout()}
        >
          <LogOut className="h-3.5 w-3.5" />
          Sign out
        </Button>
      </div>
    </>
  );

  return (
    <ShellContext.Provider value={true}>
      <div className="min-h-screen bg-background">
        <div className="flex">
          {/* Sidebar — short, grouped, high information density */}
          <aside className="no-print sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-border bg-card md:flex">
            {nav}
          </aside>

          {/* Mobile drawer */}
          {drawer && (
            <div className="no-print fixed inset-0 z-40 md:hidden">
              <div
                className="absolute inset-0 bg-foreground/30"
                onClick={() => setDrawer(false)}
                aria-hidden
              />
              <aside className="absolute left-0 top-0 flex h-full w-72 max-w-[85vw] flex-col border-r border-border bg-card shadow-xl">
                <button
                  type="button"
                  aria-label="Close menu"
                  onClick={() => setDrawer(false)}
                  className="absolute right-2 top-3 rounded p-1.5 text-muted-foreground hover:bg-muted"
                >
                  <X className="h-4 w-4" />
                </button>
                {nav}
              </aside>
            </div>
          )}

          {/* Main */}
          <div className="min-w-0 flex-1">
            <header className="no-print sticky top-0 z-10 border-b border-border bg-background/85 backdrop-blur">
              <div className="flex items-start gap-3 px-4 py-4 sm:px-6">
                <button
                  type="button"
                  aria-label="Open menu"
                  onClick={() => setDrawer(true)}
                  className="mt-0.5 rounded-md border border-border p-1.5 text-muted-foreground hover:bg-muted md:hidden"
                >
                  <Menu className="h-4 w-4" />
                </button>
                <div className="min-w-0 flex-1">
                  <h1 className="text-lg font-semibold tracking-tight sm:text-xl">{title}</h1>
                  {subtitle && (
                    <p className="mt-0.5 text-xs text-muted-foreground sm:text-sm">{subtitle}</p>
                  )}
                </div>
                {actions && (
                  <div className="flex flex-wrap items-center justify-end gap-2">{actions}</div>
                )}
              </div>
            </header>

            {readOnly && (
              <div className="no-print border-b border-warn/40 bg-warn-bg px-4 py-2 sm:px-6">
                <div className="flex items-start gap-2 text-xs">
                  <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warn" />
                  <div>
                    <span className="font-medium">You have read-only access</span>
                    <span className="text-muted-foreground">
                      {" "}
                      — signed in as {ROLE_LABEL[role] ?? role}. You can read every page and export
                      reports, but the server refuses any change to the book.
                    </span>
                  </div>
                </div>
              </div>
            )}

            {!readOnly && !canManageBook && (
              <div className="no-print border-b border-warn/40 bg-warn-bg px-4 py-2 sm:px-6">
                <div className="flex items-start gap-2 text-xs">
                  <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warn" />
                  <div>
                    <span className="font-medium">You can enter records, but not change the book</span>
                    <span className="text-muted-foreground">
                      {" "}
                      — signed in as {ROLE_LABEL[role] ?? role}. You may post transactions, record
                      receipts and add assets, commitments and budget lines. Settings, periods,
                      access and deletions stay with the treasurer. Every entry you post is
                      attributed to you in the change log.
                    </span>
                  </div>
                </div>
              </div>
            )}

            <main className="px-4 py-5 sm:px-6 sm:py-6">{children}</main>
          </div>
        </div>
      </div>
    </ShellContext.Provider>
  );
}
