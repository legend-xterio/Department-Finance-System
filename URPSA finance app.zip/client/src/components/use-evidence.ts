import { useState } from "react";
import { trpc } from "@/_core/trpc";

/**
 * Attach a receipt to any ledger-writing form.
 *
 * The posting engine refuses an entry at or above the evidence threshold unless
 * a *verified* document is attached, so every form that moves money — a
 * transaction, a sponsorship receipt, an asset disposal, a liability settlement
 * — needs this exact three-step upload (signed URL → PUT → commit → evidence
 * row → verify). Extracted here so the four forms cannot drift apart.
 */
export function useEvidenceUpload() {
  const [evidenceId, setEvidenceId] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const uploadUrl = trpc.files.uploadUrl.useMutation();
  const commit = trpc.files.commit.useMutation();
  const createEvidence = trpc.evidence.create.useMutation();
  const setEvidenceStatus = trpc.evidence.setStatus.useMutation();

  async function handleFile(file: File) {
    setUploading(true);
    setError(null);
    try {
      const { key, uploadUrl: put } = await uploadUrl.mutateAsync({
        name: file.name,
        contentType: file.type || "application/octet-stream",
      });
      const res = await fetch(put, {
        method: "PUT",
        body: file,
        headers: { "Content-Type": file.type || "application/octet-stream" },
      });
      if (!res.ok) throw new Error("The upload failed. Try again.");
      await commit.mutateAsync({ key, name: file.name });
      const ev = await createEvidence.mutateAsync({
        docType: "receipt",
        description: file.name,
        storageKey: key,
        filePath: key,
        mimeType: file.type,
        fileSizeBytes: file.size,
      });
      // A document the treasurer attaches themselves counts as verified by them.
      await setEvidenceStatus.mutateAsync({ id: ev.id, status: "verified" });
      setEvidenceId(ev.id);
      setFileName(file.name);
    } catch (e) {
      setError(e);
    } finally {
      setUploading(false);
    }
  }

  function reset() {
    setEvidenceId(null);
    setFileName(null);
    setError(null);
  }

  return {
    evidenceId,
    fileName,
    uploading,
    error,
    setError,
    handleFile,
    reset,
    /** Pass straight into a mutation. */
    evidenceIds: evidenceId ? [evidenceId] : undefined,
  };
}
