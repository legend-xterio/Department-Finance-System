import {
  pgTable,
  uuid,
  text,
  timestamp,
  index,
  bigint,
  integer,
  boolean,
  date,
  numeric,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// ──────────────────────────────────────────────────────────────────────────────
// SYSTEM TABLES — managed by the scaffold. The Agent MUST NOT redefine or drop
// the auth columns here; it only ADDS business tables below (DESIGN §5.1).
// ──────────────────────────────────────────────────────────────────────────────
export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash"), // null for SSO-linked users (future)
  name: text("name"),
  role: text("role").notNull().default("user"), // 'user' | 'admin'
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const files = pgTable(
  "files",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    key: text("key").notNull().unique(),
    ownerId: uuid("owner_id").references(() => users.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    size: bigint("size", { mode: "number" }).notNull(),
    contentType: text("content_type"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("files_owner_idx").on(t.ownerId), index("files_created_idx").on(t.createdAt)],
);

export const items = pgTable(
  "items",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    notes: text("notes"),
    coverUrl: text("cover_url"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("items_owner_idx").on(t.ownerId)],
);

// ──────────────────────────────────────────────────────────────────────────────
// BUSINESS TABLES — URPSA Financial Management System 2026/2027
//
// The workbook is SINGLE-ENTRY: one row per income or expense, with a category
// code. This app keeps that register as the input surface (`transactions`) and
// DERIVES a balanced double entry (`journal_entries` / `journal_lines`) through
// one server-side posting engine, so trial balance, financial position and cash
// flow are real statements rather than typed-in totals.
//
// Money is numeric(15,2) and surfaces as a string; shared/finance.ts converts.
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Chart of accounts. Global reference data, seeded by migration.
 * URPSA's own 12 categories (4001–4005 income, 5001–5007 expense) plus the
 * minimum system accounts a double entry needs (cash, liabilities, fund).
 */
export const accounts = pgTable(
  "accounts",
  {
    code: text("code").primaryKey(),
    name: text("name").notNull(),
    type: text("type").notNull(), // asset | liability | equity | income | expense
    category: text("category"),
    reportGroup: text("report_group"),
    parentCode: text("parent_code"),
    isPostable: boolean("is_postable").notNull().default(false),
    isCash: boolean("is_cash").notNull().default(false),
    cashFlowClass: text("cash_flow_class").notNull().default("none"),
    requiresActivity: boolean("requires_activity").notNull().default(false),
    requiresEvidence: boolean("requires_evidence").notNull().default(false),
    isContra: boolean("is_contra").notNull().default(false),
    isActive: boolean("is_active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    notes: text("notes"),
  },
  (t) => [index("accounts_type_idx").on(t.type), index("accounts_sort_idx").on(t.sortOrder)],
);

/** One row per treasurer account: the entity's accounting configuration. */
export const orgs = pgTable("orgs", {
  id: uuid("id").primaryKey().defaultRandom(),
  ownerId: uuid("owner_id")
    .notNull()
    .unique()
    .references(() => users.id, { onDelete: "cascade" }),
  legalName: text("legal_name").notNull(),
  shortName: text("short_name"),
  baseCurrency: text("base_currency").notNull().default("NGN"),
  periodStart: date("period_start").notNull(),
  periodEnd: date("period_end").notNull(),
  conversionDate: date("conversion_date").notNull(),
  openingBalanceStatus: numeric("opening_balance_status", { precision: 15, scale: 2 })
    .notNull()
    .default("0.00"),
  financialSecretary: text("financial_secretary"),
  treasurer: text("treasurer"),
  president: text("president"),
  memberIdRule: text("member_id_rule"),
  capitalisationThreshold: numeric("capitalisation_threshold", { precision: 15, scale: 2 })
    .notNull()
    .default("50000.00"),
  evidenceRequiredAbove: numeric("evidence_required_above", { precision: 15, scale: 2 })
    .notNull()
    .default("5000.00"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Bank / cash accounts (workbook "Accounts" sheet). */
export const cashAccounts = pgTable(
  "cash_accounts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    code: text("code").notNull(), // BANK-01 | CASH-01
    name: text("name").notNull(),
    accountType: text("account_type").notNull().default("bank"), // bank | cash
    details: text("details"),
    openingBalance: numeric("opening_balance", { precision: 15, scale: 2 }),
    openingDate: date("opening_date"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("cash_accounts_owner_code_uq").on(t.ownerId, t.code),
    index("cash_accounts_owner_idx").on(t.ownerId),
  ],
);

export const fiscalPeriods = pgTable(
  "fiscal_periods",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    fiscalYear: integer("fiscal_year").notNull(),
    periodNo: integer("period_no").notNull(),
    startDate: date("start_date").notNull(),
    endDate: date("end_date").notNull(),
    status: text("status").notNull().default("open"), // future | open | closed | locked
  },
  (t) => [
    uniqueIndex("fiscal_periods_owner_year_no_uq").on(t.ownerId, t.fiscalYear, t.periodNo),
    index("fiscal_periods_owner_idx").on(t.ownerId),
  ],
);

/** Activities and their approved budgets (workbook "Activities-Budgets"). */
export const activities = pgTable(
  "activities",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    code: text("code").notNull(), // FRESH-ORI-2026-27 | CONF-2026
    name: text("name").notNull(),
    startDate: date("start_date"),
    endDate: date("end_date"),
    budgetCategory: text("budget_category"),
    approvedBudget: numeric("approved_budget", { precision: 15, scale: 2 }),
    approver: text("approver"),
    approvalDate: date("approval_date"),
    fundCode: text("fund_code").notNull().default("GEN"), // GEN | SPON
    status: text("status").notNull().default("planned"), // planned | active | completed | cancelled
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("activities_owner_code_uq").on(t.ownerId, t.code),
    index("activities_owner_idx").on(t.ownerId),
  ],
);

/** Members (workbook "Members"). */
export const members = pgTable(
  "members",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    memberId: text("member_id").notNull(), // URPSA/YY/XXX
    admissionYear: text("admission_year"),
    matricNumber: text("matric_number"),
    fullName: text("full_name").notNull(),
    level: text("level"),
    phone: text("phone"),
    email: text("email"),
    status: text("status").notNull().default("active"), // active | inactive | graduated
    /** Set when archived. Archiving keeps every historical reference intact —
     *  the member stays on past transactions and dues, but leaves the active
     *  register. A hard delete is only allowed when nothing references them. */
    archivedAt: timestamp("archived_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("members_owner_member_id_uq").on(t.ownerId, t.memberId),
    index("members_owner_idx").on(t.ownerId),
  ],
);

/** Dues obligations (workbook "Dues"). Collections match on member + reference. */
export const dues = pgTable(
  "dues",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    duesRef: text("dues_ref").notNull(),
    memberId: text("member_id").notNull(),
    duesType: text("dues_type").notNull(),
    dueDate: date("due_date"),
    amountAssessed: numeric("amount_assessed", { precision: 15, scale: 2 })
      .notNull()
      .default("0.00"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("dues_owner_ref_uq").on(t.ownerId, t.duesRef),
    index("dues_owner_member_idx").on(t.ownerId, t.memberId),
  ],
);

/** Sponsorship commitments (workbook "Sponsorship"). Receipts flow from transactions. */
export const sponsorship = pgTable(
  "sponsorship",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    sponsorshipId: text("sponsorship_id").notNull(),
    sponsor: text("sponsor").notNull(),
    purpose: text("purpose"),
    contact: text("contact"),
    commitmentDate: date("commitment_date"),
    amountPledged: numeric("amount_pledged", { precision: 15, scale: 2 })
      .notNull()
      .default("0.00"),
    stage: text("stage").notNull().default("pledged"),
    // pledged | approached | proposal_sent | negotiating | contract_signed | received | declined
    activityCode: text("activity_code"),
    /** unrestricted | restricted | designated — how the money may be used. */
    restriction: text("restriction").notNull().default("restricted"),
    /** Date the money is expected in, distinct from the date it was pledged. */
    expectedDate: date("expected_date"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("sponsorship_owner_ref_uq").on(t.ownerId, t.sponsorshipId),
    index("sponsorship_owner_idx").on(t.ownerId),
  ],
);

/**
 * THE MASTER TRANSACTION REGISTER (workbook "Master Transactions").
 * One row per actual income or expense — the single-entry input surface.
 * Every row is posted through the engine, which writes the balanced journal
 * entry and links it back via `entryId`.
 */
export const transactions = pgTable(
  "transactions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    txnId: text("txn_id").notNull(), // TXN-0001
    txnType: text("txn_type").notNull(), // Income | Expense
    txnDate: date("txn_date").notNull(),
    categoryCode: text("category_code").notNull(), // 4001..5007
    cashAccountCode: text("cash_account_code").notNull(), // BANK-01 | CASH-01
    payee: text("payee"),
    memberId: text("member_id"),
    reference: text("reference"),
    amount: numeric("amount", { precision: 15, scale: 2 }).notNull().default("0.00"),
    evidenceId: text("evidence_id"),
    activityCode: text("activity_code"),
    approvalStatus: text("approval_status").notNull().default("Approved"), // Approved | Pending
    approvedBy: text("approved_by"),
    notes: text("notes"),
    entryId: uuid("entry_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("transactions_owner_txn_uq").on(t.ownerId, t.txnId),
    index("transactions_owner_date_idx").on(t.ownerId, t.txnDate),
    index("transactions_owner_activity_idx").on(t.ownerId, t.activityCode),
  ],
);

/** Derived double-entry header. Written ONLY by the posting engine. */
export const journalEntries = pgTable(
  "journal_entries",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    entryNo: text("entry_no").notNull(),
    entryDate: date("entry_date").notNull(),
    periodId: uuid("period_id").references(() => fiscalPeriods.id, { onDelete: "set null" }),
    source: text("source").notNull().default("manual"), // manual | opening | reversal
    status: text("status").notNull().default("posted"), // posted | reversed
    description: text("description").notNull(),
    documentRef: text("document_ref"),
    currency: text("currency").notNull().default("NGN"),
    totalDebit: numeric("total_debit", { precision: 15, scale: 2 }).notNull().default("0.00"),
    totalCredit: numeric("total_credit", { precision: 15, scale: 2 }).notNull().default("0.00"),
    reversesEntryId: uuid("reverses_entry_id"),
    preparedBy: text("prepared_by").notNull(),
    approvedBy: text("approved_by"),
    postedAt: timestamp("posted_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("journal_entries_owner_no_uq").on(t.ownerId, t.entryNo),
    index("journal_entries_owner_date_idx").on(t.ownerId, t.entryDate),
    index("journal_entries_owner_idx").on(t.ownerId),
  ],
);

/** Derived double-entry lines. Written ONLY by the posting engine. */
export const journalLines = pgTable(
  "journal_lines",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    entryId: uuid("entry_id")
      .notNull()
      .references(() => journalEntries.id, { onDelete: "cascade" }),
    lineNo: integer("line_no").notNull(),
    accountCode: text("account_code").notNull(),
    activityCode: text("activity_code"),
    cashAccountCode: text("cash_account_code"),
    debit: numeric("debit", { precision: 15, scale: 2 }).notNull().default("0.00"),
    credit: numeric("credit", { precision: 15, scale: 2 }).notNull().default("0.00"),
    memo: text("memo"),
  },
  (t) => [
    index("journal_lines_entry_idx").on(t.entryId),
    index("journal_lines_owner_account_idx").on(t.ownerId, t.accountCode),
    index("journal_lines_owner_activity_idx").on(t.ownerId, t.activityCode),
  ],
);

/** Evidence and document tracking (workbook "Evidence Tracking"). */
export const evidence = pgTable(
  "evidence",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    evidenceId: text("evidence_id").notNull(), // EV-0001
    transactionId: text("transaction_id"),
    docType: text("doc_type").notNull().default("receipt"),
    description: text("description"),
    filePath: text("file_path"),
    storageKey: text("storage_key"),
    mimeType: text("mime_type"),
    fileSizeBytes: integer("file_size_bytes"),
    dateReceived: date("date_received"),
    submittedBy: text("submitted_by"),
    reviewedBy: text("reviewed_by"),
    status: text("status").notNull().default("pending"), // pending | verified | query | rejected
    exceptionReason: text("exception_reason"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("evidence_owner_ref_uq").on(t.ownerId, t.evidenceId),
    index("evidence_owner_txn_idx").on(t.ownerId, t.transactionId),
  ],
);

/** Liabilities and commitments (workbook "Liabilities & Commitments"). */
export const liabilities = pgTable(
  "liabilities",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    liabilityId: text("liability_id").notNull(),
    payee: text("payee").notNull(),
    description: text("description"),
    activityCode: text("activity_code"),
    dateIncurred: date("date_incurred"),
    dueDate: date("due_date"),
    amountCommitted: numeric("amount_committed", { precision: 15, scale: 2 })
      .notNull()
      .default("0.00"),
    approvalStatus: text("approval_status").notNull().default("Approved"), // Approved | Pending
    status: text("status").notNull().default("outstanding"), // outstanding | settled
    /** Settlement: the payment that cleared this commitment, posted to the
     *  ledger through the posting engine so the liability leaves the balance
     *  sheet at the same moment the cash does. */
    settledDate: date("settled_date"),
    settledAmount: numeric("settled_amount", { precision: 15, scale: 2 }),
    settlementEntryId: uuid("settlement_entry_id"),
    settlementRef: text("settlement_ref"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("liabilities_owner_ref_uq").on(t.ownerId, t.liabilityId),
    index("liabilities_owner_idx").on(t.ownerId),
  ],
);

/** Asset register (workbook "Assets"). Custody and condition, not a second ledger. */
export const assets = pgTable(
  "assets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    assetId: text("asset_id").notNull(),
    description: text("description").notNull(),
    category: text("category").notNull().default("equipment"),
    serial: text("serial"),
    custodian: text("custodian"),
    location: text("location"),
    purchaseDate: date("purchase_date"),
    purchaseTxnId: text("purchase_txn_id"),
    cost: numeric("cost", { precision: 15, scale: 2 }).notNull().default("0.00"),
    condition: text("condition").notNull().default("good"), // new | good | fair | poor
    lastVerified: date("last_verified"),
    /** Disposal: an asset leaves the register but is never silently deleted. */
    status: text("status").notNull().default("in_use"), // in_use | disposed
    disposalDate: date("disposal_date"),
    disposalProceeds: numeric("disposal_proceeds", { precision: 15, scale: 2 }),
    disposalReason: text("disposal_reason"),
    disposalEntryId: uuid("disposal_entry_id"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("assets_owner_ref_uq").on(t.ownerId, t.assetId),
    index("assets_owner_idx").on(t.ownerId),
  ],
);

/** Monthly bank and cash reconciliation (workbook "Reconciliation"). */
export const reconciliations = pgTable(
  "reconciliations",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    month: date("month").notNull(),
    cashAccountCode: text("cash_account_code").notNull(),
    statementDate: date("statement_date"),
    statementBalance: numeric("statement_balance", { precision: 15, scale: 2 }),
    ledgerBalance: numeric("ledger_balance", { precision: 15, scale: 2 }),
    reviewedBy: text("reviewed_by"),
    status: text("status").notNull().default("not_ready"), // not_ready | reconciled | difference
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("reconciliations_owner_month_acct_uq").on(t.ownerId, t.month, t.cashAccountCode),
    index("reconciliations_owner_idx").on(t.ownerId),
  ],
);

/** Annual budget header (workbook "Budget vs Actual" / "Activities-Budgets"). */
export const budgets = pgTable(
  "budgets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    fiscalYear: integer("fiscal_year").notNull(),
    name: text("name").notNull(),
    version: integer("version").notNull().default(1),
    status: text("status").notNull().default("approved"), // draft | approved | locked | superseded
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("budgets_owner_year_idx").on(t.ownerId, t.fiscalYear)],
);

export const budgetLines = pgTable(
  "budget_lines",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    budgetId: uuid("budget_id")
      .notNull()
      .references(() => budgets.id, { onDelete: "cascade" }),
    accountCode: text("account_code").notNull(),
    activityCode: text("activity_code"),
    periodNo: integer("period_no").notNull().default(0), // 0 = annual line
    amount: numeric("amount", { precision: 15, scale: 2 }).notNull().default("0.00"),
  },
  (t) => [
    index("budget_lines_budget_idx").on(t.budgetId),
    index("budget_lines_owner_account_idx").on(t.ownerId, t.accountCode),
  ],
);
