import { defineConfig } from "drizzle-kit";
export default defineConfig({
  dialect: "postgresql",
  schema: "./_gen/schema.ts",
  out: "./_gen/out",
  strict: false,
});
