import { describe, expect, it } from "vitest";
import {
  incomeExpenditureCsv,
  financialPositionCsv,
  cashFlowCsv,
  trialBalanceCsv,
  controlChecksCsv,
  budgetVarianceCsv,
  reportFilename,
  ORG_NAME,
} from "./report-csv";
import { formatMemberId } from "./member-id";

/**
 * These exist because "the CSV button works" is otherwise verified by a human
 * clicking it once. A builder that emits an empty file, or drops the total row,
 * or writes `NaN` for a missing figure, is broken in a way a screenshot of the
 * Reports page would never show.
 */
describe("report CSV builders", () => {
  const asAt = "2026-10-26";

  const ie = {
    income: [{ code: "4001", name: "Member dues", amount: 1730000 }],
    expenditure: [{ code: "5001", name: "Venue", amount: 1345500 }],
    totalIncome: 1730000,
    totalExpenditure: 1345500,
    surplus: 384500,
  };

  it("emits a header row, the title block and the net result", () => {
    const csv = incomeExpenditureCsv(ie, asAt);
    const lines = csv.split("\n");
    expect(lines[0]).toBe("Code,Account,Amount (NGN)");
    // The organisation must survive into the file — a stray CSV needs to say
    // whose books it is.
    expect(csv).toContain(ORG_NAME);
    expect(csv).toContain("STATEMENT OF INCOME AND EXPENDITURE");
    expect(csv).toContain("1730000.00");
    expect(csv).toContain("NET SURPLUS / (DEFICIT) FOR THE PERIOD");
    expect(csv).toContain("384500.00");
  });

  it("keeps two decimal places so Excel does not re-round the kobo", () => {
    const csv = incomeExpenditureCsv({ ...ie, totalIncome: 104099.5 }, asAt);
    expect(csv).toContain("104099.50");
  });

  it("escapes a name containing a comma", () => {
    const csv = incomeExpenditureCsv(
      {
        ...ie,
        expenditure: [{ code: "5002", name: "Printing, binding and postage", amount: 100 }],
      },
      asAt,
    );
    expect(csv).toContain('"Printing, binding and postage"');
  });

  it("never writes undefined or NaN for an empty register", () => {
    const csv = financialPositionCsv(
      {
        assets: [{ code: "1010", name: "Bank", amount: 488599.5 }],
        liabilities: [],
        funds: [{ code: "3010", name: "Accumulated fund", amount: 104099.5 }],
        totalAssets: 488599.5,
        totalLiabilities: 0,
        totalFunds: 104099.5,
        currentSurplus: 384500,
        difference: 0,
      },
      asAt,
    );
    expect(csv).not.toMatch(/undefined|NaN/);
    expect(csv).toContain("None");
    expect(csv).toContain("Difference (must be zero),0.00");
  });

  it("states the cash flow control difference", () => {
    const csv = cashFlowCsv(
      {
        operating: 384500,
        investing: 0,
        financing: 104099.5,
        netMovement: 488599.5,
        openingCash: 0,
        closingCash: 488599.5,
        difference: 0,
      },
      asAt,
    );
    expect(csv).toContain("Control difference (must be zero),0.00");
    expect(csv).toContain("488599.50");
  });

  it("trial balance writes both totals and the difference", () => {
    const csv = trialBalanceCsv(
      {
        rows: [{ code: "1010", name: "Bank", debit: 3174599.5, credit: 0 }],
        totalDebit: 3174599.5,
        totalCredit: 3174599.5,
        difference: 0,
      },
      asAt,
    );
    expect(csv).toContain("TOTAL,3174599.50,3174599.50");
    expect(csv).toContain("Difference (must be zero),0.00");
  });

  it("control checks mark each result and the overall verdict", () => {
    const csv = controlChecksCsv(
      [
        { name: "Trial balance", detail: "debits = credits", value: 0, pass: true },
        { name: "Cash", detail: "cash agrees", value: 0, pass: true },
      ],
      asAt,
    );
    expect(csv).toContain("PASS");
    expect(csv).toContain("ALL CONTROLS PASSING");
  });

  it("a failing control check says ATTENTION REQUIRED, not PASS", () => {
    const csv = controlChecksCsv(
      [{ name: "Trial balance", detail: "debits = credits", value: 500, pass: false }],
      asAt,
    );
    expect(csv).toContain("FAIL");
    expect(csv).toContain("ATTENTION REQUIRED");
  });

  it("budget variance keeps the activity column even when it is blank", () => {
    const csv = budgetVarianceCsv(
      {
        rows: [
          {
            accountCode: "5001",
            name: "Venue",
            activityCode: "ACT-001",
            budget: 400000,
            actual: 250000,
            variance: 150000,
            usedPct: 62.5,
          },
          {
            accountCode: "5002",
            name: "Printing",
            activityCode: null,
            budget: 100000,
            actual: 120000,
            variance: -20000,
            usedPct: 120,
          },
        ],
        totalBudget: 500000,
        totalActual: 370000,
        totalVariance: 130000,
      },
      asAt,
    );
    const lines = csv.split("\n");
    const printing = lines.find((l) => l.includes("Printing"))!;
    expect(printing).toContain("5002,Printing,,");
    expect(csv).toContain("TOTAL");
  });

  it("filenames are stable and sortable", () => {
    expect(reportFilename("income-expenditure", "2026-10-26")).toBe(
      "urpsa-income-expenditure-2026-10-26.csv",
    );
  });
});

describe("member ID rule URPSA/YY/XXX", () => {
  it("zero-pads the sequence to three digits", () => {
    expect(formatMemberId("2026", 1)).toBe("URPSA/26/001");
    expect(formatMemberId("2026", 13)).toBe("URPSA/26/013");
    expect(formatMemberId("2026", 999)).toBe("URPSA/26/999");
  });

  it("takes the last two digits of the admission year", () => {
    expect(formatMemberId("2027", 1)).toBe("URPSA/27/001");
    expect(formatMemberId("2025", 45)).toBe("URPSA/25/045");
  });

  it("does not truncate a sequence past three digits", () => {
    // A four-digit suffix is out of spec, but silently writing URPSA/26/00
    // would collide with an existing member — so it must stay visible.
    expect(formatMemberId("2026", 1234)).toBe("URPSA/26/1234");
  });

  it("tolerates a year written with extra text", () => {
    expect(formatMemberId("2026/2027", 7)).toBe("URPSA/27/007");
  });
});
