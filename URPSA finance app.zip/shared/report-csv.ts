// ─────────────────────────────────────────────────────────────────────────────
// REPORT CSV BUILDERS
//
// Pure functions: report data in, a CSV string out. No DOM, no fetch, no React.
// That matters for two reasons:
//
//   1. The Reports page and any future export share ONE definition of each
//      statement, so they cannot drift apart.
//   2. It is testable without a browser. "Does the CSV button work?" is answered
//      by a unit test over the builder, not by a human clicking it.
//
// Every statement carries a title block (organisation, statement, date) so a
// stray downloaded file is still identifiable once it leaves the app.
// ─────────────────────────────────────────────────────────────────────────────
import { toCsv } from "./finance";
import { orgTitle, orgSubtitle, orgSession, orgContact, amountHeader, type OrgIdentity } from "./org-display";

/** Kept for callers that have no org row yet; the live name comes from Settings. */
export const ORG_NAME = "Urban and Regional Planning Students' Association (URPSA)";

type Row = (string | number)[];

/**
 * Title block every export carries: who the books belong to, which statement,
 * the session and the date. The organisation details are passed in from
 * Settings, so a renamed association or a new session flows into every file
 * without touching this module.
 *
 * A CSV is plain text and cannot hold an image, so the department mark travels
 * as a REFERENCE rather than as pixels: one line naming the crest and, when the
 * caller knows it, the absolute URL it can be fetched from. That keeps the file
 * self-identifying without pretending an image is inside it.
 *
 * The crest itself appears where an image is actually possible: the app header,
 * the on-screen statement, the printed statement (PrintMark) and the printed
 * recovery-code sheet. There is deliberately no "branded CSV" — a spreadsheet
 * cannot render one, and a fake one would be a lie in the file.
 */
function titleBlock(
  title: string,
  asAt: string,
  org?: OrgIdentity | null,
  markUrl?: string,
): Row[] {
  const rows: Row[] = [[orgTitle(org)], [title]];
  const sub = orgSubtitle(org);
  if (sub) rows.push([sub]);
  const session = orgSession(org);
  if (session) rows.push([session]);
  rows.push([`As at ${asAt}`]);
  const contact = orgContact(org);
  if (contact) rows.push([contact]);
  rows.push([`Department mark: ${(org?.shortName ?? "URPSA").trim()} crest${markUrl ? ` (${markUrl})` : ""}`]);
  rows.push([]);
  return rows;
}

const f = (v: number) => v.toFixed(2);

// ── Income & Expenditure ─────────────────────────────────────────────────────
export interface IEStatementLike {
  income: { code: string; name: string; amount: number }[];
  expenditure: { code: string; name: string; amount: number }[];
  totalIncome: number;
  totalExpenditure: number;
  surplus: number;
}

export function incomeExpenditureCsv(d: IEStatementLike, asAt: string, org?: OrgIdentity | null, markUrl?: string): string {
  const rows: Row[] = [
    ...titleBlock("STATEMENT OF INCOME AND EXPENDITURE", asAt, org, markUrl),
    ["INCOME"],
    ...d.income.map((r) => [r.code, r.name, f(r.amount)]),
    ["", "Total income", f(d.totalIncome)],
    [],
    ["EXPENDITURE"],
    ...d.expenditure.map((r) => [r.code, r.name, f(r.amount)]),
    ["", "Total expenditure", f(d.totalExpenditure)],
    [],
    ["", "NET SURPLUS / (DEFICIT) FOR THE PERIOD", f(d.surplus)],
  ];
  return toCsv(["Code", "Account", amountHeader(org)], rows);
}

// ── Financial Position ───────────────────────────────────────────────────────
export interface PositionLike {
  assets: { code: string; name: string; amount: number }[];
  liabilities: { code: string; name: string; amount: number }[];
  funds: { code: string; name: string; amount: number }[];
  totalAssets: number;
  totalLiabilities: number;
  totalFunds: number;
  currentSurplus: number;
  difference: number;
}

export function financialPositionCsv(d: PositionLike, asAt: string, org?: OrgIdentity | null, markUrl?: string): string {
  const rows: Row[] = [
    ...titleBlock("STATEMENT OF FINANCIAL POSITION", asAt, org, markUrl),
    ["ASSETS"],
    ...d.assets.map((r) => [r.code, r.name, f(r.amount)]),
    ["", "Total assets", f(d.totalAssets)],
    [],
    ["LIABILITIES"],
    ...(d.liabilities.length === 0
      ? [["", "None", "0.00"] as Row]
      : d.liabilities.map((r) => [r.code, r.name, f(r.amount)] as Row)),
    ["", "Total liabilities", f(d.totalLiabilities)],
    [],
    ["FUNDS"],
    ...d.funds.map((r) => [r.code, r.name, f(r.amount)] as Row),
    ["", "Period result (income less expenditure)", f(d.currentSurplus)],
    ["", "Total funds", f(d.totalFunds + d.currentSurplus)],
    [],
    ["", "TOTAL LIABILITIES AND FUNDS", f(d.totalLiabilities + d.totalFunds + d.currentSurplus)],
    ["", "Difference (must be zero)", f(d.difference)],
  ];
  return toCsv(["Code", "Account", amountHeader(org)], rows);
}

// ── Cash Flows ───────────────────────────────────────────────────────────────
export interface CashFlowLike {
  operating: number;
  investing: number;
  financing: number;
  netMovement: number;
  openingCash: number;
  closingCash: number;
  difference: number;
}

export function cashFlowCsv(d: CashFlowLike, asAt: string, org?: OrgIdentity | null, markUrl?: string): string {
  const rows: Row[] = [
    ...titleBlock("STATEMENT OF CASH FLOWS", asAt, org, markUrl),
    ["Net cash from operating activities", f(d.operating)],
    ["Net cash from investing activities", f(d.investing)],
    ["Net cash from financing activities", f(d.financing)],
    ["Net movement in cash", f(d.netMovement)],
    ["Cash at the start of the period", f(d.openingCash)],
    ["CASH AT THE END OF THE PERIOD", f(d.closingCash)],
    ["Control difference (must be zero)", f(d.difference)],
  ];
  return toCsv(["Section", amountHeader(org)], rows);
}

// ── Trial Balance ────────────────────────────────────────────────────────────
export interface TrialLike {
  rows: { code: string; name: string; debit: number; credit: number }[];
  totalDebit: number;
  totalCredit: number;
  difference: number;
}

export function trialBalanceCsv(d: TrialLike, asAt: string, org?: OrgIdentity | null, markUrl?: string): string {
  const rows: Row[] = [
    ...titleBlock("TRIAL BALANCE", asAt, org, markUrl),
    ...d.rows.map((r) => [r.code, r.name, f(r.debit), f(r.credit)] as Row),
    ["", "TOTAL", f(d.totalDebit), f(d.totalCredit)],
    ["", "Difference (must be zero)", f(d.difference), ""],
  ];
  return toCsv(["Code", "Account", `Debit (${(org?.baseCurrency ?? "NGN").toUpperCase()})`, `Credit (${(org?.baseCurrency ?? "NGN").toUpperCase()})`], rows);
}

// ── Control Checks ───────────────────────────────────────────────────────────
export interface ControlLike {
  name: string;
  detail: string;
  value: number;
  pass: boolean;
}

export function controlChecksCsv(d: ControlLike[], asAt: string, org?: OrgIdentity | null, markUrl?: string): string {
  const rows: Row[] = [
    ...titleBlock("CONTROL CHECKS", asAt, org, markUrl),
    ...d.map((c) => [c.name, c.detail, c.value, c.pass ? "PASS" : "FAIL"] as Row),
    [],
    ["Overall", d.every((c) => c.pass) ? "ALL CONTROLS PASSING" : "ATTENTION REQUIRED", "", ""],
  ];
  return toCsv(["Check", "Detail", "Value", "Result"], rows);
}

// ── Budget vs Actual ─────────────────────────────────────────────────────────
export interface BudgetVarianceLike {
  rows: {
    accountCode: string;
    name: string;
    activityCode: string | null;
    budget: number;
    actual: number;
    variance: number;
    usedPct: number;
  }[];
  totalBudget: number;
  totalActual: number;
  totalVariance: number;
}

export function budgetVarianceCsv(d: BudgetVarianceLike, asAt: string, org?: OrgIdentity | null, markUrl?: string): string {
  const rows: Row[] = [
    ...titleBlock("BUDGET VS ACTUAL", asAt, org, markUrl),
    ...d.rows.map(
      (r) =>
        [
          r.accountCode,
          r.name,
          r.activityCode ?? "",
          f(r.budget),
          f(r.actual),
          f(r.variance),
          r.usedPct.toFixed(1),
        ] as Row,
    ),
    [
      "TOTAL",
      "",
      "",
      f(d.totalBudget),
      f(d.totalActual),
      f(d.totalVariance),
      (d.totalBudget === 0 ? 0 : (d.totalActual / d.totalBudget) * 100).toFixed(1),
    ],
  ];
  return toCsv(["Code", "Category", "Activity", "Budget", "Actual", "Variance", "Used %"], rows);
}

/** A stable, sortable filename: urpsa-income-expenditure-2026-10-26.csv */
export function reportFilename(report: string, asAt: string, org?: OrgIdentity | null): string {
  const slug =
    (org?.shortName ?? "urpsa")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "urpsa";
  return `${slug}-${report}-${asAt}.csv`;
}
