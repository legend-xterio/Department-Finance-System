// ─────────────────────────────────────────────────────────────────────────────
// BUDGET PLAN — the arithmetic of building a budget from scratch
//
// The wizard needs to do four things that are worth getting provably right and
// are all pure: total a half-finished plan, scale last year's figures by an
// uplift, spread an annual line across twelve months, and say what is wrong with
// a plan before it is committed.
//
// None of that belongs in a React component: a component cannot be unit-tested
// without a DOM, and the rounding rules below (a spread must still add up to the
// original to the kobo) are exactly the kind of thing a screenshot never shows.
// So it lives here, and both the wizard and the tests call the same functions.
//
// Money is numeric(15,2) in Postgres and surfaces as a string. Everything here
// takes and returns plain numbers already rounded to the kobo by money().
// ─────────────────────────────────────────────────────────────────────────────
import { money } from "./finance";

/** Which half of the budget a line belongs to. */
export type PlanKind = "income" | "expense";

/**
 * One budget line as the wizard holds it in memory.
 *
 * `periodNo` is 0 for an annual line, 1–12 for one month of the administration
 * year. A line is identified by (activity, account, period) — that triple is
 * what the duplicate check keys on and what the ledger joins against.
 */
export interface PlanLine {
  /** Client-side stable key, so React rows survive an edit. Never persisted. */
  key: string;
  accountCode: string;
  kind: PlanKind;
  activityCode: string | null;
  periodNo: number;
  amount: number;
  description?: string | null;
}

/** An activity as the wizard holds it while it is still being planned. */
export interface PlanActivity {
  code: string;
  name: string;
  startDate?: string | null;
  endDate?: string | null;
  fundCode?: string;
  budgetCategory?: string | null;
  status?: string;
  /** True when this activity already exists in the database. */
  persisted?: boolean;
}

/** A pair of totals in the natural direction of each account. */
export interface PlanTotals {
  income: number;
  expenditure: number;
  /** income − expenditure. Negative is a budgeted deficit. */
  net: number;
  lineCount: number;
  incomeLineCount: number;
  expenseLineCount: number;
}

/** A line identified by its account, aggregated across activities/periods. */
export interface PlanAccountTotal {
  accountCode: string;
  kind: PlanKind;
  amount: number;
  lineCount: number;
}

/** A line identified by its activity, aggregated across accounts/periods. */
export interface PlanActivityTotal {
  activityCode: string | null;
  income: number;
  expenditure: number;
  net: number;
  lineCount: number;
}

/**
 * Total a plan. Income and expenditure are summed separately and the net is
 * derived from the two rounded totals, so the three always tie exactly —
 * adding unrounded line amounts and rounding at the end would let the displayed
 * figures be a kobo out from the displayed net.
 */
export function planTotals(lines: readonly PlanLine[]): PlanTotals {
  let income = 0;
  let expenditure = 0;
  for (const l of lines) {
    const amt = money(l.amount);
    if (l.kind === "income") income += amt;
    else expenditure += amt;
  }
  const inc = money(income);
  const exp = money(expenditure);
  return {
    income: inc,
    expenditure: exp,
    net: money(inc - exp),
    lineCount: lines.length,
    incomeLineCount: lines.filter((l) => l.kind === "income").length,
    expenseLineCount: lines.filter((l) => l.kind === "expense").length,
  };
}

/** Aggregate by account, income first then expenditure, each by code. */
export function planByAccount(lines: readonly PlanLine[]): PlanAccountTotal[] {
  const m = new Map<string, PlanAccountTotal>();
  for (const l of lines) {
    const k = `${l.kind}|${l.accountCode}`;
    const cur = m.get(k);
    if (cur) {
      cur.amount = money(cur.amount + money(l.amount));
      cur.lineCount += 1;
    } else {
      m.set(k, {
        accountCode: l.accountCode,
        kind: l.kind,
        amount: money(l.amount),
        lineCount: 1,
      });
    }
  }
  return [...m.values()].sort((a, b) =>
    a.kind === b.kind ? a.accountCode.localeCompare(b.accountCode) : a.kind === "income" ? -1 : 1,
  );
}

/**
 * Aggregate by activity. A null activityCode is the organisation-wide bucket and
 * always sorts first, which matches how the Budget page groups.
 */
export function planByActivity(lines: readonly PlanLine[]): PlanActivityTotal[] {
  const m = new Map<string, PlanActivityTotal>();
  for (const l of lines) {
    const k = l.activityCode ?? "";
    const cur = m.get(k) ?? {
      activityCode: l.activityCode ?? null,
      income: 0,
      expenditure: 0,
      net: 0,
      lineCount: 0,
    };
    const amt = money(l.amount);
    if (l.kind === "income") cur.income += amt;
    else cur.expenditure += amt;
    cur.lineCount += 1;
    m.set(k, cur);
  }
  return [...m.values()]
    .map((a) => ({
      ...a,
      income: money(a.income),
      expenditure: money(a.expenditure),
      net: money(money(a.income) - money(a.expenditure)),
    }))
    .sort((a, b) =>
      a.activityCode === null ? -1 : b.activityCode === null ? 1 : a.activityCode.localeCompare(b.activityCode),
    );
}

/**
 * Scale every line by a percentage — the "last year plus 10%" start.
 * Each line is rounded independently, because each line is committed
 * independently; the total is whatever those rounded lines add to.
 */
export function applyUplift(lines: readonly PlanLine[], pct: number): PlanLine[] {
  if (!Number.isFinite(pct) || pct === 0) return lines.map((l) => ({ ...l }));
  return lines.map((l) => ({ ...l, amount: money(money(l.amount) * (1 + pct / 100)) }));
}

/**
 * Split each annual line (periodNo 0) into `months` equal monthly lines.
 *
 * The parts MUST add back to the original exactly. Dividing by twelve and
 * rounding each part loses or gains kobo, so the remainder (in kobo) is handed
 * out one kobo at a time to the earliest months. Lines that already carry a
 * period are left alone, so spreading twice cannot double-count.
 */
export function spreadOverMonths(lines: readonly PlanLine[], months = 12): PlanLine[] {
  const n = Math.max(1, Math.min(12, Math.floor(months)));
  const out: PlanLine[] = [];
  for (const l of lines) {
    if (l.periodNo !== 0) {
      out.push({ ...l });
      continue;
    }
    const totalKobo = Math.round(money(l.amount) * 100);
    const baseKobo = Math.floor(totalKobo / n);
    let remainder = totalKobo - baseKobo * n;
    for (let m = 1; m <= n; m++) {
      const kobo = baseKobo + (remainder > 0 ? 1 : 0);
      if (remainder > 0) remainder -= 1;
      out.push({
        ...l,
        key: `${l.key}#m${m}`,
        periodNo: m,
        amount: kobo / 100,
      });
    }
  }
  return out;
}

/** Collapse monthly lines of one (activity, account) back into an annual line. */
export function collapseToAnnual(lines: readonly PlanLine[]): PlanLine[] {
  const m = new Map<string, PlanLine>();
  for (const l of lines) {
    const k = `${l.activityCode ?? ""}|${l.accountCode}`;
    const cur = m.get(k);
    if (cur) {
      cur.amount = money(cur.amount + money(l.amount));
      if (l.periodNo !== 0) cur.periodNo = 0;
    } else {
      m.set(k, { ...l });
    }
  }
  return [...m.values()];
}

// ── Fiscal year helpers ──────────────────────────────────────────────────────
//
// The administration year runs 1 October – 30 September, and the stored
// fiscalYear is the year it ENDS in: the 2026/2027 year is fiscalYear 2027.
// Getting this backwards would silently file a budget against the wrong year, so
// every label goes through these two functions rather than being formatted inline.

/** 2027 → "2026/2027" */
export function fiscalYearLabel(year: number): string {
  return `${year - 1}/${year}`;
}

/** The year before, for prefill: 2028 → 2027 */
export function priorFiscalYear(year: number): number {
  return year - 1;
}

/** The range a budget year covers, given the administration start month (10 = Oct). */
export function fiscalYearRange(year: number): { start: string; end: string } {
  return {
    start: `${year - 1}-10-01`,
    end: `${year}-09-30`,
  };
}

/**
 * Years worth offering: the year of the open period, the two before it, the one
 * after. A treasurer building next year's budget wants next year first.
 */
export function fiscalYearChoices(currentYear: number): number[] {
  return [currentYear + 1, currentYear, currentYear - 1, currentYear - 2];
}

// ── Validation ───────────────────────────────────────────────────────────────

export interface PlanIssue {
  level: "error" | "warning";
  message: string;
  /** The line keys the issue is about, so the UI can point at the row. */
  keys: string[];
}

export interface ValidateOptions {
  /** Accounts a line is allowed to use: postable, active, income or expense. */
  accountKinds?: Record<string, PlanKind>;
  /** Activity codes that exist. A line naming any other code is an error. */
  knownActivities?: Set<string> | null;
}

/**
 * Everything wrong with a plan, before it is committed.
 *
 * Errors block the commit; warnings are things a treasurer should see and may
 * still accept (a zero line, a budgeted deficit). Keeping the two apart is what
 * lets "save it anyway" be a real decision rather than a silent one.
 */
export function validatePlan(lines: readonly PlanLine[], opts: ValidateOptions = {}): PlanIssue[] {
  const issues: PlanIssue[] = [];
  const { accountKinds, knownActivities } = opts;

  if (lines.length === 0) {
    issues.push({ level: "error", message: "The plan has no lines yet.", keys: [] });
    return issues;
  }

  const seen = new Map<string, string[]>();
  const zero: string[] = [];

  for (const l of lines) {
    const amt = money(l.amount);
    if (!Number.isFinite(l.amount) || l.amount < 0) {
      issues.push({
        level: "error",
        message: `A budget amount cannot be negative (${l.accountCode}).`,
        keys: [l.key],
      });
    }
    if (Math.abs(money(l.amount) * 100 - l.amount * 100) > 1e-6) {
      issues.push({
        level: "error",
        message: `Amounts are to the kobo — ${l.accountCode} has more than two decimals.`,
        keys: [l.key],
      });
    }
    if (amt === 0) zero.push(l.key);

    if (!l.accountCode) {
      issues.push({ level: "error", message: "A line has no category.", keys: [l.key] });
    } else if (accountKinds && !accountKinds[l.accountCode]) {
      issues.push({
        level: "error",
        message: `${l.accountCode} is not a budgetable income or expenditure account.`,
        keys: [l.key],
      });
    } else if (accountKinds && accountKinds[l.accountCode] !== l.kind) {
      issues.push({
        level: "error",
        message: `${l.accountCode} is a ${accountKinds[l.accountCode]} account but the line is filed as ${l.kind}.`,
        keys: [l.key],
      });
    }

    if (l.activityCode && knownActivities && !knownActivities.has(l.activityCode)) {
      issues.push({
        level: "error",
        message: `Activity ${l.activityCode} does not exist.`,
        keys: [l.key],
      });
    }
    if (l.periodNo < 0 || l.periodNo > 12) {
      issues.push({
        level: "error",
        message: `Period ${l.periodNo} is not a month of the year.`,
        keys: [l.key],
      });
    }

    const dup = `${l.activityCode ?? ""}|${l.accountCode}|${l.periodNo}`;
    seen.set(dup, [...(seen.get(dup) ?? []), l.key]);
  }

  for (const [dup, keys] of seen) {
    if (keys.length > 1) {
      const [act, acct, period] = dup.split("|");
      issues.push({
        level: "error",
        message:
          `${acct} appears ${keys.length} times for ` +
          `${act || "general spend"} in ${period === "0" ? "the annual budget" : `month ${period}`} — ` +
          `combine them into one line.`,
        keys,
      });
    }
  }

  if (zero.length > 0) {
    issues.push({
      level: "warning",
      message: `${zero.length} line${zero.length === 1 ? " has" : "s have"} no amount yet.`,
      keys: zero,
    });
  }

  const t = planTotals(lines);
  if (t.net < 0) {
    issues.push({
      level: "warning",
      message: "This plan budgets a deficit: expenditure is higher than income.",
      keys: [],
    });
  }
  if (t.incomeLineCount === 0) {
    issues.push({
      level: "warning",
      message: "No income is budgeted, so the net position is just the spend.",
      keys: [],
    });
  }

  return issues;
}

/** Errors only. */
export function planErrors(lines: readonly PlanLine[], opts: ValidateOptions = {}): PlanIssue[] {
  return validatePlan(lines, opts).filter((i) => i.level === "error");
}

/** A stable key for a new line, unique within a plan. */
export function nextLineKey(existing: readonly PlanLine[]): string {
  let n = existing.length + 1;
  const taken = new Set(existing.map((l) => l.key));
  while (taken.has(`L${n}`)) n++;
  return `L${n}`;
}

/** Deep copy, with fresh keys — used when cloning a prior-year plan. */
export function clonePlan(lines: readonly PlanLine[]): PlanLine[] {
  return lines.map((l, i) => ({ ...l, key: `L${i + 1}` }));
}
