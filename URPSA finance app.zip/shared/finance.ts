// Shared money + formatting helpers. Money is numeric(15,2) in Postgres and
// surfaces as a string; everything here converts to a number at the edge and
// rounds to the kobo so a float never leaks into a ledger figure.

/** Parse a Postgres numeric / string / number into a number. */
export function num(v: unknown): number {
  if (v === null || v === undefined || v === "") return 0;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

/**
 * Round to 2 decimal places (the kobo).
 *
 * `Math.round(n * 100)` is wrong for values whose binary representation sits
 * just under the half: 2.675 * 100 is 267.49999999999997, so it rounds DOWN to
 * 2.67 while a treasurer reading the receipt expects 2.68. Shifting the decimal
 * point through the string form first (`"2.675e2"` → 267.5) keeps the value the
 * human typed, and only then rounds. Half away from zero, which is what
 * accounting convention expects for a negative credit note too.
 */
export function money(v: unknown): number {
  const n = num(v);
  if (n === 0) return 0;
  const scaled = Number(`${n}e2`);
  if (!Number.isFinite(scaled)) return Math.round(n * 100) / 100;
  const rounded = Math.sign(scaled) * Math.round(Math.abs(scaled));
  return Number(`${rounded}e-2`);
}

/**
 * The currency symbol every amount renders with.
 *
 * The base currency is editable in Settings, so a hardcoded ₦ would mislabel a
 * book kept in dollars. The shell sets this once from the org row; the default
 * keeps a first paint (before the org query resolves) from showing a bare
 * number.
 */
let CURRENCY_SYMBOL = "₦";

export function setCurrencySymbol(symbol: string | null | undefined) {
  CURRENCY_SYMBOL = (symbol ?? "").trim() || "₦";
}

export function currentCurrencySymbol(): string {
  return CURRENCY_SYMBOL;
}

/** Format with thousands separators in the configured currency: ₦1,234,567.89 */
export function ngn(v: unknown, opts: { decimals?: boolean } = {}): string {
  const n = money(v);
  const decimals = opts.decimals ?? true;
  return (
    CURRENCY_SYMBOL +
    n.toLocaleString("en-NG", {
      minimumFractionDigits: decimals ? 2 : 0,
      maximumFractionDigits: decimals ? 2 : 0,
    })
  );
}

/** Compact form for dashboard tiles: ₦1.65m / ₦364.3k */
export function ngnCompact(v: unknown): string {
  const n = money(v);
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (abs >= 1_000_000) return `${sign}${CURRENCY_SYMBOL}${(abs / 1_000_000).toFixed(2)}m`;
  if (abs >= 1_000) return `${sign}${CURRENCY_SYMBOL}${(abs / 1_000).toFixed(1)}k`;
  return `${sign}${CURRENCY_SYMBOL}${abs.toFixed(2)}`;
}

/** A signed figure in accounting brackets: (₦1,234.00) for negatives. */
export function ngnSigned(v: unknown): string {
  const n = money(v);
  return n < 0 ? `(${ngn(Math.abs(n))})` : ngn(n);
}

/** Percentage of a against b, one decimal. */
export function pct(a: unknown, b: unknown): number {
  const d = num(b);
  if (d === 0) return 0;
  return Math.round((num(a) / d) * 1000) / 10;
}

/**
 * ISO date (YYYY-MM-DD) for today, in the user's LOCAL sense.
 *
 * `toISOString()` is UTC. In Lagos (UTC+1) a treasurer posting at 00:30 local
 * would get yesterday's date, and a transaction dated a day early lands in the
 * wrong month at a month boundary — which is exactly when it matters. Build the
 * string from the local calendar fields instead.
 */
export function today(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/** Human date: 12 Oct 2026 */
export function fmtDate(d: unknown): string {
  if (!d) return "—";
  const s = String(d).slice(0, 10);
  const [y, m, day] = s.split("-").map(Number);
  if (!y || !m || !day) return String(d);
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${day} ${months[m - 1]} ${y}`;
}

/** Month label: Oct 2026 */
export function fmtMonth(d: unknown): string {
  if (!d) return "—";
  const s = String(d).slice(0, 10);
  const [y, m] = s.split("-").map(Number);
  if (!y || !m) return String(d);
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${months[m - 1]} ${y}`;
}

/** The 12 fiscal months of an administration year starting 1 Oct. */
export function fiscalMonths(periodStart: string): { no: number; label: string; start: string; end: string }[] {
  const [sy, sm] = periodStart.split("-").map(Number);
  const out: { no: number; label: string; start: string; end: string }[] = [];
  for (let i = 0; i < 12; i++) {
    const m0 = sm - 1 + i;
    const y = sy + Math.floor(m0 / 12);
    const m = (m0 % 12) + 1;
    const start = `${y}-${String(m).padStart(2, "0")}-01`;
    const lastDay = new Date(Date.UTC(y, m, 0)).getUTCDate();
    const end = `${y}-${String(m).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;
    out.push({ no: i + 1, label: fmtMonth(start), start, end });
  }
  return out;
}

/** CSV escaping + a rows→CSV string. */
export function toCsv(headers: string[], rows: (string | number)[][]): string {
  const esc = (v: string | number) => {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [headers.map(esc).join(","), ...rows.map((r) => r.map(esc).join(","))].join("\n");
}

/** Trigger a browser download of a CSV string. */
export function downloadCsv(filename: string, csv: string) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
