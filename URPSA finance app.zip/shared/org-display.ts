// ─────────────────────────────────────────────────────────────────────────────
// ORGANISATION IDENTITY — one definition, used everywhere.
//
// The association's name, institution, faculty, session and currency are
// editable in Settings, so they must never be hardcoded in a page, a report
// header, a CSV title block or a print footer. Everything that displays the
// organisation reads it from here, and every function tolerates a missing
// field: a half-filled Settings page must not blank out a report.
// ─────────────────────────────────────────────────────────────────────────────

export interface OrgIdentity {
  legalName?: string | null;
  shortName?: string | null;
  institution?: string | null;
  faculty?: string | null;
  initials?: string | null;
  contactEmail?: string | null;
  contactPhone?: string | null;
  baseCurrency?: string | null;
  periodStart?: string | null;
  periodEnd?: string | null;
  treasurer?: string | null;
  financialSecretary?: string | null;
  president?: string | null;
}

/** Fallback used only when no organisation row exists yet. */
export const DEFAULT_ORG_NAME = "Urban and Regional Planning Students' Association (URPSA)";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function fmt(d?: string | null): string {
  if (!d) return "";
  const s = String(d).slice(0, 10);
  const [y, m, day] = s.split("-").map(Number);
  if (!y || !m || !day) return "";
  return `${day} ${MONTHS[m - 1]} ${y}`;
}

/**
 * The full name as it should appear on a statement: the legal name, with the
 * acronym appended when the legal name does not already carry it.
 */
export function orgTitle(org?: OrgIdentity | null): string {
  const legal = (org?.legalName ?? "").trim();
  if (!legal) return DEFAULT_ORG_NAME;
  const short = (org?.shortName ?? "").trim();
  if (!short) return legal;
  // "… Association" + "URPSA" → "… Association (URPSA)"
  if (legal.toUpperCase().includes(short.toUpperCase())) return legal;
  return `${legal} (${short})`;
}

/** Institution and faculty, joined — the line under the name on a report. */
export function orgSubtitle(org?: OrgIdentity | null): string {
  return [org?.institution, org?.faculty]
    .map((s) => (s ?? "").trim())
    .filter(Boolean)
    .join(" · ");
}

/** The administration year, e.g. "2026/2027 session · 1 Oct 2026 – 30 Sep 2027". */
export function orgSession(org?: OrgIdentity | null): string {
  const start = fmt(org?.periodStart);
  const end = fmt(org?.periodEnd);
  if (!start && !end) return "";
  const sy = String(org?.periodStart ?? "").slice(0, 4);
  const ey = String(org?.periodEnd ?? "").slice(0, 4);
  const label = sy && ey ? `${sy}/${ey} session` : "Session";
  return `${label} · ${start} – ${end}`;
}

/** Contact line for a report footer. */
export function orgContact(org?: OrgIdentity | null): string {
  return [org?.contactEmail, org?.contactPhone]
    .map((s) => (s ?? "").trim())
    .filter(Boolean)
    .join(" · ");
}

/**
 * The logo mark: the treasurer's own initials when set, otherwise derived from
 * the short name, otherwise from the first letters of the legal name.
 */
export function orgInitials(org?: OrgIdentity | null): string {
  const explicit = (org?.initials ?? "").trim();
  if (explicit) return explicit.slice(0, 4).toUpperCase();

  const short = (org?.shortName ?? "").trim();
  if (short) {
    // "URPSA" → "UR" (a two-letter mark reads better in a 32px square)
    return short.slice(0, 2).toUpperCase();
  }
  const words = (org?.legalName ?? "")
    .replace(/[()]/g, " ")
    .split(/\s+/)
    .filter((w) => w && w[0] === w[0].toUpperCase());
  return words.slice(0, 2).map((w) => w[0]).join("").toUpperCase() || "UR";
}

/** Currency symbol for the configured base currency. */
export function currencySymbol(code?: string | null): string {
  switch ((code ?? "NGN").toUpperCase()) {
    case "NGN":
      return "₦";
    case "USD":
      return "$";
    case "GBP":
      return "£";
    case "EUR":
      return "€";
    default:
      return "";
  }
}

/** "Amount (NGN)" — the CSV column header for the configured currency. */
export function amountHeader(org?: OrgIdentity | null): string {
  return `Amount (${(org?.baseCurrency ?? "NGN").toUpperCase()})`;
}
