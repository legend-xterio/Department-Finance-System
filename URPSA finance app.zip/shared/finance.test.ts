import { describe, expect, it } from "vitest";
import { money, num, ngn, ngnSigned, pct, toCsv, fiscalMonths } from "../shared/finance";

// The money helpers are the arithmetic floor under every report. A rounding
// slip here shows up as a trial balance that will not close, so these pin the
// behaviour the ledger depends on.

describe("money — the ledger's arithmetic floor", () => {
  it("rounds to two decimals, killing float artefacts", () => {
    expect(money(0.1 + 0.2)).toBe(0.3);
    expect(money(1.005)).toBe(1.01);
    expect(money(2.675)).toBe(2.68);
    expect(money(1234.5678)).toBe(1234.57);
  });

  it("coerces strings and nullish values without producing NaN", () => {
    expect(money("2500.50")).toBe(2500.5);
    expect(money(null)).toBe(0);
    expect(money(undefined)).toBe(0);
    expect(money("")).toBe(0);
  });

  it("num() parses a Postgres numeric string", () => {
    expect(num("3883500.00")).toBe(3883500);
    expect(num("0.00")).toBe(0);
    expect(num(null)).toBe(0);
  });

  it("is idempotent — rounding an already-rounded figure changes nothing", () => {
    for (const v of [0.3, 1234.57, 3883500, 0.01]) {
      expect(money(money(v))).toBe(money(v));
    }
  });

  it("keeps a balanced pair balanced after rounding — the entry invariant", () => {
    // The engine rounds each line to 2dp and requires the two sides to be
    // equal. Rounding both sides the same way is what makes that hold.
    const amount = 1234.565;
    const debit = money(amount);
    const credit = money(amount);
    expect(debit).toBe(credit);
    expect(money(debit - credit)).toBe(0);
  });
});

describe("ngn — presentation", () => {
  it("formats with the naira sign and thousands separators", () => {
    expect(ngn(3883500)).toContain("3,883,500");
    expect(ngn(3883500)).toContain("₦");
  });

  it("shows two decimals by default and none when asked", () => {
    expect(ngn(1234.5)).toContain("1,234.50");
    expect(ngn(1234.5, { decimals: false })).toContain("1,235");
  });

  it("ngnSigned marks a negative figure with brackets, not a bare minus", () => {
    expect(ngnSigned(-5000)).toContain("(");
    expect(ngnSigned(-5000)).toContain("5,000");
    expect(ngnSigned(5000)).not.toContain("(");
  });
});

describe("pct — used by budget and dues", () => {
  it("computes a percentage", () => {
    expect(pct(50, 200)).toBe(25);
    expect(pct(200, 200)).toBe(100);
  });

  it("returns 0 rather than Infinity when the denominator is zero", () => {
    expect(pct(50, 0)).toBe(0);
    expect(Number.isFinite(pct(50, 0))).toBe(true);
  });
});

describe("toCsv — the export path", () => {
  it("emits a header row and one row per record", () => {
    const csv = toCsv(["Code", "Name", "Amount"], [["4001", "Dues", 25000]]);
    const lines = csv.trim().split("\n");
    expect(lines).toHaveLength(2);
    expect(lines[0]).toContain("Code");
    expect(lines[1]).toContain("4001");
  });

  it("quotes a field containing a comma so the columns do not shift", () => {
    const csv = toCsv(["Name"], [["Printing, stationery & banners"]]);
    expect(csv).toContain('"Printing, stationery & banners"');
  });

  it("escapes an embedded double quote", () => {
    const csv = toCsv(["Name"], [['The "big" conference']]);
    expect(csv).toContain('""big""');
  });
});

describe("fiscalMonths — the administration year", () => {
  it("returns twelve months starting at the given month", () => {
    const months = fiscalMonths("2026-10-01");
    expect(months).toHaveLength(12);
    expect(months[0].start).toBe("2026-10-01");
    expect(months[11].start).toBe("2027-09-01");
  });

  it("numbers the periods 1..12", () => {
    const months = fiscalMonths("2026-10-01");
    expect(months.map((m) => m.no)).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]);
  });

  it("ends each month on the last day of that month", () => {
    const months = fiscalMonths("2026-10-01");
    expect(months[0].end).toBe("2026-10-31");
    expect(months[1].end).toBe("2026-11-30");
    expect(months[3].end).toBe("2027-01-31");
    expect(months[11].end).toBe("2027-09-30");
  });
});
