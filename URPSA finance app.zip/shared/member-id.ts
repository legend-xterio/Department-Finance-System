// ─────────────────────────────────────────────────────────────────────────────
// MEMBER ID RULE — URPSA/YY/XXX
//
// Kept pure (no db, no env, no tRPC) so the same rule is used by the server when
// it allocates an ID, by the form when it previews one, and by the tests. A rule
// that lives in three places drifts; this one lives here.
// ─────────────────────────────────────────────────────────────────────────────

/** Two-digit year, three-digit sequence: URPSA/26/013 */
export const MEMBER_ID_RE = /^URPSA\/\d{2}\/\d{3}$/;

/** Build the ID for an admission year and sequence number. */
export function formatMemberId(year: string, seq: number): string {
  const yy = String(year).replace(/\D/g, "").slice(-2).padStart(2, "0");
  return `URPSA/${yy}/${String(seq).padStart(3, "0")}`;
}

export function isValidMemberId(id: string): boolean {
  return MEMBER_ID_RE.test(id.trim().toUpperCase());
}

/** The prefix an admission year owns, e.g. "URPSA/26/". */
export function memberIdPrefix(year: string): string {
  const yy = String(year).replace(/\D/g, "").slice(-2).padStart(2, "0");
  return `URPSA/${yy}/`;
}

/** Highest sequence already used under a prefix, or 0 when the prefix is free. */
export function highestSequence(ids: string[], prefix: string): number {
  let max = 0;
  for (const id of ids) {
    if (!id.startsWith(prefix)) continue;
    const n = Number(id.slice(prefix.length));
    if (Number.isFinite(n) && n > max) max = n;
  }
  return max;
}
